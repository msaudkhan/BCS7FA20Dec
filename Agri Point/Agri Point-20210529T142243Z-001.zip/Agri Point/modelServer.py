from flask import Flask, render_template, request, Markup, jsonify
import numpy as np
import pandas as pd
import requests
import json
import config
import pickle
import io
import torch
from torchvision import transforms
from flask_cors import CORS
import googletrans
from googletrans import Translator

def weather_fetch(city_name):
    api_key = "fc37e342877e759a985159826961e3c5"
    base_url = "http://api.openweathermap.org/data/2.5/weather"

    complete_url = base_url + "?q=" + city_name + "&appid=" + api_key
    response = requests.get(complete_url)
    x = response.json()

    if x["cod"] != "404":
        y = x["main"]

        tempmin = round((y["temp_min"] - 273.15), 2)
        tempmax = round((y["temp_max"] - 273.15), 2)
        humidity = y["humidity"]
        return tempmin,tempmax, humidity
    else:
        return None


crop_recommendation_model_path = 'Trained_Model/DecisionTree.pkl'
crop_recommendation_model = pickle.load(open(crop_recommendation_model_path, 'rb'))

app = Flask(__name__)
cors = CORS(app, resources={r"/*": {"origins": "*"}})

@ app.route('/Crop', methods=['POST'])
def crop_prediction():
    if request.method == 'POST':
        StartingMonth =int(request.form['mon'])
        CultivationTime=int(request.form['cultime'])
        RainfallRequirement = int(request.form['rain'])
        Irrigation=int(request.form['irrigation'])
        City =(request.form['city'])
        minTemp,maxtemp, Humidity=weather_fetch(City)
        ci=None
        if City=='Attock':
            ci="0"
        elif City=='Faisalabad':
            ci="1"
        elif City=='Multan':
            ci="2"
        elif City=='Peshawar':
            ci="3"
        elif City=='Swabi':
            ci="4"    
        Soil=int(request.form['soil'])
        data = np.array([[int(StartingMonth),int(CultivationTime),int(minTemp),int(maxtemp),int(RainfallRequirement),int(Humidity),int(Irrigation),ci,int(Soil)]])
        my_prediction = crop_recommendation_model.predict(data)
        final_prediction = my_prediction[0]
        translator = Translator()
        translation = translator.translate(final_prediction,dest="ur")
        return jsonify({'name' : translation.text})
        


if __name__ == '__main__':
    app.run(debug=True)
