<?php
ob_start();
    session_start();
    // header('Access-Control-Allow-Origin: *');
    // header('Access-Control-Allow-Credentials: true');
?>
<!DOCTYPE html>
<html>

<head>
    <meta charset="UTF-8">
    <meta name="description" content="">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <!-- The above 4 meta tags *must* come first in the head; any other head content must come *after* these tags -->

    <!-- Title -->
    <title>Agri Point</title>

    <!-- Favicon -->
    <link rel="icon" href="img/core-img/favicon.ico">
      
    <!-- Core Stylesheet -->
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" type="text/css" href="ModalStyle.css">
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Amiri&display=swap" rel="stylesheet">
    
    <style type="text/css">

        body{
            font-family: 'Amiri', serif;
        }
        .dropdown-content {
  display: none;
  position: absolute;
}

.dropdown:hover .dropdown-content {display: block;}




    </style>

</head>

<body>
    <!-- Preloader -->
    <div class="preloader d-flex align-items-center justify-content-center">
        <div class="preloader-circle"></div>
        <div class="preloader-img">
            <img src="img/core-img/leaf.png" alt="">
        </div>
    </div>

    <!-- ##### Header Area Start ##### -->
    <header class="header-area">

        <!-- ***** Top Header Area ***** -->
        <div class="top-header-area">
            <div class="container">
                <div class="row">
                    <div class="col-12">
                        <div class="top-header-content d-flex align-items-center justify-content-between">
                            <!-- Top Header Content -->
                            <div class="top-header-meta">
                                <a href="#" data-toggle="tooltip" data-placement="bottom" title="infoagripoint@gmail.com"><i class="fa fa-envelope-o" aria-hidden="true"></i> <span>Email: infoagripoint@gmail.com</span></a>
                                <a href="#" data-toggle="tooltip" data-placement="bottom" title="+9257 2741540"><i class="fa fa-phone" aria-hidden="true"></i> <span>Call Us: +9257 2741540</span></a>
                            </div>

                            <!-- Top Header Content -->
                            <div class="top-header-meta d-flex">
                                <!-- Language Dropdown -->
                                <div class="language-dropdown">
                                    <div class="dropdown">
                                        <button class="btn btn-secondary dropdown-toggle mr-30" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">زبان </button>
                                        <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                                            <a class="dropdown-item" href="#">اردو </a>
                                            
                                        </div>
                                    </div>
                                </div>
                                <!-- Login -->
                                <?php if(isset($_SESSION['Name'])){ ?>
                                    <div class="login dropdown" >
                                    <a href="#"><i class="fa fa-user" aria-hidden="true"></i> <span><?php echo $_SESSION['Name']; ?></span></a>
                                    <div class="dropdown-content">
                                    <a href="logout.php" style="text-te">Logout</a></div>
                                </div>
                                <?php }else{ ?>
                                    <div class="login" id="login">
                                    <a href="#"><i class="fa fa-user" aria-hidden="true"></i> <span>لاگ ان </span></a>
                                </div>
                                <?php }?>
                                <!-- Cart -->
                                <div class="cart">
                                    <a href="cart.php"><i class="fa fa-shopping-cart" aria-hidden="true"></i> <span>کرٹ <span class="cart-quantity"></span></span></a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- ***** Navbar Area ***** -->
        <div class="alazea-main-menu">
            <div class="classy-nav-container breakpoint-off">
                <div class="container">
                    <!-- Menu -->
                    <nav class="classy-navbar justify-content-between" id="alazeaNav">

                        <!-- Nav Brand -->
                        <a href="index.php" class="nav-brand"><img src="img/core-img/logo.png" alt=""></a>

                        <!-- Navbar Toggler -->
                        <div class="classy-navbar-toggler">
                            <span class="navbarToggler"><span></span><span></span><span></span></span>
                        </div>

                        <!-- Menu -->
                        <div class="classy-menu">

                            <!-- Close Button -->
                            <div class="classycloseIcon">
                                <div class="cross-wrap"><span class="top"></span><span class="bottom"></span></div>
                            </div>

                            <!-- Navbar Start -->
                            <div class="classynav">
                                <ul>
                                    <li><a href="index.php">ہوم </a></li>
                                    <li><a href="about.php"> ہمارے بارے میں </a></li>
                                    <li><a href="#">  پروڈکٹ  </a>
                                        <ul class="dropdown">
                                            <li><a href="product.php"> معلومات </a></li>
                                            <?php if(isset($_SESSION['Name'])){ ?>
                                            <li><a id="myBtn" href="#">  فروخت </a></li>
                                            <?php }else{ ?>
                                    <li><a id="logi" href="#">  فروخت </a></li>
                                <?php }if(isset($_SESSION['Name'])){ ?>
                                            <li><a id="shop" href="#"> کھاد کیلکولیٹر </a></li>
                                            <?php }else{ ?>
                                    <li><a id="logi1" href="#"> کھاد کیلکولیٹر </a></li>
                                    <?php }if(isset($_SESSION['Name'])){ ?>
                                            <li><a id="far" href="#"> فارمر ایکسپیرینس </a></li>
                                            <?php }else{ ?>
                                    <li><a id="logi2" href="#">  فارمر ایکسپیرینس </a></li>
                                <?php }if(isset($_SESSION['Name'])){ ?>
                                            <li><a id="lab" href="#">  لیبر </a></li>
                                            <?php }else{ ?>
                                    <li><a id="logi3" href="#">  لیبر </a></li>
                                <?php }?>
                                    <li><a id="sug" href="#"> کروپ سجیشن </a></li>
                                        </ul></li>    
                                            <li><a href="contact.php">ہم سے رابطہ کریں </a></li>
                                        
                                    
                                    <li><a href="shop.php"> شاپ   </a></li>
                                    
                                    <li><a href="#"> ادر  <span id="numb" ></span> </a>
                                    <ul class="dropdown">
                                            <?php if(isset($_SESSION['Name'])){ ?>
                                            <li><a  href="farmer.php"><span id="numbf"></span> فارمر</a></li>
                                            <?php }else{ ?>
                                    <li><a id="logi4" href="#">  فارمر</a></li>
                                        <?php }if(isset($_SESSION['Name'])){ ?>
                                            <li><a href="labour.php"><span id="numbl"></span> لیبر</a></li>
                                            <?php }else{ ?>
                                            <li><a id="logi5" href="#"> لیبر</a></li>
                                            <?php }
                                            if(isset($_SESSION['Name'])){ ?>
                                            <li>
                                              <a href="transaction.php">ٹرانزیکشن</a>
                                            </li>
                                            <?php }else{ ?>
                                            <li>
                                                <a id="logi6" href="#"> ٹرانزیکشن</a></li>
                                            <?php }
                                            if(isset($_SESSION['Name'])){ ?>
                                            <li>
                                              <a href="user_data.php"> ڈیٹا </a>
                                            </li>
                                            <?php }else{?>
                                            <li>
                                                <a id="logi6" href="#"> ڈیٹا </a></li>
                                                <?php } ?>
                                            </ul></li>
                                
                                	</ul>
                                <!-- Search Icon -->
                                <div id="searchIcon">
                                    <i class="fa fa-search" aria-hidden="true"></i>
                                </div>

                            </div>
                            <!-- Navbar End -->
                        </div>
                    </nav>

                    <!-- Search Form -->
                    <div class="search-form">
                        <form action="#" method="get">
                            <input type="search" name="search" id="search" placeholder="Type keywords &amp; press enter...">
                            <button type="submit" class="d-none"></button>
                        </form>
                        <!-- Close Icon -->
                        <div class="closeIcon"><i class="fa fa-times" aria-hidden="true"></i></div>
                    </div>
                </div>
            </div>
        </div>
    </header>
    <!-- ##### Header Area End ##### -->


    <!-- ##### Hero Area Start ##### -->
    <section class="hero-area">
        <div class="hero-post-slides owl-carousel">

            <!-- Single Hero Post -->
            <div class="single-hero-post bg-overlay">
                <!-- Post Image -->
                <div class="slide-img bg-img" style="background-image: url(img/bg-img/1.jpg);"></div>
                <div class="container h-100">
                    <div class="row h-100 align-items-center">
                        <div class="col-12">
                            <!-- Post Content -->
                            <div class="hero-slides-content text-center">
                                <h2>Agriculture manufactures, commerce and navigation, the four pillars of our prosperity, are the most thriving when left most free to individual enterprise.</h2>
                                
                                </div>
                            </div>
                        </div>
                        
                    </div>
                </div>
            

            <!-- Single Hero Post -->
            <div class="single-hero-post bg-overlay">
                <!-- Post Image -->
                <div class="slide-img bg-img" style="background-image: url(img/bg-img/2.jpg);"></div>
                <div class="container h-100">
                    <div class="row h-100 align-items-center">
                        <div class="col-12">
                            <!-- Post Content -->
                            <div class="hero-slides-content text-center">
                                <h2>Agriculture manufactures, commerce and navigation, the four pillars of our prosperity, are the most thriving when left most free to individual enterprise.</h2>
                                
                                </div>
                                </div>
                            </div>
                        </div>

                    </div>
                </div>
            </div>
            
        </div>
    </section>
    <!-- ##### Hero Area End ##### -->
    	 
    <!-- ##### Portfolio Area Start ##### -->
    <section class="alazea-portfolio-area section-padding-100-0">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <!-- Section Heading -->
                    <div class="section-heading text-center">
                        <h2>پروڈکٹ</h2>
                        <p>ہر قسم کی مصنوعات کے بارے میں معلومات حاصل کریں</p>
                    </div>
                </div>
            </div>
        </div>

        <div class="container-fluid">
            <div class="row">
                <div class="col-12">
                    <div class="alazea-portfolio-filter">
                        <div class="portfolio-filter">
                            <button class="btn active" data-filter=".درخت "> درخت </button>
                            <button class="btn" data-filter=".پودے  "> پودے  </button>
                            <button class="btn" data-filter=".سبزی "> سبزی </button>
                            <button class="btn" data-filter=".پھل "> پھل </button>
                            <button class="btn" data-filter="*">سب کچھ </button>
                        </div>
                    </div>
                </div>
            </div>

            <div class="row alazea-portfolio">

                <?php
                    $con = mysqli_connect("localhost", "root", "", "agripoint");
                    echo $con->connect_error;
                    $query="SELECT * from information LIMIT 8";
                    $res=$con->query($query);
                    if ($res->num_rows>0) {
                        while ($row=$res->fetch_assoc()) {
                            $id=$row['Id'];
                            echo "<!-- Single Portfolio Area -->
                <div class='col-12 col-sm-6 col-lg-3 single_portfolio_item ".$row['Type']." wow fadeInUp' data-wow-delay='100ms' onclick='popupInfo(".$id.")'>
                    <!-- Portfolio Thumbnail -->
                    <div class='portfolio-thumbnail bg-img' style='background-image: url(".$row['Image'].");'></div>
                    <!-- Portfolio Hover Text -->
                    <div class='portfolio-hover-overlay'>
                        <a class='d-flex align-items-center justify-content-center'>
                            <div class='port-hover-text'>
                                <h3>".$row['Name']."</h3>
                                <h5>".$row['Type']."</h5>
                            </div>
                        </a>
                    </div>
                </div>
<div id='".$id."' class='modal'>

  <!-- Modal content -->
  <div class='modal-content divpro'>
    <span  onclick='closemod(".$id.")' class='close1'>&times;</span>
  <h1 class='h1'><span class='span'>Details</span> Of Products</h1>
  <p>".$row['Discription']."</p>

  </div>

</div>
                ";
                        }
                    }
                ?>

                

            </div>
        </div>
    </section>
    <!-- ##### Portfolio Area End ##### -->
<script type="text/javascript">
    function popupInfo(idinfo){
        document.getElementById(idinfo).style.display='block';
    }
    function closemod(idinfo){
        document.getElementById(idinfo).style.display='none';
    }
</script>
    <!-- ##### Product Area Start ##### -->
    <section class="new-arrivals-products-area bg-gray section-padding-100">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <!-- Section Heading -->
                    <div class="section-heading text-center">
                        <h2>NEW ARRIVALS</h2>
                        <p>ہمارے پاس جدید ترین مصنوعات ہیں ، یہ آپ کے لئے دلچسپ ہوگا</p>
                    </div>
                </div>
            </div>


            <div class="row">
<!-- Single Product Area -->
        <?php
        $con=mysqli_connect("localhost","root","","AgriPoint");
        echo $con->connect_error;        
        $query="SELECT * FROM products ORDER BY Id DESC LIMIT 4";
        $re=$con->query($query);
        if ($re && $re->num_rows>0) {
            while ($row=$re->fetch_assoc()) {
                $img=$row['Image'];
                $na=$row['Product_name'];
                $tag=$row['Tag'];
                $pri=$row['Price'];
                $val=$row['Id'];
                echo "
                <div class='col-12 col-sm-6 col-lg-3'>
                    <div class='single-product-area1 mb-50 wow fadeInUp' data-wow-delay='100ms'>
                        <!-- Product Image -->
                        <div class='product-img1'>
                            <a ><img src='".$img."' alt=''></a>
                            <!-- Product Tag -->
                            <div class='product-tag'>";
                                            if ($tag!="None") {
                                                echo "
                                            <a href='#'>".$tag."</a>";
                                            }
                                            echo "
                            </div>
                            <div class='product-meta d-flex'>
                                
                                <a";if(isset($_SESSION['Name'])){ echo " onclick='CartPass(".$val.")'";}echo " class='add-to-cart-btn'>Add to cart</a>
                            </div>
                        </div>
                        <!-- Product Info -->
                        <div class='product-info mt-15 text-center'>
                            <a>
                                <p>".$na."</p>
                            </a>
                            <h6>".$pri."</h6>
                        </div>
                    </div>
                </div>";}}?>

                <div class="col-12 text-center">
                    <a href="shop.php" class="btn alazea-btn"> ویو آل </a>
                </div>

            </div>
        </div>
    </section>
    <script type="text/javascript">
    
    function CartPass(a){
        var val="?id="+a;
        location.href='cart.php'+val;
    }
</script>
    <!-- ##### Product Area End ##### -->
    <!-- ##### Contact Area Start ##### -->
    <section class="contact-area section-padding-100-0">
        <div class="container">
            <div class="row align-items-center justify-content-between">
                <div class="col-12 col-lg-5">
                    <!-- Section Heading -->
                    <div class="section-heading">
                        <h2>GET IN TOUCH</h2>
                        <p>Send us a message, we will call back later</p>
                    </div>
                    <!-- Contact Form Area -->
                    <div class="contact-form-area mb-100">
                        <form  id="feedform" method="POST" action="php/snd_feedback.php">
                            <div class="row">
                                <div class="col-12 col-sm-6">
                                    <div class="form-group">
                                        <input type="text" class="form-control" id="contact-name" placeholder="Your Name">
                                    </div>
                                </div>
                                <div class="col-12 col-sm-6">
                                    <div class="form-group">
                                        <input type="email" class="form-control" id="contact-email" placeholder="Your Email">
                                    </div>
                                </div>
                                <div class="col-12">
                                    <div class="form-group">
                                        <input type="text" class="form-control" id="contact-subject" placeholder="Subject">
                                    </div>
                                </div>
                                <div class="col-12">
                                    <div class="form-group">
                                        <textarea class="form-control" name="message" id="message" cols="30" rows="10" placeholder="Message"></textarea>
                                    </div>
                                </div>
                                <div class="col-12">
                                    <button type="submit" class="btn alazea-btn mt-15">Send Message</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>

                <div class="col-12 col-lg-6">
                    <!-- Google Maps -->
                    <div class="map-area mb-100">
                        <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3316.242849802438!2d72.34963171744384!3d33.780226400000004!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0xcc390d96d8c2dad2!2sCIIT%20Attock%20(New%20Campus)%2C%20Attock%2C%20Pakistan!5e0!3m2!1sen!2s!4v1602558129913!5m2!1sen!2s" width="600" height="450" frameborder="0" style="border:0;" allowfullscreen="" aria-hidden="false" tabindex="0"></iframe>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- ##### Contact Area End ##### -->
<script src="js/jquery/jquery-2.2.4.min.js"></script>
<script type="text/javascript">
    $(document).ready(function () {
  $("#feedform").submit(function (event) { 
    if ($("#contact-name").val().length>0 && $("#contact-email").val().length>0 && $("#contact-subject").val().length>0 && $("#message").val().length>0) {
    var formData = {
      name: $("#contact-name").val(),
      email: $("#contact-email").val(),
      subject: $("#contact-subject").val(),
      message: $("#message").val(),
    };
           $.ajax({    
                type:"POST",
                url:"php/snd_feedback.php",  
                data:formData,  
                dataType:"json", 
                encode: true,       
           }).done(function (data) { 
                alert(data.ans);
                });
}

else{
    alert('Fill all Fields');
}

            event.preventDefault();  
      });
});

    if ( window.history.replaceState ) {
        window.history.replaceState( null, null, window.location.href );
    }
</script>
    <!-- ##### Footer Area Start ##### -->
    <footer class="footer-area bg-img" style="background-image: url(img/bg-img/3.jpg);">
        <!-- Main Footer Area -->
        <div class="main-footer-area">
            <div class="container">
                <div class="row">

                    <!-- Single Footer Widget -->
                    <div class="col-12 col-sm-6 col-lg-3">
                        <div class="single-footer-widget">
                            <div class="footer-logo mb-30">
                                <a href="#"><img src="img/core-img/logo.png" alt=""></a>
                            </div>
                            <p>زراعت مینوفیکچر کی بنیاد ہے ، چونکہ قدرت کی تیاری ہی آرٹ کا سامان ہے۔</p>
                            <div class="social-info">
                                <a href="#"><i class="fa fa-facebook" aria-hidden="true"></i></a>
                                <a href="#"><i class="fa fa-twitter" aria-hidden="true"></i></a>
                                <a href="#"><i class="fa fa-google-plus" aria-hidden="true"></i></a>
                                <a href="#"><i class="fa fa-instagram" aria-hidden="true"></i></a>
                                <a href="#"><i class="fa fa-linkedin" aria-hidden="true"></i></a>
                            </div>
                        </div>
                    </div>

                    <!-- Single Footer Widget -->
                    <div class="col-12 col-sm-6 col-lg-3">
                        <div class="single-footer-widget">
                            <div class="widget-title">
                                <h5> کوئیک لنک </h5>
                            </div>
                            <nav class="widget-nav">
                                <ul>
                                    <li><a href="#">خریداری  </a></li>
                                    <li><a href="#">FAQs</a></li>
                                    <li><a href="#">    پیمنٹس </a></li>
                                    <li><a href="#">  نیوز </a></li>
                                    <li><a href="#">  ریٹرن </a></li>
                                    <li><a href="#">  اشتہار </a></li>
                                    <li><a href="#"> شپنگ </a></li>
                                    <li><a href="#">  کیریئر </a></li>
                                    <li><a href="#">    آرڈرز </a></li>
                                    <li><a href="#"> پالیسیز   </a></li>
                                </ul>
                            </nav>
                        </div>
                    </div>

                    <!-- Single Footer Widget -->
                    <div class="col-12 col-sm-6 col-lg-3">
                        <div class="single-footer-widget">
                            <div class="widget-title">
                                <h5> بیسٹ سیلر </h5>
                            </div>
 <?php
        $con=mysqli_connect("localhost","root","","AgriPoint");
        echo $con->connect_error;        
        $query="SELECT * FROM buy ORDER BY Price DESC LIMIT 2";
        $re=$con->query($query);
        if ($re && $re->num_rows>0) {
            while ($row=$re->fetch_assoc()) {
                $img=$row['Image'];
                $na=$row['Product_Name'];
                $pri=$row['Price'];
                echo "
                            <!-- Single Best Seller Products -->
                            <div class='single-best-seller-product d-flex align-items-center'>
                                <div class='product-thumbnail'>
                                    <a ><img src='".$img."' alt=''></a>
                                </div>
                                <div class='product-info'>
                                    <a >".$na."</a>
                                    <p>".$pri."</p>
                                </div>
                            </div>";}}?>

                            
                        </div>
                    </div>

                    <!-- Single Footer Widget -->
                    <div class="col-12 col-sm-6 col-lg-3">
                        <div class="single-footer-widget">
                            <div class="widget-title">
                                <h5> رابطہ </h5>
                            </div>

                            <div class="contact-information">
                                <p><span>Address:</span> comsats یونیورسٹی اٹک کیمپس </p>
                                <p><span>Phone:</span> +9257 2741540</p>
                                <p><span>Email:</span> infoagripoint@gmail.com</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Footer Bottom Area -->
        <div class="footer-bottom-area">
            <div class="container">
                <div class="row">
                    <div class="col-12">
                        <div class="border-line"></div>
                    </div>
                    <!-- Copywrite Text -->
                    <div class="col-12 col-md-6">
                        <div class="copywrite-text">
                            <p> <a target="_blank" href="index.php">AGRI POINT</a></p>
                        </div>
                    </div>
                    <!-- Footer Nav -->
                    <div class="col-12 col-md-6">
                        <div class="footer-nav">
                            <nav>
                                <ul>
                                    <li><a href="index.php">  ہوم </a></li>
                                    <li><a href="index.php">  پروڈکٹ </a></li>
                                    <li><a href="shop.php">  شاپ    </a></li>
                                    <li><a href="contact.php"> ہم سے رابطہ کریں </a></li>
                                    <li><a href="about.php">ہمارے بارے میں</a></li>
                                </ul>
                            </nav>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </footer>
    <!-- ##### Footer Area End ##### -->


<div id="myModal" class="modal">

  <!-- Modal content -->
  <div class="modal-content divpro">
  	<span class="close">&times;</span>
    <form class="form" enctype="multipart/form-data" method="POST">
  <h1 class="h1"><span class="span">Product</span> Information</h1>
  <input class="input" placeholder="Name" type="text" name="OName" required="">
  <input class="input" placeholder="Product Name" type="text" name="PName" required="">
  <input class="input" type="text"  placeholder="Price" name="price" required="">
  <select name="cate" class="input">
  	<option value="Plant">Plant</option>
  	<option value="Seed">Seed</option>
  	<option value="Fetilizer">Fetilizer</option>
  	<option value="Other">Other</option>
  </select>
  <select name="Tag" class="input">
  	<option value="None">None</option>
  	<option value="Hot">Hot</option>
  	<option value="Sale">Sale</option>
  </select>
  <input class="input" type="file" name="image" id="img2" onchange="validateImage2()" required="">

  <button name="add_pro" class="btn1 button1">Add</button>
</form>

  </div>

</div>



<div id="myModal2" class="modal">

  <!-- Modal content -->
  <div class="modal-content divpro">
    <span class="close">&times;</span>
    <form class="form" enctype="multipart/form-data" method="POST" name="login_form">
        <h1 class="h1"><span class="span">Log</span>in</h1>
        <input class="input" placeholder="Email" type="email" name="email" required="">
        <p id="email"></p>
        <input class="input" placeholder="Password" type="password" name="pass" required="">
        <p id="pass"></p>
        <button type="submit" class="btn1 button1" name="log" >Login</button>
        <h5 style="margin-top:2px; ">If not Register <u id="signup" >Click here</u></h5>
    </form>

  </div>

</div>

</div>



<div id="myModal3" class="modal">

  <!-- Modal content -->
  <div class="modal-content divpro">
    <span class="close">&times;</span>
    <form class="form" enctype="multipart/form-data" method="POST" action="">
  <h1 class="h1"><span class="span">Sign</span>Up</h1>
  <input class="input" placeholder="Name" type="text" name="uname" required="" />
  <input class="input" placeholder="Email" type="email" name="email" required="" />
  <input class="input" placeholder="Password" type="password" name="password" required="" />
  <input class="input" placeholder="Confirm Password" type="password" name="cpassword" required="" />
  <button class="btn1 button1" name="reg">Signup</button>
</form>

  </div>

</div>



<div id="myModal4" class="modal">

  <!-- Modal content -->
  <div class="modal-content divpro">
    <span class="close">&times;</span>
    <form class="form" enctype="multipart/form-data" method="POST">
  <h1 class="h1"><span class="span">Farmer</span> Experience</h1>
  <input class="input" placeholder="Name" type="text" name="Name" required="">
  <input class="input" placeholder="Experience" type="text" name="exp" required="">
  <select name="field" class="input">
    <option value="Plant">Plant</option>
    <option value="Seed">Seed</option>
    <option value="Fetilizer">Fetilizer</option>
    <option value="Other">Other</option>
  </select>
  <input class="input" required="" type="text"  placeholder="Discription" name="dis">
  <input class="input" type="file" required="" name="image" id="img1" onchange="validateImage1()">

  <button name="add_ex" class="btn1 button1">Add</button>
</form>

  </div>

</div>

<div id="myModal5" class="modal">

  <!-- Modal content -->
  <div class="modal-content divpro">
    <span class="close">&times;</span>
    <form class="form"  name="labour" enctype="multipart/form-data" method="POST" autocomplete="off">
  <h1 class="h1"><span class="span">Labour</span> Experience</h1>
  <input class="input" placeholder="Name" type="text" name="LName" required="" >
  <input class="input" placeholder="Email" type="email" name="LEmail" required="">
  <input class="input" placeholder="Experience" type="text" name="lexp" required="">
  <select name="lfield" class="input">
    <option value="Plant">Plant</option>
    <option value="Seed">Seed</option>
    <option value="Fetilizer">Fetilizer</option>
    <option value="Other">Other</option>
  </select>
  <input class="input" type="text"  placeholder="Discription" name="ldis" required="">
  <input class="input" type="file" name="limage" id="img" onchange="validateImage()" required="">
  <input  type="submit"  class="btn1 button1"  name="Lab_Info" value="Add Experience">
</form>

  </div>

</div>


<div id="myModal1" class="modal">

  <!-- Modal content -->
  <div class="modal-content divpro">
    <span class="close">&times;</span>
    <form class="form" enctype="multipart/form-data" method="POST" action="">
  <p  type="submit" name="" class="input" id="withoutnpk" >Without NPK</p>
  <p  name="" class="input" style="margin-top: 20px;" id="withnpk" >With NPK</p>
</form>

  </div>

</div>


<div id="myModal6" class="modal">

  <!-- Modal content -->
  <div class="modal-content divpro">
    <span class="close">&times;</span>
    <form class="form"  enctype="multipart/form-data" method="POST" autocomplete="off">
  <h1 class="h1"><span class="span">Fertilizer</span> Calculator</h1>
  <input type="number" id="size" placeholder="size in sqft" class="input">
<input type="text" id="N" placeholder="N in lbs" class="input">
<input type="text" id="P" placeholder="P in lbs" class="input">
<input type="text" id="K" placeholder="K in lbs" class="input">
<p  onclick="cal()" class="button1 btn1" style="text-align: center;" >Calculate</p>
</form>

  </div>

</div>



<div id="myModal7" class="modal">

  <!-- Modal content -->
  <div class="modal-content divpro">
    <span class="close">&times;</span>
    <form class="form"  enctype="multipart/form-data" method="POST" autocomplete="off">
  <h1 class="h1"><span class="span">Fertilizer</span> Calculator</h1>
<select id="CropType" class="input">
    <option>Corn</option>
    <option>Potatoes</option>
    <option>Onion</option>
    <option>Tomatoes</option>
</select>
<input type="number" id="size" placeholder="size in sqft" class="input">
<p  onclick="cal1()" class="button1 btn1" style="text-align: center;"  >Calculate</p>
</form>

  </div>

</div>


<div id="myModal8" class="modal">

  <!-- Modal content -->
  <div class="modal-content divpro">
    <span class="close">&times;</span>
    <form id="formCrop" class="form"  enctype="multipart/form-data" method="POST" autocomplete="off">
  <h1 class="h1"><span class="span">Crop</span> Suggestion</h1>
<input type="number" name="mon" placeholder="Starting Month" class="input" id="mon1">
	<input type="number" name="cultime" placeholder="Cultivation Time" class="input" id="cultime1">
	<input id="rain1" type="number" name="rain" placeholder="RainFalls" class="input">
	<input id="irrigation1" type="number" name="irrigation" placeholder="Irrigation" class="input">
	<select id="city1" name="city" class="input">
		<option>Attock</option>
		<option>Faisalabad</option>
		<option>Multan</option>
		<option>Peshawar</option>
		<option>Swabi</option>
	</select>
	<input id="soil1" type="number" name="soil" placeholder="Soil" class="input">
	<button type="submit" name="sub"  class="button1 btn1">Submit</button>
    <div id="wait" style="display:none;width:69px;height:89px;border:1px solid black;position:absolute;top:50%;left:50%;padding:2px;"><img src='img/core-img/load.gif' width="64" height="64" /><br>Loading..</div>
</form>

  </div>

</div>

<script type="text/javascript" src="js/jquery/jquery-2.2.4.min.js"></script>

<script type="text/javascript" >

$(document).ready(function() {
    $(document).ajaxStart(function(){
    //$("#wait").css("display", "block");
  });
  $(document).ajaxComplete(function(){
    //$("#wait").css("display", "none");
  });
  $("button").click(function(){
    $("#wait").css("display", "block");
    $("#txt").load("demo_ajax_load.asp");
  });

    $('#formCrop').on('submit', function(event) {
       if ($('#mon1').val().length>0 && $('#cultime1').val().length>0 && $('#rain1').val().length>0 && $('#irrigation1').val().length>0 && $('#city1').val().length>0 && $('#soil1').val().length>0 && $('#mon1').val()>=0 && $('#cultime1').val()>=0 && $('#rain1').val()>=0 && $('#irrigation1').val()>=0 && $('#soil1').val()>=0) {
        $.ajax({
            data : {
                mon : $('#mon1').val(),
                cultime : $('#cultime1').val(),
                rain : $('#rain1').val(),
                irrigation : $('#irrigation1').val(),
                city : $('#city1').val(),
                soil : $('#soil1').val()
            },
            type : 'POST',
            url : 'http://localhost:5000/Crop'
        })
        .done(function(data) {
            $("#wait").css("display", "none");
            if (data.error) {
                alert(data.error);
            }
            else {
                alert(data.name);
            }
        }).fail(function (data) {
            $("#wait").css("display", "none");
            alert('Server Not Working Try Again');
        });}
        else{
            $("#wait").css("display", "none");
                if ($('#mon1').val().length==0){
                        alert("Please Fill Starting Month Field");}
                else if ($('#cultime1').val().length==0){
                        alert("Please Fill Cultivation  Field");}

                else if ($('#rain1').val().length==0){
                        alert("Please Fill RainFalls Field");}
                else if ($('#irrigation1').val().length==0){
                       alert("Please Fill Irrigation Field");}
                else if ($('#soil1').val().length==0){
                    alert("Please Fill Soil Field");}
                else {
                    alert('Enter Zero or Greater than Zero')
                }
    }
        event.preventDefault();
    });
    
});
</script>

<script type="text/javascript">
        
function validateImage() {
    var formData = new FormData();
    var file = document.getElementById("img").files[0];
    formData.append("Filedata", file);
    var t = file.type.split('/').pop().toLowerCase();
    if (t != "jpeg" && t != "jpg" && t != "png" && t != "bmp" && t != "gif") {
        alert('Please select a valid image file extension');
        document.getElementById("img").value = '';
        return false;
    }
    if (file.size > 1024000) {
        alert('Max Upload size is 1MB only');
        document.getElementById("img").value = '';
        return false;
    }
    return true;
}

function validateImage1() {
    var formData = new FormData();
    var file = document.getElementById("img1").files[0];
    formData.append("Filedata", file);
    var t = file.type.split('/').pop().toLowerCase();
    if (t != "jpeg" && t != "jpg" && t != "png" && t != "bmp" && t != "gif") {
        alert('Please select a valid image file extension');
        document.getElementById("img1").value = '';
        return false;
    }
    if (file.size > 1024000) {
        alert('Max Upload size is 1MB only');
        document.getElementById("img1").value = '';
        return false;
    }
    return true;
}


function validateImage2() {
    var formData = new FormData();
    var file = document.getElementById("img2").files[0];
    formData.append("Filedata", file);
    var t = file.type.split('/').pop().toLowerCase();
    if (t != "jpeg" && t != "jpg" && t != "png" && t != "bmp" && t != "gif") {
        alert('Please select a valid image file extension');
        document.getElementById("img2").value = '';
        return false;
    }
    if (file.size > 1024000) {
        alert('Max Upload size is 1MB only');
        document.getElementById("img2").value = '';
        return false;
    }
    return true;
}
    

</script>


<?php
    if (isset($_POST['reg'])) {
        $con=mysqli_connect("localhost","root","","AgriPoint");
        echo $con->connect_error;
        $name=$_POST['uname'];
        $email=$_POST['email'];
        $pass=$_POST['password'];
        $cpass=$_POST['cpassword'];

        if ($pass==$cpass) {
            $query="INSERT INTO users(Name,Email,Password) 
            VALUES ('$name','$email','$pass')";
            if($con->query($query)){
                echo "<script>
                    alert('you have successfully register');
                </script>";
            }
        }
        else{
            echo "<script>
                alert('Password not Match');
            </script>";
        }

    }


    if (isset($_POST['log'])) {
        $con=mysqli_connect("localhost","root","","AgriPoint");
        echo $con->connect_error;
        $name=$_POST['email'];
        $pass=$_POST['pass'];
        $query="SELECT * FROM users WHERE Email='$name' AND Password='$pass'";
        $res=$con->query($query);
        if ($res->num_rows>0) {
            while ($row=$res->fetch_assoc()) {
                    $_SESSION['Name']=$row['Name'];
                    $_SESSION['Id']=$row['Id'];
                    
                    header("location:/Agri Point/templates/index.php");
                    ob_end_flush();
                }
        }
        else{
          echo " <script> alert('Incorrect UserName or Passowrd');</script>";
        }
    }


    if (isset($_POST['add_pro'])) {
        $con=mysqli_connect("localhost","root","","AgriPoint");
        echo $con->connect_error;
        $name=$_POST['OName'];
        $pname=$_POST['PName'];
        $pri=$_POST['price'];
        $cate=$_POST['cate'];
        $tag=$_POST['Tag'];
        $file_name= $_FILES['image']['name'];
      //$file_size = $_FILES['image']['size'];
      $file_tmp = $_FILES['image']['tmp_name'];
      // $file_type = $_FILES['image']['type'];
      // $file_e=explode('.', $file_name);
      // $file_ex=end($file_e);
      // $file_ext=strtolower($file_ex);
      // $extensions= array("jpeg","jpg","png");
      // if(in_array($file_ext,$extensions)=== false){
      //    echo "extension not allowed, please choose a JPEG or PNG file.";}
      // elseif ($file_size > 2097152) {
      //    echo 'File size must be excately 2 MB';}  
      // else {
         move_uploaded_file($file_tmp,"images/".$file_name);
         $id=$_SESSION['Id'];
         $query="INSERT INTO Products(Owner_Name,Product_Name,Price,Image,Category,SessionId,Tag) 
            VALUES ('$name','$pname','$pri','images/$file_name','$cate','$id','$tag')";
            if($con->query($query)){
                echo "<script>
                    alert('you have successfully add product');
                </script>";
         }
         else{
            echo "<script>
                alert('Sorry Try Again');
            </script>";
        }
        }
        


if (isset($_POST['add_ex'])) {
        $con=mysqli_connect("localhost","root","","AgriPoint");
        echo $con->connect_error;
        $name=$_POST['Name'];
        $exp=$_POST['exp'];
        $fe=$_POST['field'];
        $dis=$_POST['dis'];
        $file_name= $_FILES['image']['name'];
      //$file_size = $_FILES['image']['size'];
      $file_tmp = $_FILES['image']['tmp_name'];
      // $file_type = $_FILES['image']['type'];
      // $file_e=explode('.', $file_name);
      // $file_ex=end($file_e);
      // $file_ext=strtolower($file_ex);
      // $extensions= array("jpeg","jpg","png");
      // if(in_array($file_ext,$extensions)=== false){
      //    echo "extension not allowed, please choose a JPEG or PNG file.";}
      // elseif ($file_size > 2097152) {
      //    echo 'File size must be excately 2 MB';}  
      // else {
        $idfar=$_SESSION['Id'];
         move_uploaded_file($file_tmp,"images/".$file_name);
         $query="INSERT INTO farmer_experience(Name,Experience,Field,Discription,Image,Session_Id) 
            VALUES ('$name','$exp','$fe','$dis','images/$file_name','$idfar')";
            if($con->query($query)){
                echo "<script>
                    alert('you have successfully add information');
                </script>";
         }
         else{
            echo "<script>
                alert('Sorry Try Again');
            </script>";
        }
        }
  
if (isset($_POST['Lab_Info'])) {
        $con=mysqli_connect("localhost","root","","AgriPoint");
        echo $con->connect_error;
        $name=$_POST['LName'];
        $exp=$_POST['lexp'];
        $fe=$_POST['lfield'];
        $dis=$_POST['ldis'];
        $email=$_POST['LEmail'];
        $file_name= $_FILES['limage']['name'];
      $file_size = $_FILES['limage']['size'];
      $file_tmp = $_FILES['limage']['tmp_name'];
      $file_type = $_FILES['limage']['type'];
      $file_e=explode('.', $file_name);
      $file_ex=end($file_e);
      $file_ext=strtolower($file_ex);
     //  $extensions= array("jpeg","jpg","png");
     //  if(in_array($file_ext,$extensions)=== false){
     //     echo "<script>
     //                document.getElementById('laberror').innerHtml='extension not allowed, please choose a JPEG or PNG file.';
     //            </script>";
     // }
     //  elseif ($file_size > 2097152) {
     //     echo "<script>
     //                document.getElementById('laberror').innerHtml='File size must be excately 2 MB';
     //            </script>";
     //     }  
     //  else {
         move_uploaded_file($file_tmp,"images/".$file_name);
         $idfar=$_SESSION['Id'];
         $query="INSERT INTO Lab_Info(Name,Email,Experience,Field,Discription,Image,Session_Id) 
            VALUES ('$name','$email','$exp','$fe','$dis','images/$file_name',$idfar)";
            if($con->query($query)){
                echo "<script>
                    alert('You have successfully Add Your Information');
                </script>";
         }
         else{
            echo "<script>
                alert('Sorry Try Again');
            </script>";
        }
        }
  

  
    
?>
<script type="text/javascript" src="js/jquery/jquery-2.2.4.min.js"></script>


<script>


        $(document).ready(function(){
            loadMsg();
        });




        function loadMsg()
        {
            $.post('php/count.php', function(response){
                //alert(response);
                if (response!='') {
                var obj = JSON.parse(response);
                $('#numbf').text(obj[0].count); 
                $('#numbl').text(obj[1].count);
                var tot=obj[0].count+obj[1].count;
                $('#numb').text(tot);}
            });
        }


        setInterval(function(){
            loadMsg();
        }, 2000);

    </script>
    <!-- ##### All Javascript Files ##### -->
    <!-- jQuery-2.2.4 js -->
    <script src="js/jquery/jquery-2.2.4.min.js"></script>
    <!-- Popper js -->
    
    <script src="js/bootstrap/popper.min.js"></script>
    <!-- Bootstrap js -->
    <script src="js/bootstrap/bootstrap.min.js"></script>
    <!-- All Plugins js -->
    <script src="js/plugins/plugins.js"></script>
    <!-- Active js -->
    <script src="js/active.js"></script>

    <script src="js/modal.js"></script>
    <script type="text/javascript" src="js/calculator.js"></script>
</body>

</html>