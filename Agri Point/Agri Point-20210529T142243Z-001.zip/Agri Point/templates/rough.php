<!-- All Products Area -->
                <div class="col-12 col-md-8 col-lg-9">
                    <div class="shop-products-area" >
                        
                            
<?php
$dbhost = "localhost";
    $dbname = "agripoint";
    $dbuser = "root";
    $dbpass = "";


    try{
        $db=mysqli_connect($dbhost,$dbuser,$dbpass,$dbname);
    }catch(PDOException $e){
        echo $e->getMessage();
    }
    $a=$_REQUEST['id'];
    $query = "SELECT * from message1 WHERE Rec_Id='$a' group by Session_Id";
            $res=$db->query($query);
            if ($res->num_rows>0) {
                while ($row=$res->fetch_assoc())  {
                    $abc=$row['Session_Id'];
                    $query = "SELECT * from users WHERE Id='$abc'";
            $res1=$db->query($query);
            if ($res1->num_rows>0) {
                while ($row1=$res1->fetch_assoc())  {
                    $name=$row1['Name'];
                    $email=$row1['Email'];
                    echo "<div class='row'>
                    <div class='col-12 col-sm-6 col-lg-4'>
                    <div class='product-info mt-15 text-center'>
                    <a onclick='abc(".$abc.",".$a.")'><h3>".$name."</h3></a>
                    <a onclick='abc(".$abc.",".$a.")'><h5>".$email."</h5></a>
                    </div></div></div>";

                }}}}
?>

<script type="text/javascript">
    function abc(a,b) {
        // body...
    
    var val="?id="+a+"&fidd="+b;
        location.href='msg3.php'+val;}
</script>
                    
                           
                        </div>

                    </div>