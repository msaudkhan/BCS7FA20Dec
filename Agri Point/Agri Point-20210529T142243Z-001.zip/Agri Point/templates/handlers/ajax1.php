<?php
session_start();
include("../config.php");
$us=$_SESSION['Id'];
$query="SELECT * from users where Id='$us'";
			$res=$db->query($query);
			if ($res->num_rows>0) {
				while ($row=$res->fetch_assoc())  {
				$name=$row['Name']; 
}}
if( isset($_REQUEST['action']) ){


	switch( $_REQUEST['action'] ){
		


		case "SendMessage":
			 $me=$_REQUEST['message'];
			$rid=$_REQUEST['fid'];
			$ridd=$_REQUEST['fidd'];		 
			$query="SELECT * from farmer_experience where Id='$rid'";
			$res=$db->query($query);
			if ($res->num_rows>0) {
				while ($row=$res->fetch_assoc())  {
				$oid=$row['Session_Id']; 
}}
			$query = "INSERT INTO message(Rec_Id,Session_Id,Message,Session_Ido,Session_Name,SNId) values('$rid','$ridd','$me','$oid','$name','$us')";

			$db->query($query);

			echo 1;


		break;




		case "getChat":

			$rid=$_REQUEST['fid'];
			$ridd=$_REQUEST['id'];	

			$query = "SELECT * from message WHERE Session_Ido='$us' and Rec_Id='$rid' and
			Session_Id='$ridd' order by Id desc";
			$res=$db->query($query);
			if ($res->num_rows>0) {
				while ($row=$res->fetch_assoc())  {
				$chat ='';
				$abc=$row['Session_Name'];
				$abcd=$row['Message'];
				$chat=  '<div class="siglemessage"><strong>'.$abc.' says:  </strong>'.$abcd.'</div>';
				echo $chat;

			}

		
			}
			

			


		break;



	}


}


?>