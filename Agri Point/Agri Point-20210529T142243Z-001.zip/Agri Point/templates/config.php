<?php

	$dbhost = "localhost";
	$dbname = "agripoint";
	$dbuser = "root";
	$dbpass = "";


	try{
		$db=mysqli_connect($dbhost,$dbuser,$dbpass,$dbname);
	}catch(PDOException $e){
		echo $e->getMessage();
	}

	



?>