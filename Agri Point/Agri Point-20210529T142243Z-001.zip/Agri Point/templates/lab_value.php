<?php
session_start();

	
	$email=$_POST['email'];
	$pass=$_POST['pass'];
	$con=mysqli_connect("localhost","root","","AgriPoint");
        echo $con->connect_error;        
        $query="SELECT * FROM users WHERE Email='$email'";
        $re=$con->query($query);
        if ($re && $re->num_rows>0) {
            while ($row=$re->fetch_assoc()) {
            	if ($row['Password']==$pass) {
            		echo "correct";
            	}
            	else{
            		echo "password";
            	}
            }}
        else{
        	echo "email";
        }
	
?>