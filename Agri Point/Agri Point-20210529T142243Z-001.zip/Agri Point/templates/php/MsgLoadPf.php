<?php
session_start();
$value=array();
	$con=mysqli_connect("localhost","root","","AgriPoint");
        echo $con->connect_error;
        $a=$_REQUEST['id'];
        $query = "SELECT * , Max(Id) as t from message1  WHERE  Rec_Id='$a'  group by Session_Id order by t asc";
            $res=$con->query($query);
            if ($res->num_rows>0) {
                while ($row=$res->fetch_assoc())  {
                    $abc=$row['Session_Id'];
                    $query = "SELECT * from users WHERE Id='$abc'";
            $res1=$con->query($query);
            if ($res1->num_rows>0) {
                while ($row1=$res1->fetch_assoc())  {
                	$na=$row1['Name'];
                	$b=$row1['Email'];
                	$us=$_SESSION['Id'];
                	$query2 = "SELECT * from message1 WHERE Session_Ido='$us' and Rec_Id='$a' and
			Session_Id='$abc' and SNId!='$us' and status=0";
			$res2=$con->query($query2);
			if ($res2->num_rows>0) {
                $vall=$res2->num_rows;
                    $value[] = array('sid' => $abc, 'name' => $na, 'email' => $b, 'count' => $vall );

                }
            else{
                $query3 = "SELECT * from message1 WHERE Session_Ido='$us' and Rec_Id='$a' and
            Session_Id='$abc' and SNId!='$us'";
            $res3=$con->query($query3);
                if ($res3->num_rows>0) {
                    $value[] = array('sid' => $abc, 'name' => $na, 'email' => $b, 'count' => '0' );

                }
            }
            }
            }
        }
    }

$json = json_encode($value);
echo $json;
    ?>