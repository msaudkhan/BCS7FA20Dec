<?php
ob_start();
    session_start();
    $usid=$_SESSION['Id'];
    $id=$_REQUEST['fidd'];
    $idd=$_REQUEST['id'];
    $con=mysqli_connect("localhost","root","","AgriPoint");
    echo $con->connect_error;
    $query="UPDATE message1 set status='1' where Rec_Id='$id' and Session_Ido='$usid' and SNId!='$usid' and Session_Id='$idd'";
    $con->query($query)
?>