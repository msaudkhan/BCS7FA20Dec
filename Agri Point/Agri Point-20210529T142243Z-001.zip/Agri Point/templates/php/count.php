<?php
session_start();
$value=array();
if (isset($_SESSION['Id'])) {
$us=$_SESSION['Id'];
$con=mysqli_connect("localhost","root","","agripoint");
	echo $con->connect_error;
$sql="SELECT * from message where status=0 AND SNId != $us AND (Session_Id=$us OR Session_Ido=$us)";
$res=$con->query($sql);
if($res && $res->num_rows>0){
	$value[] = array('count' => $res->num_rows );}
else{
	$value[] = array('count' => "" );
}
$sql1="SELECT * from message1 where status=0 AND SNId != $us AND (Session_Id=$us OR Session_Ido=$us)";
$res1=$con->query($sql1);
if($res1 && $res1->num_rows>0){
	$value[] = array('count' => $res1->num_rows );}
else{
	$value[] = array('count' => "" );
}
	echo json_encode($value);
}


?>