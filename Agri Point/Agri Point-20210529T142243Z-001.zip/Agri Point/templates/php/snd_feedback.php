<?php
$data=[];  
 $con = mysqli_connect("localhost", "root", "", "AgriPoint"); 
 echo $con->connect_error; 
      $name=$_POST['name'];
      $email=$_POST['email'];
      $subject=$_POST['subject'];
      $message=$_POST['message'];
      $query = "INSERT into feedback (Name,Email,Subject,Message) values ('$name','$email','$subject','$message')";  
      if($con->query($query)){
      		$data['ans']="Your Feedback Successfully send";
		}
		else{
			$data['ans']="Try Again";
		} 

echo json_encode($data);   
 ?>