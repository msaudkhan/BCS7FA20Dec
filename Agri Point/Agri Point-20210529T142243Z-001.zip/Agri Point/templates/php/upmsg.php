<?php
ob_start();
    session_start();

    $usid=$_SESSION['Id'];
    $id=$_REQUEST['id'];
    $con=mysqli_connect("localhost","root","","AgriPoint");
    echo $con->connect_error;
    $query="UPDATE message set status='1' where Rec_Id='$id' and SNId!='$usid' and  (Session_Id='$usid' OR Session_Ido='$usid')";
    $con->query($query);
?>