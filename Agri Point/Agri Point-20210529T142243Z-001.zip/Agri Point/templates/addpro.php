<?php
	if (isset($_POST['sub'])) {
		$con = mysqli_connect("localhost", "root", "", "agripoint");
		echo $con->connect_error;
        $name=$_POST['name'];
        $type=$_POST['type'];
        $dis=$_POST['dis'];
        $file_name= $_FILES['image']['name'];
      $file_size = $_FILES['image']['size'];
      $file_tmp = $_FILES['image']['tmp_name'];
      $file_type = $_FILES['image']['type'];
      $file_e=explode('.', $file_name);
      $file_ex=end($file_e);
      $file_ext=strtolower($file_ex);
      $extensions= array("jpeg","jpg","png");
      if(in_array($file_ext,$extensions)=== false){
         echo "extension not allowed, please choose a JPEG or PNG file.";}
      elseif ($file_size > 2097152) {
         echo 'File size must be excately 2 MB';}  
      else {
         move_uploaded_file($file_tmp,"images/pro/".$file_name);
         $query="INSERT INTO information(Name,Type,Discription,Image) 
            VALUES ('$name','$type','$dis','images/pro/$file_name')";
            if($con->query($query)){
                echo "<script>
                    alert('you have successfully add Information of Product');
                </script>";
         }
         else{
            echo "<script>
                alert('Sorry Try Again');
            </script>";
        }
	}}
?>
<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
<form method="POST" enctype="multipart/form-data">
	<input type="text" name="name">
	<input type="text" name="type">
	<input type="file" name="image">
	<input type="text" name="dis">
	<input type="submit" name="sub">
</form>
</body>
</html>