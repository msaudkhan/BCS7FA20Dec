<?php

    $success = 0;
    $uploadedFile = '';
    
    //File upload path
    $uploadPath = 'images/';
    $targetPath = $uploadPath . basename( $_FILES['limage']['name']);

    if(@move_uploaded_file($_FILES['limage']['tmp_name'], $targetPath)){
        $success = 1;
        $uploadedFile = $targetPath;
    }
    sleep(1);
    exit();
?>
<script type="text/javascript">window.top.window.stopUpload();</script>
