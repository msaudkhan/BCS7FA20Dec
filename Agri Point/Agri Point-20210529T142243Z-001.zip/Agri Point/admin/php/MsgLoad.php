<?php
session_start();
$value=array();
	$con=mysqli_connect("localhost","root","","AgriPoint");
        echo $con->connect_error;
    $query="SELECT * FROM farmer_experience";
    $re=$con->query($query);
        if ($re && $re->num_rows>0) {
            while ($row=$re->fetch_assoc()) {
                $val=$row['Id'];
                $us=$_SESSION['Id'];
               
                    $sql="SELECT * from message where status=0 AND SNId != $us AND (Session_Id=$us OR Session_Ido=$us) AND Rec_Id=$val";
                                            $res=$con->query($sql);
                                            if($res->num_rows>0){
                                                $a=$res->num_rows;
                                                $value[] = array('id' => $val, 'count' => $a );
            }
        }       } 
$json = json_encode($value);
echo $json;
?>