<?php
session_start();
if (isset($_SESSION['37102-5456225-7'])) {

$con=mysqli_connect("localhost","root","","agripoint");
	echo $con->connect_error;
$sql="SELECT * from feedback where Status=1";
$res=$con->query($sql);
if($res && $res->num_rows>0){
	$value[] = array('count' => $res->num_rows );}
else{
	$value[] = array('count' => "" );
}

	echo json_encode($value);
}
	else{
		$value[] = array('count' => "" );
		echo json_encode($value);
	}
?>