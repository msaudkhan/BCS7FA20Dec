<?php
	$con=mysqli_connect("localhost","root","","AgriPoint");
        echo $con->connect_error;
	$id=$_GET['id'];
	$query="DELETE FROM products WHERE Id='$id'";
        $con->query($query);
?>