<?php
	$dbhost = "localhost";
	$dbname = "AgriPoint";
	$dbuser = "root";
	$dbpass = "";


	try{
		$db=mysqli_connect($dbhost,$dbuser,$dbpass,$dbname);
	}catch(PDOException $e){
		echo $e->getMessage();
	}
?>