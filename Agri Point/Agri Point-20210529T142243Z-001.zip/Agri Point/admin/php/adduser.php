<?php
	
	if (isset($_POST['reg'])) {
		$con=mysqli_connect("localhost","root","","AgriPoint");
		echo $con->connect_error;
		$name=$_POST['uname'];
		$email=$_POST['email'];
		$pass=$_POST['password'];
		$cpass=$_POST['cpassword'];

		if ($pass==$cpass) {
			$query="INSERT INTO users(Name,Email,Password) 
			VALUES ('$name','$email','$pass')";
			$con->query($query);
		}
		else{
			echo "Password not Match";
		}

	}
?>