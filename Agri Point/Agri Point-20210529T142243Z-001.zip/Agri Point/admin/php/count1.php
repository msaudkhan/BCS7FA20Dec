<?php
session_start();
if (isset($_SESSION['Id'])) {
$id=$_REQUEST['proid'];
$us=$_SESSION['Id'];
$con=mysqli_connect("localhost","root","","agripoint");
	echo $con->connect_error;
	$a;
$sql="SELECT * from message where status=0 AND SNId != $us AND (Session_Id=$us OR Session_Ido=$us) AND Rec_Id=$id";
$res=$con->query($sql);
if($res->num_rows>0){
	$a=$res->num_rows;
	echo json_encode($a);
exit();
}}
?>