<?php
ob_start();
    session_start();
    $con=mysqli_connect("localhost","root","","AgriPoint");
    echo $con->connect_error;
    $query="UPDATE feedback set status='0'";
    $con->query($query);

?>