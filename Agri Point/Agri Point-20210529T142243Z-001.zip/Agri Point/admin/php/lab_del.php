<?php
	$con=mysqli_connect("localhost","root","","AgriPoint");
        echo $con->connect_error;
	$id=$_GET['id'];
	$query="DELETE FROM lab_info WHERE Id='$id'";
        $con->query($query);
    $query1="UPDATE message1 set Status='1' where Rec_Id='$id'";
    $con->query($query1);
?>