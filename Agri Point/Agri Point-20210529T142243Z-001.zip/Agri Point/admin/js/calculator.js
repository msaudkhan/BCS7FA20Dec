function cal() {
		var crop=document.getElementById('CropType').value;
		var size=document.getElementById('size').value;
		var s=parseFloat(size);
		if (crop=="Corn") {
			var N=s*0.001722;
			var P=s*0.001148;
			var K=s*0.000574;
			CalFer(N,P,K);
		}

		if (crop=="Potatoes") {
			var N=s*0.002066;
			var P=s*0.002124;
			var K=s*0.002812;
			CalFer(N,P,K);	
		}

		if (crop=="Onion") {
			var N=s*0.000689;
			var P=s*0.001607;
			var K=s*0.002640;
			CalFer(N,P,K);	
		}

		if (crop=="Tomatoes") {
			var N=s*0.001607;
			var P=s*0.001377;
			var K=s*0.003214;
			CalFer(N,P,K);	
		}		

	}

	function CalFer(a,b,c) {
		var size=document.getElementById('size').value;
		var h=size*0.0000092903;
		var MOP=((100/60)*c)*h;
		var dapp=((100/46)*b);
		var dapn=((18/100)*dapp);
		a=a-dapn;
		var urea=((100/46)*a)*h;
		alert("MOP:\n"+MOP+" kg\nDAP:\n"+dapn*h+"kg\nUrea:\n"+urea+" kg");
	}





	function cal1() {
		var size=document.getElementById('size').value;
		var N=document.getElementById('N').value;
		var P=document.getElementById('P').value;
		var K=document.getElementById('K').value;
		CalFer(N,P,K);
	}

	function CalFer(a,b,c) {
		var size=document.getElementById('size').value;
		var h=size*0.0000092903;
		var MOP=((100/60)*c)*h;
		var dapp=((100/46)*b);
		var dapn=((18/100)*dapp);
		a=a-dapn;
		var urea=((100/46)*a)*h;
		alert("MOP:\n"+MOP+" kg\nDAP:\n"+dapn*h+"kg\nUrea:\n"+urea+" kg");
	}