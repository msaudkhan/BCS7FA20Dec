// Get the modal
var modal = document.getElementById("myModal");
var modal1 = document.getElementById("myModal1");
var modal2 = document.getElementById("myModal2");
var modal3 = document.getElementById("myModal3");
var modal4 = document.getElementById("myModal4");
var modal5 = document.getElementById("myModal5");
var modal6 = document.getElementById("myModal6");
var modal7 = document.getElementById("myModal7");
var modal8 = document.getElementById("myModal8");
// Get the button that opens the modal
var pro = document.getElementById("myBtn");
var p = document.getElementById("logi");
var p1 = document.getElementById("logi1");
var p2 = document.getElementById("logi2");
var p3 = document.getElementById("logi3");
var p4 = document.getElementById("logi4");
var p5 = document.getElementById("logi5");
var p6 = document.getElementById("logi6");
var btn1 = document.getElementById("shop");
var btn_log = document.getElementById("login");
var signup_cl = document.getElementById("signup");
var far_exp = document.getElementById("far");
var lab = document.getElementById("lab");
var WithNPK = document.getElementById("withoutnpk");
var WithoutNpk = document.getElementById("withnpk");
var sug = document.getElementById("sug");

// Get the <span> element that closes the modal
var span = document.getElementsByClassName("close")[0];
var span1 = document.getElementsByClassName("close")[1];
var span2 = document.getElementsByClassName("close")[2];
var span3 = document.getElementsByClassName("close")[3];
var span4 = document.getElementsByClassName("close")[4];
var span5 = document.getElementsByClassName("close")[5];
var span6 = document.getElementsByClassName("close")[6];
var span7 = document.getElementsByClassName("close")[7];
var span8 = document.getElementsByClassName("close")[8];
// When the user clicks the button, open the modal 

if (btn1!=null) {
btn1.onclick = function() {
	modal.style.display = "none";
	modal4.style.display = "none";
	modal5.style.display = "none";
	modal2.style.display = "none";
	modal3.style.display = "none";
  	modal1.style.display = "block";
  	modal6.style.display="none";
  	modal7.style.display="none";
  	modal8.style.display = "none";
}}
if (btn_log!=null) {
btn_log.onclick = function() {
	modal1.style.display = "none";
	modal.style.display = "none";
	modal4.style.display = "none";
	modal5.style.display = "none";
	modal3.style.display = "none";
  	modal2.style.display = "block";
  	modal6.style.display="none";
  	modal7.style.display="none";
  	modal8.style.display = "none";
}}
if (p!=null) {
p.onclick = function() {
	modal1.style.display = "none";
	
	modal.style.display = "none";
	modal4.style.display = "none";
	modal5.style.display = "none";
	modal3.style.display = "none";
  	modal2.style.display = "block";
  	modal6.style.display="none";
  	modal7.style.display="none";
  	modal8.style.display = "none";
}}

if (p1!=null) {
p1.onclick = function() {
	modal1.style.display = "none";
	
	modal.style.display = "none";
	modal4.style.display = "none";
	modal5.style.display = "none";
	modal3.style.display = "none";
  	modal2.style.display = "block";
  	modal6.style.display="none";
  	modal7.style.display="none";
  	modal8.style.display = "none";
}}
if (p2!=null) {
p2.onclick = function() {
	modal1.style.display = "none";
	
	modal.style.display = "none";
	modal4.style.display = "none";
	modal5.style.display = "none";
	modal3.style.display = "none";
  	modal2.style.display = "block";
  	modal6.style.display="none";
  	modal7.style.display="none";
  	modal8.style.display = "none";
}}
if (p3!=null) {
p3.onclick = function() {
	modal1.style.display = "none";
	
	modal.style.display = "none";
	modal4.style.display = "none";
	modal5.style.display = "none";
	modal3.style.display = "none";
  	modal2.style.display = "block";
  	modal6.style.display="none";
  	modal7.style.display="none";
  	modal8.style.display = "none";
}}

if (p4!=null) {
p4.onclick = function() {
	modal1.style.display = "none";
	
	modal.style.display = "none";
	modal4.style.display = "none";
	modal5.style.display = "none";
	modal3.style.display = "none";
  	modal2.style.display = "block";
  	modal6.style.display="none";
  	modal7.style.display="none";
  	modal8.style.display = "none";
}}

if (p5!=null) {
p5.onclick = function() {
	modal1.style.display = "none";
	
	modal.style.display = "none";
	modal4.style.display = "none";
	modal5.style.display = "none";
	modal3.style.display = "none";
  	modal2.style.display = "block";
  	modal6.style.display="none";
  	modal7.style.display="none";
  	modal8.style.display = "none";
}}


if (p6!=null) {
p6.onclick = function() {
	modal1.style.display = "none";
	
	modal.style.display = "none";
	modal4.style.display = "none";
	modal5.style.display = "none";
	modal3.style.display = "none";
  	modal2.style.display = "block";
  	modal6.style.display="none";
  	modal7.style.display="none";
  	modal8.style.display = "none";
}}

if (signup_cl!=null) {
signup_cl.onclick = function() {
	modal1.style.display = "none";
	modal2.style.display = "none";
	modal4.style.display = "none";
	modal5.style.display = "none";
	modal.style.display = "none";
  	modal3.style.display = "block";
  	modal6.style.display="none";
  	modal7.style.display="none";
  	modal8.style.display = "none";
}}
if (pro!=null) {
pro.onclick = function() {
	modal1.style.display = "none";
	modal2.style.display = "none";
	modal4.style.display = "none";
	modal5.style.display = "none";
	modal3.style.display = "none";
  	modal.style.display = "block";
  	modal6.style.display="none";
  	modal7.style.display="none";
  	modal8.style.display = "none";
}
}
if (far_exp!=null) {
far_exp.onclick = function() {
	modal1.style.display = "none";
	modal2.style.display = "none";
	modal4.style.display = "block";
	modal5.style.display = "none";
	modal3.style.display = "none";
  	modal.style.display = "none";
  	modal6.style.display="none";
  	modal7.style.display="none";
  	modal8.style.display = "none";
}}
if (lab!=null) {
lab.onclick = function() {
	modal1.style.display = "none";
	modal2.style.display = "none";
	modal4.style.display = "none";
	modal.style.display = "none";
	modal3.style.display = "none";
  	modal5.style.display = "block";
  	modal6.style.display="none";
  	modal7.style.display="none";
  	modal8.style.display = "none";
}
}

if (withnpk!=null) {
withnpk.onclick = function() {
	modal1.style.display = "none";
	modal2.style.display = "none";
	modal4.style.display = "none";
	modal.style.display = "none";
	modal3.style.display = "none";
  	modal5.style.display = "none";
  	modal6.style.display="none";
  	modal7.style.display="block";
  	modal8.style.display = "none";
}}

if (withoutnpk!=null) {
withoutnpk.onclick = function() {
	modal1.style.display = "none";
	modal2.style.display = "none";
	modal4.style.display = "none";
	modal.style.display = "none";
	modal3.style.display = "none";
  	modal5.style.display = "none";
  	modal6.style.display = "block";
  	modal8.style.display="none";
  	modal7.style.display="none";
}}
if (sug!=null) {
sug.onclick = function() {
	modal1.style.display = "none";
	modal2.style.display = "none";
	modal4.style.display = "none";
	modal.style.display = "none";
	modal3.style.display = "none";
  	modal5.style.display = "none";
  	modal6.style.display = "none";
  	modal8.style.display="block";
  	modal7.style.display="none";
}}
// When the user clicks on <span> (x), close the modal
span.onclick = function() {
  modal.style.display = "none";
}
span1.onclick = function() {
  modal2.style.display = "none";
}
span2.onclick = function() {
  modal1.style.display = "none";
}

span3.onclick = function() {
  modal3.style.display = "none";
}
span4.onclick = function() {
  modal4.style.display = "none";
}
span5.onclick = function() {
  modal5.style.display = "none";
}
span6.onclick = function() {
  modal6.style.display = "none";
}
span7.onclick = function() {
  modal7.style.display = "none";
}
span8.onclick = function() {
  modal8.style.display = "none";
}
