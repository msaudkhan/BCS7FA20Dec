<?php
ob_start();
    session_start();
?>
<script type="text/javascript" src="js/jquery/jquery-2.2.4.min.js"></script>


<script>
$(document).ready(function(){
            loadMsg();
        });




        function loadMsg()
        {
            $.post('php/count.php', function(response){
                //alert(response);
                if (response!='') {
                var obj = JSON.parse(response);
                $('#numb').text(obj[0].count); 
                }
            });
        }


        setInterval(function(){
            loadMsg();
        }, 2000);
</script>
<!DOCTYPE html>
<html>

<head>
    <meta charset="UTF-8">
    <meta name="description" content="">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <!-- The above 4 meta tags *must* come first in the head; any other head content must come *after* these tags -->

    <!-- Title -->
    <title>Agri Point</title>

    <!-- Favicon -->
    <link rel="icon" href="img/core-img/favicon.ico">
      
    <!-- Core Stylesheet -->
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" type="text/css" href="ModalStyle.css">
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Amiri&display=swap" rel="stylesheet">
    
    <style type="text/css">

        body{
            font-family: 'Amiri', serif;
        }
        .dropdown-content {
  display: none;
  position: absolute;
}

.dropdown:hover .dropdown-content {display: block;}




    </style>

</head>

<body>
    <!-- Preloader -->
    <div class="preloader d-flex align-items-center justify-content-center">
        <div class="preloader-circle"></div>
        <div class="preloader-img">
            <img src="img/core-img/leaf.png" alt="">
        </div>
    </div>

    <!-- ##### Header Area Start ##### -->
    <header class="header-area">

        <!-- ***** Top Header Area ***** -->
        <div class="top-header-area">
            <div class="container">
                <div class="row">
                    <div class="col-12">
                        <div class="top-header-content d-flex align-items-center justify-content-between">
                            <!-- Top Header Content -->
                            <div class="top-header-meta">
                                <a href="#" data-toggle="tooltip" data-placement="bottom" title="infoagripoint@gmail.com"><i class="fa fa-envelope-o" aria-hidden="true"></i> <span>Email: infoagripoint@gmail.com</span></a>
                                <a href="#" data-toggle="tooltip" data-placement="bottom" title="+9257 2741540"><i class="fa fa-phone" aria-hidden="true"></i> <span>Call Us: +9257 2741540</span></a>
                            </div>

                            <!-- Top Header Content -->
                            <div class="top-header-meta d-flex">
                                <!-- Language Dropdown -->
                                <div class="language-dropdown">
                                    <div class="dropdown">
                                        <button class="btn btn-secondary dropdown-toggle mr-30" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">زبان </button>
                                        <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                                            <a class="dropdown-item" href="#">اردو </a>
                                            
                                        </div>
                                    </div>
                                </div>
                                <!-- Login -->
                                <?php if(isset($_SESSION['37102-5456225-7'])){ ?>
                                    <div class="login dropdown" >
                                    <a href="#"><i class="fa fa-user" aria-hidden="true"></i> <span><?php echo $_SESSION['37102-5456225-7']; ?></span></a>
                                    <div class="dropdown-content">
                                    <a href="logout.php" style="text-te">Logout</a></div>
                                </div>
                                <?php }else{ ?>
                                    <div class="login" onclick="log()">
                                    <a href="#"><i class="fa fa-user" aria-hidden="true"></i> <span>لاگ ان </span></a>
                                </div>
                                <?php }?>
                                <!-- Cart -->
                                <div class="cart">
                                    <a><i class="fa fa-shopping-cart" aria-hidden="true"></i> <span>Admin</span></a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- ***** Navbar Area ***** -->
        <div class="alazea-main-menu">
            <div class="classy-nav-container breakpoint-off">
                <div class="container">
                    <!-- Menu -->
                    <nav class="classy-navbar justify-content-between" id="alazeaNav">

                        <!-- Nav Brand -->
                        <a href="index.php" class="nav-brand"><img src="img/core-img/logo.png" alt=""></a>

                        <!-- Navbar Toggler -->
                        <div class="classy-navbar-toggler">
                            <span class="navbarToggler"><span></span><span></span><span></span></span>
                        </div>

                        <!-- Menu -->
                        <div class="classy-menu">

                            <!-- Close Button -->
                            <div class="classycloseIcon">
                                <div class="cross-wrap"><span class="top"></span><span class="bottom"></span></div>
                            </div>

                            <!-- Navbar Start -->
                            <div class="classynav">
                                <ul>
                                    <li><a href="index.php">ہوم </a></li>
                                    <li><a> پروڈکٹ  </a>
                                        <ul class="dropdown">
                                            <?php if (isset($_SESSION['37102-5456225-7'])) {
                                        echo "
                                           <li> <a id='addinfo' onclick='addinfo()'> انسرٹ پروڈکٹ</a></li>
                                            <li><a href='aproduct.php'> ویو پروڈکٹ</a></li>";}
                                            else{
                                                echo "
                                           <li> <a  onclick='log()'> انسرٹ پروڈکٹ</a></li>
                                            <li><a onclick='log()'> ویو پروڈکٹ</a></li>";
                                            }?>
                                        </ul>
                                    </li>
                                    <?php if (isset($_SESSION['37102-5456225-7'])) {
                                        echo "
                                    <li><a href='farmer.php'> فارمر  </a></li>
                                    <li><a href='labour.php'> لیبر  </a></li>
                                        
                                    
                                    <li><a href='shop.php'> شاپ   </a></li>
                                    
                                    <li><a href='feedback.php'> فیڈ بیک   <span id='numb' ></span> </a></li><li><a href='user.php'> یوزر </a></li>";
                                    
                                        }
                                    else{
                                        echo "
                                    <li><a onclick='log()'> فارمر  </a></li>
                                    <li><a onclick='log()'> لیبر  </a></li>
                                        
                                    
                                    <li><a onclick='log()'> شاپ   </a></li>
                                    
                                    <li><a onclick='log()'> فیڈ بیک   <span id='numb' ></span> </a></li>
                                    <li><a onclick='log()'> یوزر </a></li>"; }
                                ?>
                                    
                                
                                </ul>
                                <!-- Search Icon -->
                                <div id="searchIcon">
                                    <i class="fa fa-search" aria-hidden="true"></i>
                                </div>

                            </div>
                            <!-- Navbar End -->
                        </div>
                    </nav>

                    <!-- Search Form -->
                    <div class="search-form">
                        <form action="#" method="get">
                            <input type="search" name="search" id="search" placeholder="Type keywords &amp; press enter...">
                            <button type="submit" class="d-none"></button>
                        </form>
                        <!-- Close Icon -->
                        <div class="closeIcon"><i class="fa fa-times" aria-hidden="true"></i></div>
                    </div>
                </div>
            </div>
        </div>
    </header>
    <!-- ##### Header Area End ##### -->


    <!-- ##### Hero Area Start ##### -->
    <section class="hero-area">
        <div class="hero-post-slides owl-carousel">

            <!-- Single Hero Post -->
            <div class="single-hero-post bg-overlay">
                <!-- Post Image -->
                <div class="slide-img bg-img" style="background-image: url(img/bg-img/1.jpg);"></div>
                <div class="container h-100">
                    <div class="row h-100 align-items-center">
                        <div class="col-12">
                            <!-- Post Content -->
                            <div class="hero-slides-content text-center">
                                <h2>Agriculture manufactures, commerce and navigation, the four pillars of our prosperity, are the most thriving when left most free to individual enterprise.</h2>
                                
                                </div>
                            </div>
                        </div>
                        
                    </div>
                </div>
            

            <!-- Single Hero Post -->
            <div class="single-hero-post bg-overlay">
                <!-- Post Image -->
                <div class="slide-img bg-img" style="background-image: url(img/bg-img/2.jpg);"></div>
                <div class="container h-100">
                    <div class="row h-100 align-items-center">
                        <div class="col-12">
                            <!-- Post Content -->
                            <div class="hero-slides-content text-center">
                                <h2>Agriculture manufactures, commerce and navigation, the four pillars of our prosperity, are the most thriving when left most free to individual enterprise.</h2>
                                
                                </div>
                                </div>
                            </div>
                        </div>

                    </div>
                </div>
            </div>
            
        </div>
    </section>
    <!-- ##### Hero Area End ##### -->
    	 
    <!-- ##### Portfolio Area Start ##### -->
    <section class="alazea-portfolio-area section-padding-100-0">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <!-- Section Heading -->
                    <div class="section-heading text-center">
                        <h2>پروڈکٹ</h2>
                        <p>ہر قسم کی مصنوعات کے بارے میں معلومات حاصل کریں</p>
                    </div>
                </div>
            </div>
        </div>

        <div class="container-fluid">
            <div class="row">
                <div class="col-12">
                    <div class="alazea-portfolio-filter">
                        <div class="portfolio-filter">
                            <button class="btn active" data-filter=".درخت "> درخت </button>
                            <button class="btn" data-filter=".پودے  "> پودے  </button>
                            <button class="btn" data-filter=".سبزی "> سبزی </button>
                            <button class="btn" data-filter=".پھل "> پھل </button>
                            <button class="btn" data-filter="*">سب کچھ </button>
                        </div>
                    </div>
                </div>
            </div>

            <div class="row alazea-portfolio">

                <?php
                    $con = mysqli_connect("localhost", "root", "", "agripoint");
                    echo $con->connect_error;
                    $query="SELECT * from information LIMIT 8";
                    $res=$con->query($query);
                    if ($res->num_rows>0) {
                        while ($row=$res->fetch_assoc()) {
                            $id=$row['Id'];
                            echo "<!-- Single Portfolio Area -->
                <div class='col-12 col-sm-6 col-lg-3 single_portfolio_item ".$row['Type']." wow fadeInUp' data-wow-delay='100ms' onclick='popupInfo(".$id.")'>
                    <!-- Portfolio Thumbnail -->
                    <div class='portfolio-thumbnail bg-img' style='background-image: url(".$row['Image'].");'></div>
                    <!-- Portfolio Hover Text -->
                    <div class='portfolio-hover-overlay'>
                        <a class='d-flex align-items-center justify-content-center'>
                            <div class='port-hover-text'>
                                <h3>".$row['Name']."</h3>
                                <h5>".$row['Type']."</h5>
                            </div>
                        </a>
                    </div>
                </div>
<div id='".$id."' class='modal'>

  <!-- Modal content -->
  <div class='modal-content divpro'>
    <span  onclick='closemod(".$id.")' class='close1'>&times;</span>
  <h1 class='h1'><span class='span'>Details</span> Of Products</h1>
  <p>".$row['Discription']."</p>

  </div>

</div>
                ";
                        }
                    }
                ?>

                

            </div>
        </div>
    </section>
    <!-- ##### Portfolio Area End ##### -->
<script type="text/javascript">
    function popupInfo(idinfo){
        document.getElementById(idinfo).style.display='block';
    }
    function closemod(idinfo){
        document.getElementById(idinfo).style.display='none';
    }
</script>
 <!-- ##### Product Area Start ##### -->
    <section class="new-arrivals-products-area bg-gray section-padding-100">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <!-- Section Heading -->
                    <div class="section-heading text-center">
                        <h2>NEW ARRIVALS</h2>
                        <p>ہمارے پاس جدید ترین مصنوعات ہیں ، یہ آپ کے لئے دلچسپ ہوگا</p>
                    </div>
                </div>
            </div>


            <div class="row">
<!-- Single Product Area -->
        <?php
        $con=mysqli_connect("localhost","root","","AgriPoint");
        echo $con->connect_error;        
        $query="SELECT * FROM products ORDER BY Id DESC LIMIT 4";
        $re=$con->query($query);
        if ($re && $re->num_rows>0) {
            while ($row=$re->fetch_assoc()) {
                $img=$row['Image'];
                $na=$row['Product_name'];
                $tag=$row['Tag'];
                $pri=$row['Price'];
                $val=$row['Id'];
                echo "
                <div class='col-12 col-sm-6 col-lg-3'>
                    <div class='single-product-area1 mb-50 wow fadeInUp' data-wow-delay='100ms'>
                        <!-- Product Image -->
                        <div class='product-img1'>
                            <a ><img src='".$img."' alt=''></a>
                            <!-- Product Tag -->
                            <div class='product-tag'>";
                                            if ($tag!="None") {
                                                echo "
                                            <a href='#'>".$tag."</a>";
                                            }
                                            echo "
                            </div>
                            <div class='product-meta d-flex'>
                                
                                <a";if(isset($_SESSION['37102-5456225-7'])){ echo " onclick='pro_del(".$val.")'";}echo " class='add-to-cart-btn'>Delete</a>
                            </div>
                        </div>
                        <!-- Product Info -->
                        <div class='product-info mt-15 text-center'>
                            <a>
                                <p>".$na."</p>
                            </a>
                            <h6>".$pri."</h6>
                        </div>
                    </div>
                </div>";}}?>

                <div class="col-12 text-center">
                    <a href="shop.php" class="btn alazea-btn"> ویو آل </a>
                </div>

            </div>
        </div>
    </section>
    <script type="text/javascript">
    
       function pro_del(a){
            if (confirm("Delete!")) {
                 if (window.XMLHttpRequest) {
                xmlhttp = new XMLHttpRequest();
                       } else
                 {
                    xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
                       }
                        xmlhttp.onreadystatechange = function() {
                      if (this.readyState == 4 && this.status == 200)
                        {   
                                 
                            window.location.href="shop.php";
                            }
                                };
                              xmlhttp.open("GET","php/pro_del.php?id="+a,true);       xmlhttp.send();    }
            
            else{

            }}</script>
    <!-- ##### Footer Area Start ##### -->
    <footer class="footer-area bg-img" style="background-image: url(img/bg-img/3.jpg);">
        <!-- Main Footer Area -->
        <div class="main-footer-area">
            <div class="container">
                <div class="row">

                    <!-- Single Footer Widget -->
                    <div class="col-12 col-sm-6 col-lg-3">
                        <div class="single-footer-widget">
                            <div class="footer-logo mb-30">
                                <a href="#"><img src="img/core-img/logo.png" alt=""></a>
                            </div>
                            <p>زراعت مینوفیکچر کی بنیاد ہے ، چونکہ قدرت کی تیاری ہی آرٹ کا سامان ہے۔</p>
                            <div class="social-info">
                                <a href="#"><i class="fa fa-facebook" aria-hidden="true"></i></a>
                                <a href="#"><i class="fa fa-twitter" aria-hidden="true"></i></a>
                                <a href="#"><i class="fa fa-google-plus" aria-hidden="true"></i></a>
                                <a href="#"><i class="fa fa-instagram" aria-hidden="true"></i></a>
                                <a href="#"><i class="fa fa-linkedin" aria-hidden="true"></i></a>
                            </div>
                        </div>
                    </div>

                    <!-- Single Footer Widget -->
                    <div class="col-12 col-sm-6 col-lg-3">
                        <div class="single-footer-widget">
                            <div class="widget-title">
                                <h5> کوئیک لنک </h5>
                            </div>
                            <nav class="widget-nav">
                                <ul>
                                    <li><a href="#">خریداری  </a></li>
                                    <li><a href="#">FAQs</a></li>
                                    <li><a href="#">    پیمنٹس </a></li>
                                    <li><a href="#">  نیوز </a></li>
                                    <li><a href="#">  ریٹرن </a></li>
                                    <li><a href="#">  اشتہار </a></li>
                                    <li><a href="#"> شپنگ </a></li>
                                    <li><a href="#">  کیریئر </a></li>
                                    <li><a href="#">    آرڈرز </a></li>
                                    <li><a href="#"> پالیسیز   </a></li>
                                </ul>
                            </nav>
                        </div>
                    </div>

                    <!-- Single Footer Widget -->
                    <div class="col-12 col-sm-6 col-lg-3">
                        <div class="single-footer-widget">
                            <div class="widget-title">
                                <h5> بیسٹ سیلر </h5>
                            </div>
 <?php
        $con=mysqli_connect("localhost","root","","AgriPoint");
        echo $con->connect_error;        
        $query="SELECT * FROM buy ORDER BY Price DESC LIMIT 2";
        $re=$con->query($query);
        if ($re && $re->num_rows>0) {
            while ($row=$re->fetch_assoc()) {
                $img=$row['Image'];
                $na=$row['Product_Name'];
                $pri=$row['Price'];
                echo "
                            <!-- Single Best Seller Products -->
                            <div class='single-best-seller-product d-flex align-items-center'>
                                <div class='product-thumbnail'>
                                    <a ><img src='".$img."' alt=''></a>
                                </div>
                                <div class='product-info'>
                                    <a >".$na."</a>
                                    <p>".$pri."</p>
                                </div>
                            </div>";}}?>

                            
                        </div>
                    </div>

                    <!-- Single Footer Widget -->
                    <div class="col-12 col-sm-6 col-lg-3">
                        <div class="single-footer-widget">
                            <div class="widget-title">
                                <h5> رابطہ </h5>
                            </div>

                            <div class="contact-information">
                                <p><span>Address:</span> comsats یونیورسٹی اٹک کیمپس </p>
                                <p><span>Phone:</span> +9257 2741540</p>
                                <p><span>Email:</span> infoagripoint@gmail.com</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Footer Bottom Area -->
        <div class="footer-bottom-area">
            <div class="container">
                <div class="row">
                    <div class="col-12">
                        <div class="border-line"></div>
                    </div>
                    <!-- Copywrite Text -->
                    <div class="col-12 col-md-6">
                        <div class="copywrite-text">
                            <p> <a target="_blank" href="index.php">AGRI POINT</a></p>
                        </div>
                    </div>
                    <!-- Footer Nav -->
                    <div class="col-12 col-md-6">
                        <div class="footer-nav">
                            <nav>
                                <ul>
                                    <li><a href="index.php">  ہوم </a></li>
                                    <li><a href="index.php">  پروڈکٹ </a></li>
                                    <li><a href="shop.php">  شاپ    </a></li>
                                    <li><a href="contact.php"> ہم سے رابطہ کریں </a></li>
                                    <li><a href="about.php">ہمارے بارے میں</a></li>
                                </ul>
                            </nav>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </footer>
    <!-- ##### Footer Area End ##### -->


<div id="myModal" class="modal">

  <!-- Modal content -->
  <div class="modal-content divpro">
  	<span class="close" onclick="close1()">&times;</span>
    <form class="form" enctype="multipart/form-data" method="POST">
  <h1 class="h1"><span class="span">Add</span> Product Information</h1>
  <input class="input" placeholder="Name" type="text" name="Name" >
  <select name="type" class="input">
      <option> درخت    </option>
      <option> پودے   </option>
      <option>سبزی   </option>
      <option>   پھل  </option>
  </select>
  <input class="input" type="text"  placeholder="Discription" name="dis"/>
  <input class="input" type="file" name="image" id="img2" onchange="validateImage()">

  <button name="add_pro" class="btn1 button1">Add Information</button>
</form>

  </div>

</div>




<script type="text/javascript">
        
function validateImage() {
    var formData = new FormData();
    var file = document.getElementById("img2").files[0];
    formData.append("Filedata", file);
    var t = file.type.split('/').pop().toLowerCase();
    if (t != "jpeg" && t != "jpg" && t != "png" && t != "bmp" && t != "gif") {
        alert('Please select a valid image file extension');
        document.getElementById("img2").value = '';
        return false;
    }
    if (file.size > 1024000) {
        alert('Max Upload size is 1MB only');
        document.getElementById("img2").value = '';
        return false;
    }
    return true;
}
    
function addinfo() {
    document.getElementById('myModal').style.display='block';

}
function close1() {
    document.getElementById('myModal').style.display='none';
}
function log() {
    document.getElementById('myModal2').style.display='block';

}
function close2() {
    document.getElementById('myModal2').style.display='none';
}
</script>


<?php
    
    if (isset($_POST['add_pro'])) {
        $con=mysqli_connect("localhost","root","","AgriPoint");
        echo $con->connect_error;
        $name=$_POST['Name'];
        $pname=$_POST['type'];
        $pri=$_POST['dis'];
        $file_name= $_FILES['image']['name'];
        $file_tmp = $_FILES['image']['tmp_name'];
         move_uploaded_file($file_tmp,"images/".$file_name);
         $id=$_SESSION['Id'];
         $query="INSERT INTO information(Name,Type,Discription,Image) 
            VALUES ('$name','$pname','$pri','../admin/images/$file_name')";
            if($con->query($query)){
                echo "<script>
                    alert('Added Product Information');
                </script>";
         }
         else{
            echo "<script>
                alert('Sorry Try Again');
            </script>";
        }
        }
        


  
    
?>

<div id="myModal2" class="modal">

  <!-- Modal content -->
  <div class="modal-content divpro">
    <span class="close" onclick="close2()">&times;</span>
    <form class="form" enctype="multipart/form-data" method="POST" name="login_form">
        <h1 class="h1"><span class="span">Log</span>in</h1>
        <input class="input" placeholder="Email" type="text" name="email" required="">
        <p id="email"></p>
        <input class="input" placeholder="Password" type="password" name="pass" required="">
        <p id="pass"></p>
        <button  type="submit" class="btn1 button1" name="log" >Login</button>
    </form>

  </div>

</div>
<?php
    if (isset($_POST['log'])) {
        $name=$_POST['email'];
        $pswrd=$_POST['pass'];
        if (($name=='anas'&&$pswrd=='1234')||($name=='saif'&&$pswrd=='1234')) {
            $_SESSION['37102-5456225-7']=$name;
            header('location:index.php');
        }
        else{
            echo "<script>alert('incorrect try again');</script>";
        }
    }
?>

    <!-- ##### All Javascript Files ##### -->
    <!-- jQuery-2.2.4 js -->
    <script src="js/jquery/jquery-2.2.4.min.js"></script>
    <!-- Popper js -->
    
    <script src="js/bootstrap/popper.min.js"></script>
    <!-- Bootstrap js -->
    <script src="js/bootstrap/bootstrap.min.js"></script>
    <!-- All Plugins js -->
    <script src="js/plugins/plugins.js"></script>
    <!-- Active js -->
    <script src="js/active.js"></script>

    <script src="js/modal.js"></script>
    <script type="text/javascript" src="js/calculator.js"></script>
</body>

</html>