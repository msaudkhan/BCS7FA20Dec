<?php
ob_start();
    session_start();
?>
<script type="text/javascript" src="js/jquery/jquery-2.2.4.min.js"></script>


<script>
$(document).ready(function(){
            loadMsg();
        });




        function loadMsg()
        {
            $.post('php/count.php', function(response){
                //alert(response);
                if (response!='') {
                var obj = JSON.parse(response);
                $('#numb').text(obj[0].count); 
                }
            });
        }


        setInterval(function(){
            loadMsg();
        }, 2000);
</script>
<!DOCTYPE html>
<html>

<head>
    <meta charset="UTF-8">
    <meta name="description" content="">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <!-- The above 4 meta tags *must* come first in the head; any other head content must come *after* these tags -->

    <!-- Title -->
    <title>Agri Point</title>

    <!-- Favicon -->
    <link rel="icon" href="img/core-img/favicon.ico">

    <!-- Core Stylesheet -->
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" type="text/css" href="ModalStyle.css">
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Amiri&display=swap" rel="stylesheet">
    <style type="text/css">

        body{
            font-family: 'Amiri', serif;
        }
        .dropdown-content {
  display: none;
  position: absolute;
}

.dropdown:hover .dropdown-content {display: block;}

    </style>

</head>

<body>
    <!-- Preloader -->
    <div class="preloader d-flex align-items-center justify-content-center">
        <div class="preloader-circle"></div>
        <div class="preloader-img">
            <img src="img/core-img/leaf.png" alt="">
        </div>
    </div>
    <!-- ##### Header Area Start ##### -->
    <header class="header-area">

        <!-- ***** Top Header Area ***** -->
        <div class="top-header-area">
            <div class="container">
                <div class="row">
                    <div class="col-12">
                        <div class="top-header-content d-flex align-items-center justify-content-between">
                            <!-- Top Header Content -->
                            <div class="top-header-meta">
                                <a href="#" data-toggle="tooltip" data-placement="bottom" title="infoagripoint@gmail.com"><i class="fa fa-envelope-o" aria-hidden="true"></i> <span>Email: infoagripoint@gmail.com</span></a>
                                <a href="#" data-toggle="tooltip" data-placement="bottom" title="+9257 2741540"><i class="fa fa-phone" aria-hidden="true"></i> <span>Call Us: +9257 2741540</span></a>
                            </div>

                            <!-- Top Header Content -->
                            <div class="top-header-meta d-flex">
                                <!-- Language Dropdown -->
                                <div class="language-dropdown">
                                    <div class="dropdown">
                                        <button class="btn btn-secondary dropdown-toggle mr-30" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">زبان </button>
                                        <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                                            <a class="dropdown-item" href="#">اردو </a>
                                            
                                        </div>
                                    </div>
                                </div>
                                <!-- Login -->
                                <?php if(isset($_SESSION['37102-5456225-7'])){ ?>
                                    <div class="login dropdown" >
                                    <a href="#"><i class="fa fa-user" aria-hidden="true"></i> <span><?php echo $_SESSION['37102-5456225-7']; ?></span></a>
                                    <div class="dropdown-content">
                                    <a href="logout.php" style="text-te">Logout</a></div>
                                </div>
                                <?php }else{ ?>
                                    <div class="login" onclick="log()">
                                    <a href="#"><i class="fa fa-user" aria-hidden="true"></i> <span>لاگ ان </span></a>
                                </div>
                                <?php }?>
                                <!-- Cart -->
                                <div class="cart">
                                    <a><i class="fa fa-shopping-cart" aria-hidden="true"></i> <span>Admin</span></a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- ***** Navbar Area ***** -->
        <div class="alazea-main-menu">
            <div class="classy-nav-container breakpoint-off">
                <div class="container">
                    <!-- Menu -->
                    <nav class="classy-navbar justify-content-between" id="alazeaNav">

                        <!-- Nav Brand -->
                        <a href="index.php" class="nav-brand"><img src="img/core-img/logo.png" alt=""></a>

                        <!-- Navbar Toggler -->
                        <div class="classy-navbar-toggler">
                            <span class="navbarToggler"><span></span><span></span><span></span></span>
                        </div>

                        <!-- Menu -->
                        <div class="classy-menu">

                            <!-- Close Button -->
                            <div class="classycloseIcon">
                                <div class="cross-wrap"><span class="top"></span><span class="bottom"></span></div>
                            </div>

                            <!-- Navbar Start -->
                            <div class="classynav">
                                <ul>
                                    <li><a href="index.php">ہوم </a></li>
                                    <li><a> پروڈکٹ  </a>
                                        <ul class="dropdown">
                                            <?php if (isset($_SESSION['37102-5456225-7'])) {
                                        echo "
                                           <li> <a id='addinfo' onclick='addinfo()'> انسرٹ پروڈکٹ</a></li>
                                            <li><a href='aproduct.php'> ویو پروڈکٹ</a></li>";}
                                            else{
                                                echo "
                                           <li> <a  onclick='log()'> انسرٹ پروڈکٹ</a></li>
                                            <li><a onclick='log()'> ویو پروڈکٹ</a></li>";
                                            }?>
                                        </ul>
                                    </li>
                                    <?php if (isset($_SESSION['37102-5456225-7'])) {
                                        echo "
                                    <li><a href='farmer.php'> فارمر  </a></li>
                                    <li><a href='labour.php'> لیبر  </a></li>
                                        
                                    
                                    <li><a href='shop.php'> شاپ   </a></li>
                                    
                                    <li><a href='feedback.php'> فیڈ بیک   <span id='numb' ></span> </a></li><li><a href='user.php'> یوزر </a></li>";
                                    
                                        }
                                    else{
                                        echo "
                                    <li><a onclick='log()'> فارمر  </a></li>
                                    <li><a onclick='log()'> لیبر  </a></li>
                                        
                                    
                                    <li><a onclick='log()'> شاپ   </a></li>
                                    
                                    <li><a onclick='log()'> فیڈ بیک   <span id='numb' ></span> </a></li>
                                    <li><a onclick='log()'> یوزر </a></li>";    }
                                ?>
                                    
                                
                                </ul>
                                <!-- Search Icon -->
                                <div id="searchIcon">
                                    <i class="fa fa-search" aria-hidden="true"></i>
                                </div>

                            </div>
                            <!-- Navbar End -->
                        </div>
                    </nav>
                    <!-- Search Form -->
                    <div class="search-form">
                        <form action="#" method="get">
                            <input type="search" name="search" id="search" placeholder="Type keywords &amp; press enter...">
                            <button type="submit" class="d-none"></button>
                        </form>
                        <!-- Close Icon -->
                        <div class="closeIcon"><i class="fa fa-times" aria-hidden="true"></i></div>
                    </div>
                </div>
            </div>
        </div>
    </header>
    <!-- ##### Header Area End ##### -->

    <!-- ##### Breadcrumb Area Start ##### -->
    <div class="breadcrumb-area">
        <!-- Top Breadcrumb Area -->
        <div class="top-breadcrumb-area bg-img bg-overlay d-flex align-items-center justify-content-center" style="background-image: url(img/bg-img/24.jpg);">
            <h2>شاپ   </h2>
        </div>

        <div class="container">
            <div class="row">
                <div class="col-12">
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item"><a href="#"><i class="fa fa-home"></i> Home</a></li>
                            <li class="breadcrumb-item active" aria-current="page">Shop</li>
                        </ol>
                    </nav>
                </div>
            </div>
        </div>
    </div>
    <!-- ##### Breadcrumb Area End ##### -->

    <!-- ##### Shop Area Start ##### -->
    <section class="shop-page section-padding-0-100">
        <div class="container">
            

            <div class="row">
                <!-- Sidebar Area -->
                <div class="col-12 col-md-4 col-lg-3">
                    <div class="shop-sidebar-area">

                        

                        <!-- Shop Widget -->
                        <div class="shop-widget catagory mb-50">
                            <h4 class="widget-title">Categories</h4>
                            <div class="widget-desc">
                                <!-- Single Checkbox -->
                                <div class="custom-control custom-checkbox d-flex align-items-center mb-2">
                                    <input type="radio" name="alpha" class="custom-control-input" id="customCheck1" onclick="sort()" <?php
                                        if (isset($_GET['all'])) { echo "checked";}?>
                                    >
                                    <label class="custom-control-label" for="customCheck1">All </label>
                                </div>
                                <!-- Single Checkbox -->
                                <div class="custom-control custom-checkbox d-flex align-items-center mb-2">
                                    <input type="radio" name="alpha" class="custom-control-input" id="customCheck2" onclick="sort()" <?php
                                        if (isset($_GET['Plant'])) { echo "checked";}?>
                                    >
                                    <label class="custom-control-label" for="customCheck2">Plant </label>
                                </div>
                                <!-- Single Checkbox -->
                                <div class="custom-control custom-checkbox d-flex align-items-center mb-2">
                                    <input type="radio" name="alpha" class="custom-control-input" id="customCheck3" onclick="sort()" <?php
                                        if (isset($_GET['Seed'])) { echo "checked";}?>
                                    >
                                    <label class="custom-control-label" for="customCheck3">Seed</label>
                                </div>
                                <!-- Single Checkbox -->
                                <div class="custom-control custom-checkbox d-flex align-items-center mb-2">
                                    <input type="radio" name="alpha" class="custom-control-input" id="customCheck4" onclick="sort()" <?php
                                        if (isset($_GET['Fertilizer'])) { echo "checked";}?>>
                                    <label class="custom-control-label" for="customCheck4" 
                                    >Fertilizer</label>
                                </div>
                            </div>
                        </div>


                        <div class="shop-widget sort-by mb-50">
                            <h4 class="widget-title">Sort by</h4>
                            <div class="widget-desc">
                                <!-- Single Checkbox -->
                                <div class="custom-control custom-checkbox d-flex align-items-center mb-2">
                                    <input type="radio" class="custom-control-input" id="customCheck7" name="alpha" onclick="sort()" 
                                    <?php
                                        if (isset($_GET['newar'])) { echo "checked";}?>
                                    >
                                    
                                    <label class="custom-control-label" for="customCheck7">New arrivals</label>
                                </div>
                                <!-- Single Checkbox -->
                                <div class="custom-control custom-checkbox d-flex align-items-center mb-2">
                                    <input type="radio" class="custom-control-input" id="customCheck8" name="alpha" onclick="sort()" 
                                    <?php
                                        if (isset($_GET['alaz'])) { echo "checked";}?>
                                    >
                                    <label class="custom-control-label" for="customCheck8">Alphabetically, A-Z</label>
                                </div>
                                <!-- Single Checkbox -->
                                <div class="custom-control custom-checkbox d-flex align-items-center mb-2">
                                    <input type="radio" class="custom-control-input" id="customCheck9" name="alpha" onclick="sort()"
                                    <?php
                                        if (isset($_GET['alza'])) { echo "checked";}?>
                                    >
                                    <label class="custom-control-label" for="customCheck9">Alphabetically, Z-A</label>
                                </div>
                            </div>
                        </div>
                        <!-- Shop Widget -->
                        <div class="shop-widget best-seller mb-50">
                            <h4 class="widget-title">Best Seller</h4>
                            <div class="widget-desc">

                                <!-- Single Best Seller Products -->

 <?php
        $con=mysqli_connect("localhost","root","","AgriPoint");
        echo $con->connect_error;        
        $query="SELECT * FROM buy ORDER BY Price DESC LIMIT 3";
        $re=$con->query($query);
        if ($re && $re->num_rows>0) {
            while ($row=$re->fetch_assoc()) {
                $img="../templates/".$row['Image'];
                $na=$row['Product_Name'];
                $pri=$row['Price'];
                echo "
                                <div class='single-best-seller-product d-flex align-items-center'>
                                    <div class='product-thumbnail'>
                                        <a ><img src='".$img."' alt=''></a>
                                    </div>
                                    <div class='product-info'>
                                        <a>".$na."</a>
                                        <p>".$pri."</p>
                                        
                                    </div>
                                </div>";}}?>

                              
                            </div>
                        </div>
                    </div>
                </div>

                <!-- All Products Area -->
                <div class="col-12 col-md-8 col-lg-9">
                    <div class="shop-products-area" >
                        <div class="row">
<?php

        $con=mysqli_connect("localhost","root","","AgriPoint");
        echo $con->connect_error;
        if (isset($_GET['alaz'])) {
            $query="SELECT * FROM products order by Product_name ASC";}
        
        elseif (isset($_GET['newar'])) {

        $query="SELECT * FROM products order by Id DESC";
        }
        elseif (isset($_GET['alza'])) {
        $query="SELECT * FROM products order by Product_name DESC";   
        }

        elseif (isset($_GET['Plant'])) {

        $query="SELECT * FROM products WHERE Category='Plant'";
        }
        elseif (isset($_GET['Seed'])) {
        $query="SELECT * FROM products WHERE Category='Seed'";   
        }

        elseif (isset($_GET['Fertilizer'])) {

        $query="SELECT * FROM products WHERE Category='Fetilizer'";
        }
        else{
        $query="SELECT * FROM products";
        }
        $re=$con->query($query);
        if ($re && $re->num_rows>0) {
            while ($row=$re->fetch_assoc()) {
                $img="../templates/".$row['Image'];
                $na=$row['Product_name'];
                $tag=$row['Tag'];
                $pri=$row['Price'];
                $val=$row['Id'];
                echo "<div class='col-12 col-sm-6 col-lg-4'>
                                <div class='single-product-area1 mb-50'>
                                    <!-- Product Image -->
                                    <div class='product-img1'>
                                        <a href=''><img src='".$img."' alt='' width='270' height='320'></a>
                                        <!-- Product Tag -->
                                        <div class='product-tag'>";
                                            if ($tag!="None") {
                                                echo "
                                            <a href='#'>".$tag."</a>";
                                            }
                                            echo "
                                        </div>
                                    <div class='product-meta d-flex'>
                                        <a href='' onclick='pro_del(".$val.")' class='add-to-cart-btn'>Delete</a>
                                            
                                        </div>
                                    </div>
                                    <!-- Product Info -->
                                    <div class='product-info mt-15 text-center'>
                                        <a href=''>
                                            <p>".$na."</p>
                                        </a>
                                        <h6>".$pri."</h6>
                                    </div>
                                </div>
                            </div>";
            }
        }
?>


<script type="text/javascript">
    
       function pro_del(a){
            if (confirm("Delete!")) {
                 if (window.XMLHttpRequest) {
                xmlhttp = new XMLHttpRequest();
                       } else
                 {
                    xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
                       }
                        xmlhttp.onreadystatechange = function() {
                      if (this.readyState == 4 && this.status == 200)
                        {   
                                 
                            window.location.href="shop.php";
                            }
                                };
                              xmlhttp.open("GET","php/pro_del.php?id="+a,true);       xmlhttp.send();    }
            
            else{

            }}

    function sort() {
        var val="?";
        var rad0=document.getElementById('customCheck1');
        var rad01=document.getElementById('customCheck2');
        var rad02=document.getElementById('customCheck3');
        var rad3=document.getElementById('customCheck4');
        var rad=document.getElementById('customCheck7');
        var rad1=document.getElementById('customCheck8');
        var rad2=document.getElementById('customCheck9');
        if (rad.checked==true) {
            val=val+"newar=new arivals";
            location.href=val;
        }
        if (rad1.checked==true) {
            val=val+"alaz=ASC";
            location.href=val;
        }
        if (rad2.checked==true) {
            val=val+"alza=DESC";
            location.href=val;
        }
        if (rad0.checked==true) {
            val=val+"all=all";
            location.href=val;
        }
        if (rad01.checked==true) {
            val=val+"Plant=Plant";
            location.href=val;
        }
        if (rad02.checked==true) {
            val=val+"Seed=Seed";
            location.href=val;
        }
        if (rad3.checked==true) {
            val=val+"Fertilizer=Fertilizer";
            location.href=val;
        }
    }
</script>

                        </div>   
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- ##### Shop Area End ##### -->

<div id="myModal" class="modal">

  <!-- Modal content -->
  <div class="modal-content divpro">
    <span class="close" onclick="close1()">&times;</span>
    <form class="form" enctype="multipart/form-data" method="POST">
  <h1 class="h1"><span class="span">Add</span> Product Information</h1>
  <input class="input" placeholder="Name" type="text" name="Name" >
  <select name="type" class="input">
      <option> درخت    </option>
      <option> پودے   </option>
      <option>سبزی   </option>
      <option>   پھل  </option>
  </select>
  <input class="input" type="text"  placeholder="Discription" name="dis"/>
  <input class="input" type="file" name="image" id="img2" onchange="validateImage()">

  <button name="add_pro" class="btn1 button1">Add Information</button>
</form>

  </div>

</div>




<script type="text/javascript">
        
function validateImage() {
    var formData = new FormData();
    var file = document.getElementById("img2").files[0];
    formData.append("Filedata", file);
    var t = file.type.split('/').pop().toLowerCase();
    if (t != "jpeg" && t != "jpg" && t != "png" && t != "bmp" && t != "gif") {
        alert('Please select a valid image file extension');
        document.getElementById("img2").value = '';
        return false;
    }
    if (file.size > 1024000) {
        alert('Max Upload size is 1MB only');
        document.getElementById("img2").value = '';
        return false;
    }
    return true;
}
    
function addinfo() {
    document.getElementById('myModal').style.display='block';

}
function close1() {
    document.getElementById('myModal').style.display='none';
}
</script>


<?php
    
    if (isset($_POST['add_pro'])) {
        $con=mysqli_connect("localhost","root","","AgriPoint");
        echo $con->connect_error;
        $name=$_POST['Name'];
        $pname=$_POST['type'];
        $pri=$_POST['dis'];
        $file_name= $_FILES['image']['name'];
        $file_tmp = $_FILES['image']['tmp_name'];
         move_uploaded_file($file_tmp,"images/".$file_name);
         $id=$_SESSION['Id'];
         $query="INSERT INTO information(Name,Type,Discription,Image) 
            VALUES ('$name','$pname','$pri','../admin/images/$file_name')";
            if($con->query($query)){
                echo "<script>
                    alert('Added Product Information');
                </script>";
         }
         else{
            echo "<script>
                alert('Sorry Try Again');
            </script>";
        }
        }
        


  
    
?>
    <!-- ##### Footer Area Start ##### -->
    <footer class="footer-area bg-img" style="background-image: url(img/bg-img/3.jpg);">
        <!-- Main Footer Area -->
        <div class="main-footer-area">
            <div class="container">
                <div class="row">

                    <!-- Single Footer Widget -->
                    <div class="col-12 col-sm-6 col-lg-3">
                        <div class="single-footer-widget">
                            <div class="footer-logo mb-30">
                                <a href="#"><img src="img/core-img/logo.png" alt=""></a>
                            </div>
                            <p>زراعت مینوفیکچر کی بنیاد ہے ، چونکہ قدرت کی تیاری ہی آرٹ کا سامان ہے۔</p>
                            <div class="social-info">
                                <a href="#"><i class="fa fa-facebook" aria-hidden="true"></i></a>
                                <a href="#"><i class="fa fa-twitter" aria-hidden="true"></i></a>
                                <a href="#"><i class="fa fa-google-plus" aria-hidden="true"></i></a>
                                <a href="#"><i class="fa fa-instagram" aria-hidden="true"></i></a>
                                <a href="#"><i class="fa fa-linkedin" aria-hidden="true"></i></a>
                            </div>
                        </div>
                    </div>

                    <!-- Single Footer Widget -->
                    <div class="col-12 col-sm-6 col-lg-3">
                        <div class="single-footer-widget">
                            <div class="widget-title">
                                <h5> کوئیک لنک </h5>
                            </div>
                            <nav class="widget-nav">
                                <ul>
                                    <li><a href="#">خریداری  </a></li>
                                    <li><a href="#">FAQs</a></li>
                                    <li><a href="#">    پیمنٹس </a></li>
                                    <li><a href="#">  نیوز </a></li>
                                    <li><a href="#">  ریٹرن </a></li>
                                    <li><a href="#">  اشتہار </a></li>
                                    <li><a href="#"> شپنگ </a></li>
                                    <li><a href="#">  کیریئر </a></li>
                                    <li><a href="#">    آرڈرز </a></li>
                                    <li><a href="#"> پالیسیز   </a></li>
                                </ul>
                            </nav>
                        </div>
                    </div>

                    <!-- Single Footer Widget -->
                    <div class="col-12 col-sm-6 col-lg-3">
                        <div class="single-footer-widget">
                            <div class="widget-title">
                                <h5> بیسٹ سیلر </h5>
                            </div>
 <?php
        $con=mysqli_connect("localhost","root","","AgriPoint");
        echo $con->connect_error;        
        $query="SELECT * FROM buy ORDER BY Price DESC LIMIT 2";
        $re=$con->query($query);
        if ($re && $re->num_rows>0) {
            while ($row=$re->fetch_assoc()) {
                $img=$row['Image'];
                $na=$row['Product_Name'];
                $pri=$row['Price'];
                echo "
                            <!-- Single Best Seller Products -->
                            <div class='single-best-seller-product d-flex align-items-center'>
                                <div class='product-thumbnail'>
                                    <a ><img src='".$img."' alt=''></a>
                                </div>
                                <div class='product-info'>
                                    <a >".$na."</a>
                                    <p>".$pri."</p>
                                </div>
                            </div>";}}?>

                            
                        </div>
                    </div>

                    <!-- Single Footer Widget -->
                    <div class="col-12 col-sm-6 col-lg-3">
                        <div class="single-footer-widget">
                            <div class="widget-title">
                                <h5> رابطہ </h5>
                            </div>

                            <div class="contact-information">
                                <p><span>Address:</span> comsats یونیورسٹی اٹک کیمپس </p>
                                <p><span>Phone:</span> +9257 2741540</p>
                                <p><span>Email:</span> infoagripoint@gmail.com</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Footer Bottom Area -->
        <div class="footer-bottom-area">
            <div class="container">
                <div class="row">
                    <div class="col-12">
                        <div class="border-line"></div>
                    </div>
                    <!-- Copywrite Text -->
                    <div class="col-12 col-md-6">
                        <div class="copywrite-text">
                            <p> <a target="_blank" href="index.php">AGRI POINT</a></p>
                        </div>
                    </div>
                    <!-- Footer Nav -->
                    <div class="col-12 col-md-6">
                        <div class="footer-nav">
                            <nav>
                                <ul>
                                    <li><a href="index.php">  ہوم </a></li>
                                    <li><a href="index.php">  پروڈکٹ </a></li>
                                    <li><a href="shop.php">  شاپ    </a></li>
                                    <li><a href="contact.php"> ہم سے رابطہ کریں </a></li>
                                    <li><a href="about.php">ہمارے بارے میں</a></li>
                                </ul>
                            </nav>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </footer>
    <!-- ##### Footer Area End ##### -->


  

    <!-- ##### All Javascript Files ##### -->
    <!-- jQuery-2.2.4 js -->
    <script src="js/jquery/jquery-2.2.4.min.js"></script>
    <!-- Popper js -->
    <script src="js/bootstrap/popper.min.js"></script>
    <!-- Bootstrap js -->
    <script src="js/bootstrap/bootstrap.min.js"></script>
    <!-- All Plugins js -->
    <script src="js/plugins/plugins.js"></script>
    <!-- Active js -->
    <script src="js/active.js"></script>
    <!-- Icons js-->
    <script src='https://kit.fontawesome.com/a076d05399.js'></script>
     <script src="js/modal.js"></script>
</body>

</html>