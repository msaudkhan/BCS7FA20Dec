package com.example.foodbyte.ui.cart;

import android.util.Log;

import static android.content.ContentValues.TAG;

public class ModelImage {
    private String id,imageurl,name,price,user_name,quantity,mart;

    public ModelImage(String id, String url, String name, String price, String quantity,String mart, String user_name) {
        this.id = id;
        this.imageurl = url;
        this.price=price;
        this.name=name;
        this.quantity=quantity;
        this.mart=mart;
        this.user_name= user_name;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getImageurl() {
        return imageurl;
    }

    public void setImageurl(String imageurl) {
        this.imageurl = imageurl;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPrice() {
        return price;
    }

    public void setPrice(String price) { this.price = price; }

    public String getUserName() {
        return user_name;
    }

    public void setUserName(String user_name) { this.user_name = user_name; }

    public String getQuantity() {
        return quantity;
    }

    public void setQuantity(String quantity) { this.quantity = quantity; }

    public String getMart() {
        return mart;
    }

    public void setMart(String mart) { this.mart = mart; }

}
