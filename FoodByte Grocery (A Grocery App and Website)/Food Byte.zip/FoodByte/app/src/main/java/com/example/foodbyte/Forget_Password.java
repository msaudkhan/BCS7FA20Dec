package com.example.foodbyte;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.util.Patterns;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import static android.content.ContentValues.TAG;

public class Forget_Password extends AppCompatActivity {
    EditText email,dd,mm,yy;
    Button reset;
    AlertDialog.Builder builder;
    String ip;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_forget__password);

        ActionBar actionBar = getSupportActionBar();
        actionBar.setHomeAsUpIndicator(R.drawable.ic_baseline_close_24);
        actionBar.setDisplayHomeAsUpEnabled(true);

        SharedPreferences editor1 = getSharedPreferences("ip", Context.MODE_PRIVATE);
        ip=editor1.getString("ip",null);
        Log.i(TAG, "ip: "+ip);

        builder = new AlertDialog.Builder(this);

        reset=findViewById(R.id.reset);
        email=findViewById(R.id.email);
        dd=findViewById(R.id.dd);
        mm=findViewById(R.id.mm);
        yy= findViewById(R.id.yy);

        reset.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                final String DT= dd.getText().toString();
                final String MM= mm.getText().toString();
                final String YY= yy.getText().toString();
                final String EMAIL=email.getText().toString();
                final String DOB= dd.getText().toString()+"/"+mm.getText().toString()+"/"+yy.getText().toString();

                if (email.length()==0){email.requestFocus();email.setError("FIELD CANNOT BE EMPTY");}
                else if(email.length()<8 || !(Patterns.EMAIL_ADDRESS.matcher(EMAIL).matches())) {email.requestFocus();email.setError("Enter Valid Email Address");}

                else if (DT.length()==0){dd.requestFocus();dd.setError("FIELD CANNOT BE EMPTY");}
                else if (Integer.parseInt(DT)<1 ||Integer.parseInt(DT)>31){dd.requestFocus();dd.setError("ENTER A VALID DATE");}
                else if (MM.length()==0){mm.requestFocus();mm.setError("FIELD CANNOT BE EMPTY");}
                else if (Integer.parseInt(MM)<1 ||Integer.parseInt(MM)>12){mm.requestFocus();mm.setError("ENTER A VALID MONTH");}
                else if (YY.length()==0){yy.requestFocus();yy.setError("FIELD CANNOT BE EMPTY");}
                else if (Integer.parseInt(YY)<1970 ||Integer.parseInt(YY)>2008){yy.requestFocus();yy.setError("ENTER A VALID YEAR");}
                else {
                    Handler handler = new Handler(Looper.getMainLooper());
                    handler.post(new Runnable() {
                        @Override
                        public void run() {
                            //Starting Write and Read data with URL
                            //Creating array for parameters
                            String[] field = new String[2];
                            field[0] = "email";
                            field[1] = "dob";


                            //Creating array for data
                            String[] data = new String[2];
                            data[0] = EMAIL;
                            data[1] = DOB;

                            PutData putData = new PutData("http://"+ip+"/grocery/android/reset_password.php", "POST", field, data);
                            if (putData.startPut()) {
                                if (putData.onComplete()) {
                                    String result = putData.getResult();
                                    Log.i(result, "runr: "+result);
                                    if (result.equals("reset"))
                                    {
                                        Toast.makeText(getApplicationContext(),"Your Password is reset to 1234",Toast.LENGTH_LONG).show();
                                        builder.setMessage("Your Password is reset to 1234") .setTitle("Password Reset");

                                        //Setting message manually and performing action on button click
                                        builder.setMessage("Your Password is reset to 1234")
                                                .setCancelable(false)
                                                .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                                                    public void onClick(DialogInterface dialog, int id) {
                                                        Intent intent=new Intent(getApplicationContext(),LoginActivity.class);
                                                        startActivity(intent);
                                                        finish();
                                                    }
                                                }
                                                );
                                        //Creating dialog box
                                        AlertDialog alert = builder.create();
                                        //Setting the title manually
                                        alert.setTitle("Password Changed");
                                        alert.show();

                                }
                                    else {Toast.makeText(getApplicationContext(),"Wrong Credentials",Toast.LENGTH_LONG).show();}
                                }
                            }
                        }
                    });
                }
            }
        });
    }
    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                Intent i=new Intent(this,LoginActivity.class);
                startActivity(i);
                finish();
                return true;
        }
        return super.onOptionsItemSelected(item);
    }
}