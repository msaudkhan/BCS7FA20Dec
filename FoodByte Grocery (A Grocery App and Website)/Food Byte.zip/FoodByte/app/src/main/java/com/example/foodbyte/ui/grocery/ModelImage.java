package com.example.foodbyte.ui.grocery;

import android.util.Log;

import static android.content.ContentValues.TAG;

public class ModelImage {
    private String id,imageurl,name,price,user_name;


    public ModelImage(String id, String url, String name, String price, String user_name) {
        this.id = id;
        this.imageurl = url;
        this.price=price;
        this.name=name;
        this.user_name=user_name;
    }


    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getImageurl() {
        return imageurl;
    }

    public void setImageurl(String imageurl) {
        this.imageurl = imageurl;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPrice() {
        return price;
    }

    public void setPrice(String price) { this.price = price; }

    public String getUserName() {
        return user_name;
    }

    public void setUserName(String user_name) { this.user_name = user_name;
        Log.i(TAG, "setUserName: "+user_name);}
}
