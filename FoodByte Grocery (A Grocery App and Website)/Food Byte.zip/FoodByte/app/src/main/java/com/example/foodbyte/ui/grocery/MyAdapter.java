package com.example.foodbyte.ui.grocery;

import android.content.Context;
import android.content.SharedPreferences;
import android.net.wifi.WifiManager;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.format.Formatter;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.fragment.app.FragmentTransaction;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.example.foodbyte.PutData;
import com.example.foodbyte.R;
import com.example.foodbyte.RegistrationActivity;

import java.util.List;

import static android.content.ContentValues.TAG;
import static android.content.Context.MODE_PRIVATE;
import static android.content.Context.WIFI_SERVICE;

public class MyAdapter extends RecyclerView.Adapter<ImageViewHOlder> {
    
    private Context context;
    TextView price,name;
    Button add_to_cart;
    String mart_id,ip;
    private List<com.example.foodbyte.ui.grocery.ModelImage> imageList;

    public MyAdapter(Context context, List<com.example.foodbyte.ui.grocery.ModelImage> imageList) {
        this.context = context;
        this.imageList = imageList;
        Log.i(TAG, "MyAdapter: "+imageList);
    }

    @NonNull
    @Override
    public ImageViewHOlder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.custom_layout_item,parent,false);
        Log.i(TAG, "onCreateViewHolder: "+imageList);
        price=view.findViewById(R.id.price);
        name=view.findViewById(R.id.desp);
        add_to_cart=view.findViewById(R.id.add_to_cart);
        SharedPreferences editor = context.getSharedPreferences("mart_id", MODE_PRIVATE);
        mart_id = editor.getString("mart_id", "1");
        SharedPreferences editor1 = context.getSharedPreferences("ip", Context.MODE_PRIVATE);
        ip=editor1.getString("ip",null);
        Log.i(TAG, "ip: "+ip);
        return new ImageViewHOlder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ImageViewHOlder holder, final int position) {
        Log.i(TAG, "onBindViewHolder: "+imageList);

        Glide.with(context).load(imageList.get(position).getImageurl()).into(holder.imageView);
       // Log.i(TAG, "onBindViewHolder: "+position);
        name.setText(imageList.get(position).getName().toString());
        price.setText(imageList.get(position).getPrice().toString());
        final String prod_id=imageList.get(position).getId().toString();
        final String uname=imageList.get(position).getUserName().toString();

        add_to_cart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.i(TAG, "onClick: "+prod_id);
                Log.i(TAG, "onClick: "+uname);

                Handler handler = new Handler(Looper.getMainLooper());
                handler.post(new Runnable() {
                    @Override
                    public void run() {
                        //Starting Write and Read data with URL
                        //Creating array for parameters
                        String[] field = new String[3];
                        field[0] = "Cust_Id";
                        field[1] = "Prod_Id";
                        field[2] = "Mart_Id";


                        //Creating array for data
                        String[] data = new String[3];
                        data[0] = uname;
                        data[1] = prod_id;
                        data[2] = mart_id;

                        PutData putData = new PutData("http://"+ip+"/grocery/android/cart.php", "POST", field, data);
                        Log.i(TAG, "putdata: "+putData.getData());
                        if (putData.startPut()) {
                            if (putData.onComplete()) {
                                String result = putData.getResult();
                                Log.i(TAG, "run: "+result);
                                if (result.equals("Added To carts") == true)
                                {

                                    //  Intent intent=new Intent(RegistrationActivity.this,Home.class);
                                    //startActivity(intent);
                                    
                                    Log.i(TAG, "data added");
                                    // Toast.makeText(SignUp.this,"data added",Toast.LENGTH_LONG).show();
                                }
                                else
                                {
                                   // Toast.makeText(MyAdapter.this, result,Toast.LENGTH_LONG).show();
                                    Log.i(TAG, "data not added");
                                    Log.i(TAG, "run: ");
                                }
                                //End ProgressBar (Set visibility to GONE)
                                //Log.i("PutData", result);
                            }
                        }
                        //End Write and Read data with URL
                    }
                });


            }
        });

    }

    @Override
    public int getItemCount() {
        return imageList.size();
    }


}

class ImageViewHOlder extends RecyclerView.ViewHolder{

    ImageView imageView;
    public ImageViewHOlder(@NonNull View itemView) {
        super(itemView);
        imageView = itemView.findViewById(R.id.imageView);
    }
}