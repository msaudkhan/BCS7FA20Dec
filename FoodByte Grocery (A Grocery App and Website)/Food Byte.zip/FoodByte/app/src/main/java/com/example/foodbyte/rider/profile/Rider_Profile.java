package com.example.foodbyte.rider.profile;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.foodbyte.LoginActivity;
import com.example.foodbyte.PutData;
import com.example.foodbyte.R;
import com.example.foodbyte.ui.profile.Edit_Profile;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static android.content.ContentValues.TAG;

public class Rider_Profile extends Fragment {
    ImageView imageView;
    ListView listView;
    String user_id,ip;
    String name="",email="",phone="";
    AlertDialog.Builder builder;
    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        View root = inflater.inflate(R.layout.fragment_rider_profile, container, false);

        imageView= root.findViewById(R.id.bgimgview);
        listView = root.findViewById(R.id.itemlist);

        SharedPreferences editor = getActivity().getSharedPreferences("user", Context.MODE_PRIVATE);
        user_id=editor.getString("user",null);
        SharedPreferences editor1 = getActivity().getSharedPreferences("ip", Context.MODE_PRIVATE);
        ip=editor1.getString("ip",null);
        Log.i(TAG, "ip: "+ip);
        builder = new AlertDialog.Builder(getActivity());

        clicklistener(user_id);
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                if (position == 3)
                {
                    Intent intent= new Intent(getActivity(), Edit_Rider_Profile.class);
                    startActivity(intent);
                }
                if (position == 4) { free_rider(); }

            }
        });
        return root;
    }

    public void clicklistener(String txt) {
        String url = "http://"+ip+"/grocery/android/get_rider_profile.php";
        final String text = txt;
        StringRequest stringRequest = new StringRequest(Request.Method.POST, url, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                //Toast.makeText(getActivity().getApplicationContext(), response, Toast.LENGTH_LONG).show();
                Log.i(TAG, "get rider profile :"+response);
                try {
                    JSONObject jsonObject = new JSONObject(response);
                    String succes = jsonObject.getString("success");
                    JSONArray jsonArray = jsonObject.getJSONArray("data");
                    Log.i(TAG, "onResponse: "+succes);
                    if(succes.equals("1")){
                        for(int i=0;i<jsonArray.length();i++){
                            JSONObject object = jsonArray.getJSONObject(i);
                            Log.i(TAG, "onResponse: "+object);
                            name= object.getString("name");
                            email=object.getString("email");
                            phone=object.getString("phone");
                            Log.i(TAG, "afterget1: "+name+email+phone);
                            String[] detail = new String[]
                                    {name,email,phone,"Edit","Logout"};
                            //  private ArrayList<String> data;
                            int[] listview_icon = new int[]
                                    {R.drawable.ic_baseline_account_box_24,R.drawable.ic_baseline_email_24,
                                            R.drawable.ic_baseline_phone_24,R.drawable.ic_baseline_edit_24,
                                            R.drawable.ic_baseline_power_settings_new_24};
                            List<HashMap<String,String>> list= new ArrayList<HashMap<String, String>>();
                            for (int j =0 ; j<5 ; j++)
                            {
                                HashMap<String,String> hm =new HashMap<String, String>();
                                hm.put("Listdetail",detail[j]);
                                hm.put("listicon",Integer.toString(listview_icon[j]));

                                list.add(hm);
                            }
                            String[] from = {
                                    "listicon","Listdetail"
                            };
                            int[] to ={R.id.foricon, R.id.foritem};
                            SimpleAdapter simpleAdapter =new SimpleAdapter(getActivity(),list,R.layout.fragment_profile_item,from,to);
                            listView.setAdapter(simpleAdapter);
                        }
                    }


                } catch (JSONException e) {
                    e.printStackTrace();
                    Log.i(TAG, "excep: ");
                }

            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(getActivity().getApplicationContext(), error.toString(), Toast.LENGTH_LONG).show();
            }
        }) {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String, String> params = new HashMap<String, String>();
                params.put("user_id", text);
                Log.i(TAG, "getParams: "+params);
                return params;
            }


        };
        RequestQueue requestQueue = Volley.newRequestQueue(getContext().getApplicationContext());
        requestQueue.add(stringRequest);
    }

    public void free_rider(){
        Handler handler = new Handler(Looper.getMainLooper());
        handler.post(new Runnable() {
            @Override
            public void run() {
                //Starting Write and Read data with URL
                //Creating array for parameters
                String[] field = new String[1];
                field[0] = "Rider_Id";

                //Creating array for data
                String[] data = new String[1];
                data[0] = user_id;

                //Toast.makeText(getApplicationContext(), field[0]+" "+data[0], Toast.LENGTH_LONG).show();
                PutData putData = new PutData("http://"+ip+"/grocery/android/logout_rider.php", "POST", field, data);
                Log.i(TAG, "putdata: "+putData.getData());
                if (putData.startPut()) {
                    if (putData.onComplete()) {
                        String result = putData.getResult();
                        Log.i(TAG, "run: "+result);
                        if (result.equals("Success") == true)
                        {
                            Log.i(TAG, "Rider is offline now");
                            Intent intent= new Intent(getActivity(), LoginActivity.class);
                            startActivity(intent);

                        }
                        else
                        {
                            Log.i(TAG, "Rider not logout");
                            Log.i(TAG, "run: ");
                        }

                    }
                }

            }
        });
    }

}
