package com.example.foodbyte.ui.cart;

public class ModelImage2 {
    private String name,price;
    public ModelImage2(String name, String price) {
        this.price=price;
        this.name=name;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPrice() {
        return price;
    }

    public void setPrice(String price) { this.price = price; }

}
