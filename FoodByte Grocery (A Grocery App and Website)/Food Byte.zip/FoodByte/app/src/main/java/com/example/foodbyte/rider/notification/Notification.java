package com.example.foodbyte.rider.notification;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.foodbyte.PutData;
import com.example.foodbyte.R;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static android.content.ContentValues.TAG;
import static android.content.Context.MODE_PRIVATE;

public class Notification extends Fragment {
    TextView notification,order_id,name,mart_id,tv1,tv2,tv3;
    Button complete;
    String user_id,ip;
    double latitude;
    double longitude;
    public View onCreateView(@NonNull LayoutInflater inflater,
                                 ViewGroup container, Bundle savedInstanceState) {
            View root = inflater.inflate(R.layout.fragment_notification, container, false);

            SharedPreferences editor = getActivity().getSharedPreferences("user", MODE_PRIVATE);
            user_id=editor.getString("user",null);
            SharedPreferences editor1 = getActivity().getSharedPreferences("ip", Context.MODE_PRIVATE);
            ip=editor1.getString("ip",null);
            Log.i(TAG, "ip: "+ip);
                            Log.i(TAG, "user_id: "+user_id);

            notification=root.findViewById(R.id.notication);
            order_id=root.findViewById(R.id.order_id);
            tv1=root.findViewById(R.id.tv1);
            tv2=root.findViewById(R.id.tv2);
            tv3=root.findViewById(R.id.tv3);
            name=root.findViewById(R.id.name);
            complete=root.findViewById(R.id.complete);
            mart_id=root.findViewById(R.id.mart_id);
            clicklistener(user_id);
        try {
            if (ContextCompat.checkSelfPermission(getActivity().getApplicationContext(), android.Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED ) {
                ActivityCompat.requestPermissions(getActivity(), new String[]{android.Manifest.permission.ACCESS_FINE_LOCATION}, 101);
            }
        } catch (Exception e){
            e.printStackTrace();
        }
        location();
        Log.i(TAG, "Latitude: "+Double.toString(latitude)+" Longitude "+Double.toString(longitude));
        //Toast.makeText(getActivity(),"latitude "+Double.toString(latitude)+"/longitude "+longitude,Toast.LENGTH_LONG).show();
        final String Latitue= Double.toString(latitude);
        final String Longitude= Double.toString(longitude);
        Handler handler = new Handler(Looper.getMainLooper());
        handler.post(new Runnable() {
            @Override
            public void run() {
                //Starting Write and Read data with URL
                //Creating array for parameters
                String[] field = new String[3];
                field[0] = "latitude";
                field[1] = "longitude";
                field[2] = "id";
                // field[3] = "Email";


                //Creating array for data
                String[] data = new String[3];
                data[0] = Latitue;
                data[1] = Longitude;
                data[2] = user_id;

                PutData putData = new PutData("http://"+ip+"/grocery/Location/signup.php", "POST", field, data);
                if (putData.startPut()) {
                    if (putData.onComplete()) {
                        String result = putData.getResult();
                        //Toast.makeText(getContext(),result,Toast.LENGTH_LONG).show();
                        Log.i(TAG, result);
                        if (result.equals("location added") == true)
                        { Log.i(TAG, "location added: "); }
                        else { Log.i(TAG, "location added: ");}
                    }
                }
                //End Write and Read data with URL
            }
        });
            complete.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    order_complete(user_id);
                }
            });
            return root;
        }
    public void clicklistener(String txt){

        String url = "http://"+ip+"/grocery/android/display_rider_notification.php";
        final String text = txt;
        StringRequest stringRequest = new StringRequest(Request.Method.POST, url, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                Log.i(TAG, "Display Rider notification: "+response);
                //Toast.makeText(getContext(), response.trim(), Toast.LENGTH_LONG).show();
                Log.i(TAG, "onResponse: "+response);
                try {
                    JSONObject jsonObject = new JSONObject(response);
                    String succes = jsonObject.getString("success");
                    JSONArray jsonArray = jsonObject.getJSONArray("data");

                    String order="",desp="",namee="",mart="",notify="";
                    if (succes.equals("1")) {
                        if (jsonArray.length()==0){
                            notification.setText("NO ORDER YET");
                            tv1.setText("");tv2.setText("");tv3.setText("");
                            complete.setVisibility(getView().GONE);
                        }
                        for (int i = 0; i < jsonArray.length(); i++) {
                            JSONObject object = jsonArray.getJSONObject(i);
                            Log.i(TAG, "onResponse: " + object);
                            order = object.getString("order_id");
                            namee = object.getString("name");
                            desp=object.getString("desp");
                            mart=object.getString("mart_id").substring(5);
                            Log.i(TAG, "deso"+object);
                            order_id.setText("#"+order);
                            name.setText(namee);
                            mart_id.setText(mart);
                            notify=desp;
                            notification.setText(notify);
                            complete.setVisibility(getView().getVisibility());
                        }
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(getContext(), error.toString(), Toast.LENGTH_LONG).show();
            }
        }) {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String, String> params = new HashMap<String, String>();
                params.put("user_id", text);
                return params;
            }
        };
        RequestQueue requestQueue = Volley.newRequestQueue(getContext());
        requestQueue.add(stringRequest);
    }
    public void order_complete(final String txt){
        Handler handler = new Handler(Looper.getMainLooper());
        handler.post(new Runnable() {
            @Override
            public void run() {
                //Starting Write and Read data with URL
                //Creating array for parameters
                String[] field = new String[1];
                field[0] = "Rider_Id";

                //Creating array for data
                String[] data = new String[1];
                data[0] = txt;

                PutData putData = new PutData("http://"+ip+"/grocery/android/delete_rider_notification.php", "POST", field, data);
                Log.i(TAG, "putdata: "+putData.getData());
                if (putData.startPut()) {
                    if (putData.onComplete()) {
                        String result = putData.getResult();
                        Log.i(TAG, "run: "+result);
                        if (result.equals("Success") == true)
                        {
                            Notification newFragment = new Notification();
                            FragmentTransaction transaction = getFragmentManager().beginTransaction();
                            transaction.replace(R.id.rider_nav_host_fragment, newFragment);
                            transaction.addToBackStack(null);
                            Log.i(TAG, "refresh");
                            transaction.commit();
                            Log.i(TAG, "data added");
                        }
                        else
                        {
                            // Toast.makeText(MyAdapter.this, result,Toast.LENGTH_LONG).show();
                            Log.i(TAG, "data not added");
                            Log.i(TAG, "run: ");
                        }
                    }
                }
                //End Write and Read data with URL
            }
        });
    }
    public void location()
    {
        GpsTracker gpsTracker = new GpsTracker(getActivity());
        if(gpsTracker.canGetLocation()){
            latitude = gpsTracker.getLatitude();
            longitude = gpsTracker.getLongitude();
        //    tvLatitude.setText(String.valueOf(latitude));
          //  tvLongitude.setText(String.valueOf(longitude));
        }else{
            gpsTracker.showSettingsAlert();
        }
    }
}
