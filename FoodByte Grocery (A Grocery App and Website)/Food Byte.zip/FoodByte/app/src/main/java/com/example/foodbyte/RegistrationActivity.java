package com.example.foodbyte;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.wifi.WifiManager;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.format.Formatter;
import android.text.method.HideReturnsTransformationMethod;
import android.text.method.PasswordTransformationMethod;
import android.util.Log;
import android.util.Patterns;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

import static android.content.ContentValues.TAG;


public class RegistrationActivity extends AppCompatActivity {
    Button signup,already;
    EditText username, email, password, dt, mm, yy,phonenumber,address;
    RadioButton Gender,User_Rider;
    RadioGroup radioGroup,radioGroup1;
    ImageView eye;
    String ip;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registration);
        username=findViewById(R.id.name);
        email=findViewById(R.id.email);
        password=findViewById(R.id.password);
        dt=findViewById(R.id.dd);
        mm=findViewById(R.id.mm);
        yy= findViewById(R.id.yy);
        phonenumber= findViewById(R.id.phone);
        address=findViewById(R.id.address);
        radioGroup=findViewById(R.id.radioGroup);
        radioGroup1=findViewById(R.id.radioGroup1);
        signup=findViewById(R.id.signup);
        already=findViewById(R.id.already);
        eye=findViewById(R.id.eye);
        SharedPreferences editor1 = getSharedPreferences("ip", Context.MODE_PRIVATE);
        ip=editor1.getString("ip",null);
        Log.i(TAG, "ip: "+ip);
        already.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(getApplicationContext(),LoginActivity.class);
                startActivity(intent);
                finish();
            }
        });
        eye.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(password.getTransformationMethod().equals(PasswordTransformationMethod.getInstance())){
                    password.setTransformationMethod(HideReturnsTransformationMethod.getInstance());
                }
                else{password.setTransformationMethod(PasswordTransformationMethod.getInstance());}
            }
        });

        signup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                final String Name= username.getText().toString();
                final  String EmaiL= email.getText().toString();
                final String PassworD= password.getText().toString();
                String DT= dt.getText().toString();
                String MM= mm.getText().toString();
                String YY= yy.getText().toString();
                DT=String.valueOf(Integer.parseInt(DT));
                MM=String.valueOf(Integer.parseInt(MM));
                YY=String.valueOf(Integer.parseInt(YY));
                final String AddreSS= address.getText().toString();
                final String PhonE= phonenumber.getText().toString();
                final String Date_of_Birth= DT+"/"+MM+"/"+YY;
                Log.i(Date_of_Birth, "dob "+Date_of_Birth);
                int selectedId=radioGroup.getCheckedRadioButtonId();Gender=findViewById(selectedId);
                int selectedId1=radioGroup1.getCheckedRadioButtonId();User_Rider=findViewById(selectedId1);
                final String GendeR= Gender.getText().toString();
                final String User_or_Rider= User_Rider.getText().toString();
                Log.i(User_or_Rider, "onClick: "+User_or_Rider);
                if (Name.length()==0){username.requestFocus();username.setError("FIELD CANNOT BE EMPTY");}
                else if (EmaiL.length()==0){email.requestFocus();email.setError("FIELD CANNOT BE EMPTY");}
                else if(EmaiL.length()<8 || !(Patterns.EMAIL_ADDRESS.matcher(EmaiL).matches())) {email.requestFocus();email.setError("Enter Valid Email Address");}
                else if (PassworD.length()==0){password.requestFocus();password.setError("FIELD CANNOT BE EMPTY");}
                else if (DT.length()==0){dt.requestFocus();dt.setError("FIELD CANNOT BE EMPTY");}
                else if (Integer.parseInt(DT)<1 ||Integer.parseInt(DT)>31){dt.requestFocus();dt.setError("ENTER A VALID DATE");}
                else if (MM.length()==0){mm.requestFocus();mm.setError("FIELD CANNOT BE EMPTY");}
                else if (Integer.parseInt(MM)<1 ||Integer.parseInt(MM)>12){mm.requestFocus();mm.setError("ENTER A VALID MONTH");}
                else if (YY.length()==0){yy.requestFocus();yy.setError("FIELD CANNOT BE EMPTY");}
                else if (Integer.parseInt(YY)<1970 ||Integer.parseInt(YY)>2008){yy.requestFocus();yy.setError("ENTER A VALID YEAR");}
                else if (AddreSS.length()==0){address.requestFocus();address.setError("FIELD CANNOT BE EMPTY");}
                else if(PhonE.length()==0) {phonenumber.requestFocus();phonenumber.setError("FIELD CANNOT BE EMPTY"); }
                else if(PhonE.length()<11 || PhonE.length()>11 || !(android.util.Patterns.PHONE.matcher(PhonE).matches())) {phonenumber.requestFocus();phonenumber.setError("Enter Valid Phone Number");}
                else
                {
                    Handler handler = new Handler(Looper.getMainLooper());
                    handler.post(new Runnable() {
                        @Override
                        public void run() {
                            //Starting Write and Read data with URL
                            //Creating array for parameters
                            String[] field = new String[7];
                            field[0] = "Name";
                            field[1] = "Gender";
                            field[2] = "Phone";
                            field[3] = "Email";
                            field[4] = "Password";
                            field[5] = "Address";
                            field[6] = "Date_Of_Birth";
                            // field[3] = "Email";


                            //Creating array for data
                            String[] data = new String[7];
                            data[0] = Name;
                            data[1] = GendeR;
                            data[2] = PhonE;
                            data[3] = EmaiL;
                            data[4] = PassworD;
                            data[5] = AddreSS;
                            data[6] = Date_of_Birth;

                            PutData putData;
                            if(User_or_Rider.contains("User")) { putData = new PutData("http://"+"192.168.10.5"+"/grocery/android/user_register.php", "POST", field, data);}
                            else {putData = new PutData("http://"+ip+"/grocery/android/rider_register.php", "POST", field, data);}
                            if (putData.startPut()) {
                                if (putData.onComplete()) {
                                    String result = putData.getResult();
                                    Log.i(result, "run: "+result);
                                    if (result.equals("Sign Up Success"))
                                    {
                                        Intent intent=new Intent(getApplicationContext(),LoginActivity.class);
                                        startActivity(intent);
                                        finish();

                                    }
                                    else if (result.equals("0")){Toast.makeText(getApplicationContext(),"Email or Phone Number Already Taken",Toast.LENGTH_LONG).show();}
                                    else if (result.equals("00")){Toast.makeText(getApplicationContext(),"Email Registered With Rider",Toast.LENGTH_LONG).show();}
                                    else {Toast.makeText(RegistrationActivity.this,"Data not Send",Toast.LENGTH_LONG).show();}
                                }
                            }
                        }
                    });

                }

            }
        });

        ActionBar actionBar = getSupportActionBar();
        if (actionBar != null) {
            actionBar.setDisplayHomeAsUpEnabled(true);
        }

    }
    public boolean onOptionsItemSelected(MenuItem item){
        switch (item.getItemId()) {
            case android.R.id.home:
                Intent i=new Intent(this,LoginActivity.class);
                startActivity(i);
                finish();
                return true;
        }
        return super.onOptionsItemSelected(item);
    }

    public boolean onCreateOptionsMenu(Menu menu) {
        return true;
    }

}

