package com.example.foodbyte.ui.cart;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.example.foodbyte.PutData;
import com.example.foodbyte.R;

import java.util.List;

import static android.content.ContentValues.TAG;
import static android.content.Context.MODE_PRIVATE;

public class MyAdapter2 extends RecyclerView.Adapter<ImageViewHOlder> {
    RecyclerView recyclerView;
    private Context context;
    TextView price,name,total;
    private List<ModelImage2> imageList2;
    String g_total;

    public MyAdapter2(Context context, List<com.example.foodbyte.ui.cart.ModelImage2> imageList2) {
        this.context = context;
        this.imageList2 = imageList2;
        Log.i(TAG, "MyAdapter2: "+imageList2);
    }

    @NonNull
    @Override
    public ImageViewHOlder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.checkout_receipt, parent, false);
        Log.i(TAG, "onCreateViewHolder: " + imageList2);
        price = view.findViewById(R.id.prod_price);
        name = view.findViewById(R.id.prod_name);
        total=view.findViewById(R.id.total);
        recyclerView = view.findViewById(R.id.receipt_recyclerView);


        return new ImageViewHOlder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ImageViewHOlder holder, final int position) {
        Log.i(TAG, "onBindViewHolder: "+imageList2);
        name.setText(imageList2.get(position).getName().toString());
        price.setText(imageList2.get(position).getPrice().toString());
    }

    @Override
    public int getItemCount() {
        return imageList2.size();
    }


}