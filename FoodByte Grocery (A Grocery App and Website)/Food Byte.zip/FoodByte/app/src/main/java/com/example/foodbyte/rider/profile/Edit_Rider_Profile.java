package com.example.foodbyte.rider.profile;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.method.HideReturnsTransformationMethod;
import android.text.method.PasswordTransformationMethod;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.foodbyte.PutData;
import com.example.foodbyte.R;
import com.example.foodbyte.ui.profile.Edit_Profile;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

import static android.content.ContentValues.TAG;

public class Edit_Rider_Profile extends AppCompatActivity {
    EditText name,phone,current_password,new_password,address;
    Button save;
    String new_name,new_phone,new_address,current_pass,new_pass,user_id,ip;
    ImageView eye1,eye2;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.fragment_rider_profile_edit);

        ActionBar actionBar = getSupportActionBar();
        actionBar.setHomeAsUpIndicator(R.drawable.ic_baseline_close_24);
        actionBar.setDisplayHomeAsUpEnabled(true);

        SharedPreferences editor = getSharedPreferences("user", MODE_PRIVATE);
        user_id=editor.getString("user",null);
        SharedPreferences editor1 = getSharedPreferences("ip", Context.MODE_PRIVATE);
        ip=editor1.getString("ip",null);
        Log.i(TAG, "ip: "+ip);

        name=findViewById(R.id.name);
        phone=findViewById(R.id.phone);
        address=findViewById(R.id.address);
        current_password=findViewById(R.id.current_password);
        new_password=findViewById(R.id.new_password);
        eye1=findViewById(R.id.eye1);
        eye2=findViewById(R.id.eye2);
        save=findViewById(R.id.save);

        fetch_profile(user_id);

        eye1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(current_password.getTransformationMethod().equals(PasswordTransformationMethod.getInstance())){
                    current_password.setTransformationMethod(HideReturnsTransformationMethod.getInstance());
                }
                else{current_password.setTransformationMethod(PasswordTransformationMethod.getInstance());}
            }
        });
        eye2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(new_password.getTransformationMethod().equals(PasswordTransformationMethod.getInstance())){
                    new_password.setTransformationMethod(HideReturnsTransformationMethod.getInstance());
                }
                else{new_password.setTransformationMethod(PasswordTransformationMethod.getInstance());}
            }
        });
        save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(name.getText().length()==0)
                {
                    name.requestFocus();
                    name.setError("FIELD CANNOT BE EMPTY");
                }
                else if(phone.getText().length()==0)
                {
                    phone.requestFocus();
                    phone.setError("FIELD CANNOT BE EMPTY");
                }
                else if(phone.getText().length()<11 || phone.getText().length()>11 || !(android.util.Patterns.PHONE.matcher(phone.getText()).matches()))
                {
                    phone.requestFocus();
                    phone.setError("Enter Valid Phone Number");
                }
                else if(address.getText().length()==0)
                {
                    address.requestFocus();
                    address.setError("FIELD CANNOT BE EMPTY");
                }
                else if (current_password.getText().length()==0)
                {
                    current_password.requestFocus();
                    current_password.setError("Enter Password to Save changes");
                }
                else if (new_password.getText().length()==0)
                {
                    new_password.requestFocus();
                    new_password.setError("Enter old/new to Save changes");
                }
                else {
                    new_name=name.getText().toString();
                    new_phone=phone.getText().toString();
                    new_address=address.getText().toString();
                    current_pass=current_password.getText().toString();
                    new_pass=new_password.getText().toString();

                    Handler handler = new Handler(Looper.getMainLooper());
                    handler.post(new Runnable() {
                        @Override
                        public void run() {
                            //Starting Write and Read data with URL
                            //Creating array for parameters
                            String[] field = new String[5];
                            field[0] = "Rider_Id";
                            field[1] = "Name";
                            field[2] = "Phone";
                            field[3] = "Address";
                            field[4] = "Password";

                            //Creating array for data
                            String[] data = new String[5];
                            data[0] = user_id;
                            data[1] = new_name;
                            data[2] = new_phone;
                            data[3] = new_address;
                            data[4] = new_pass;

                            //Toast.makeText(getApplicationContext(), field[0]+" "+data[0], Toast.LENGTH_LONG).show();
                            PutData putData = new PutData("http://"+ip+"/grocery/android/change_rider_profile.php", "POST", field, data);
                            Log.i(TAG, "putdata: "+putData.getData());
                            if (putData.startPut()) {
                                if (putData.onComplete()) {
                                    String result = putData.getResult();
                                    Log.i(TAG, "run: "+result);
                                    if (result.equals("Success") == true)
                                    {

                                        //  Intent intent=new Intent(RegistrationActivity.this,Home.class);
                                        //startActivity(intent);
                                        Toast.makeText(getApplicationContext(), result,Toast.LENGTH_LONG).show();
                                        Log.i(TAG, "data added");
                                        // Toast.makeText(SignUp.this,"data added",Toast.LENGTH_LONG).show();
                                    }
                                    else
                                    {
                                        Toast.makeText(getApplicationContext(), result,Toast.LENGTH_LONG).show();
                                        Log.i(TAG, "data not added");
                                        Log.i(TAG, "run: ");
                                    }
                                    //End ProgressBar (Set visibility to GONE)
                                    //Log.i("PutData", result);
                                }
                            }
                            //End Write and Read data with URL
                        }
                    });

                }
            }
        });
    }
    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                this.finish();
                return true;
        }
        return super.onOptionsItemSelected(item);
    }

    public void fetch_profile(String user_id){
        String url = "http://"+ip+"/grocery/android/get_rider_edit_profile.php";
        final String text = user_id;
        StringRequest stringRequest = new StringRequest(Request.Method.POST, url, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                Log.i(TAG, "get rider edit profile: "+response);
                //Toast.makeText(getApplicationContext(), response, Toast.LENGTH_LONG).show();
                try {
                    JSONObject jsonObject = new JSONObject(response);
                    String succes = jsonObject.getString("success");
                    JSONArray jsonArray = jsonObject.getJSONArray("data");
                    //Log.i(TAG, "onResponse: "+succes);
                    if(succes.equals("1")){
                        for(int i=0;i<jsonArray.length();i++){
                            JSONObject object = jsonArray.getJSONObject(i);
                            Log.i(TAG, "onResponse: "+object);
                            name.setText(object.getString("name"));
                            phone.setText(object.getString("phone"));
                            address.setText(object.getString("address"));
                            current_password.setText(object.getString("password"));
                            new_password.setText(object.getString("password"));
                            Log.i(TAG, "afterget1: "+name+address+phone);

                        }
                    }


                } catch (JSONException e) {
                    e.printStackTrace();
                    Log.i(TAG, "excep: ");
                }

            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(getApplicationContext(), error.toString(), Toast.LENGTH_LONG).show();
            }
        }) {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String, String> params = new HashMap<String, String>();
                params.put("user_id", text);
                Log.i(TAG, "getParams: "+params);
                return params;
            }


        };
        RequestQueue requestQueue = Volley.newRequestQueue(getApplicationContext());
        requestQueue.add(stringRequest);
    }


}
