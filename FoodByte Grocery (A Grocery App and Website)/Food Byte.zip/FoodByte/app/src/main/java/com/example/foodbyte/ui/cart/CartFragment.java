package com.example.foodbyte.ui.cart;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.android.volley.AuthFailureError;
import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.foodbyte.PutData;
import com.example.foodbyte.R;
import com.squareup.picasso.Picasso;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static android.content.ContentValues.TAG;
import static android.content.Context.MODE_PRIVATE;

public class CartFragment extends Fragment {
    RecyclerView recyclerView;
    Button check_out,add_recom_cart;
    TextView tv_name,tv_price;
    MyAdapter myAdapter;
    String user_name,ip,recom_id,recom_mart_id;
    List<ModelImage> imageList;
    ModelImage modelImage;
    ImageView img;
    String  Python_adress1="http://192.168.10.5:5000/com1";
    LinearLayoutManager linearLayoutManager;
    final ArrayList<Double> Arrayid = new ArrayList<Double>(200);
    final ArrayList<Double> Arraylatitude = new ArrayList<Double>(300);
    final ArrayList<Double> Arraylongitude = new ArrayList<Double>(300);
    final ArrayList<Double> Arraydistance = new ArrayList<Double>(300);

    //private CartViewModel cartViewModel;
    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        // cartViewModel = new ViewModelProvider(this).get(CartViewModel.class);
        View root = inflater.inflate(R.layout.fragment_cart, container, false);
        recyclerView = root.findViewById(R.id.car_recyclerView);
        linearLayoutManager = new LinearLayoutManager(getContext());
        recyclerView.setLayoutManager(linearLayoutManager);
        imageList = new ArrayList<>();
        img=root.findViewById(R.id.rec_image);
        tv_name=root.findViewById(R.id.tv_name);
        tv_price=root.findViewById(R.id.tv_price);
        add_recom_cart=root.findViewById(R.id.add_recom_cart);
        check_out = root.findViewById(R.id.checkout);
        myAdapter = new MyAdapter(getContext(), imageList);

        //fetchImages();

        recyclerView.setAdapter(myAdapter);
        SharedPreferences editor = getActivity().getSharedPreferences("user", MODE_PRIVATE);
        user_name = editor.getString("user", null);
        SharedPreferences editor1 = getActivity().getSharedPreferences("ip", Context.MODE_PRIVATE);
        ip=editor1.getString("ip",null);
        Log.i(TAG, "ip: "+ip);

        clicklistener(user_name);

        SharedPreferences editor3 = getActivity().getSharedPreferences("recom_id", MODE_PRIVATE);
        recom_id = editor3.getString("recom_id", null);

        add_recom_cart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) { Add_recom_cart(); }
        });
        check_out.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i=new Intent(getContext(),Checkout.class);
                startActivity(i);
            }
        });

        return root;
    }

    public void clicklistener(String txt) {
        imageList.clear();
        recyclerView.removeAllViews();
        imageList.removeAll(imageList);
        String url = "http://"+ip+"/grocery/display_cart_item.php";
        final String text = txt;
        StringRequest stringRequest = new StringRequest(Request.Method.POST, url, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                //Toast.makeText(getActivity().getApplicationContext(), response.trim(), Toast.LENGTH_LONG).show();
                Log.i(TAG, "display cart: "+response);
                try {
                    JSONObject jsonObject = new JSONObject(response);
                    String succes = jsonObject.getString("success");
                    JSONArray jsonArray = jsonObject.getJSONArray("data");
                    //Log.i(TAG, "onResponse: "+succes);

                    String id = "", imageurl = "",url= "",price="",name= "", category= "",quantity="",mart="";
                    if (succes.equals("1")) {

                        String id1="";
                        for (int i = 0; i < jsonArray.length(); i++) {
                            JSONObject object = jsonArray.getJSONObject(i);
                            Log.i(TAG, "onResponse: " + object);
                            id = object.getString("id");
                            imageurl = object.getString("image");
                            category = object.getString("category");
                            url = "http://"+ip+"/grocery/images/" + category + "/" + imageurl;
                            price = object.getString("price");
                            name = object.getString("name");
                            quantity=object.getString("quantity");
                            mart=object.getString("mart");
                            Log.i(TAG, "id: " + id + " " + price + " " + name);
                            Log.i(TAG, "last prod id: "+id);
                            id1=id;
                            SharedPreferences.Editor editor = getContext().getSharedPreferences("recom_mart_id", MODE_PRIVATE).edit();
                            editor.putString("recom_mart_id", mart);
                            editor.apply();

                            modelImage =new ModelImage(id,url,name,price,quantity,mart,user_name);
                            imageList.add(modelImage);
                            myAdapter.notifyDataSetChanged();
                        }
                        Log.i(TAG, "id1: "+id1);
                        getMLnames(id1);

                    }


                } catch (JSONException e) {
                    e.printStackTrace();
                }

            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(getActivity().getApplicationContext(), error.toString(), Toast.LENGTH_LONG).show();
            }
        }) {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String, String> params = new HashMap<String, String>();
                params.put("user_id", text);
                return params;
            }


        };
        RequestQueue requestQueue = Volley.newRequestQueue(getContext().getApplicationContext());
        requestQueue.add(stringRequest);
    }

    public double distance(double lat1, double lat2, double lon1, double lon2) {

        // The math module contains a function
        // named toRadians which converts from
        // degrees to radians.
        lon1 = Math.toRadians(lon1);
        lon2 = Math.toRadians(lon2);
        lat1 = Math.toRadians(lat1);
        lat2 = Math.toRadians(lat2);

        // Haversine formula
        double dlon = lon2 - lon1;
        double dlat = lat2 - lat1;
        double a = Math.pow(Math.sin(dlat / 2), 2)
                + Math.cos(lat1) * Math.cos(lat2)
                * Math.pow(Math.sin(dlon / 2), 2);

        double c = 2 * Math.asin(Math.sqrt(a));

        // Radius of earth in kilometers. Use 3956
        // for miles
        double r = 6371;
        double reult = c * r;
        // Arraydistance.add(reult);
        //  Toast.makeText(MainActivity2.this,Double.toString(reult)+"km",Toast.LENGTH_LONG).show();
        // calculate the result
        return (c * r);
    }

    public static double getMin(ArrayList<Double> inputArray) {
        double minValue = inputArray.get(0);
        for (int i = 1; i < inputArray.size(); i++) {
            if (inputArray.get(i) < minValue) {
                minValue = inputArray.get(i);
            }
        }
        return minValue;
    }

    public static double Findid(ArrayList<Double> inputArray, double value) {
        double Nearestid = 0;
        for (int i = 0; i < inputArray.size(); i++) {
            if (inputArray.get(i) == value) {
                Nearestid = i;
                // minValue = inputArray.get(i);
                break;
            }
        }
        return Nearestid;
    }
    public void getMLnames(String id)
    {
        String url = "http://"+ip+"/grocery/getMLname.php";
        final String text = id;
        StringRequest stringRequest = new StringRequest(Request.Method.POST, url, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                //  Toast.makeText(getActivity().getApplicationContext(), response.trim(), Toast.LENGTH_LONG).show();
                try {
                    JSONObject jsonObject = new JSONObject(response);
                    String succes = jsonObject.getString("success");
                    JSONArray jsonArray = jsonObject.getJSONArray("data");
                    //Log.i(TAG, "onResponse: "+succes);

                    String Ml_Name="",imageurl="",url="",price="",name="";
                    if(succes.equals("1")){
                        for(int i=0;i<jsonArray.length();i++){
                            JSONObject object = jsonArray.getJSONObject(i);
//                        Log.i(TAG, "onResponse: "+object);
                            Ml_Name = object.getString("Ml_Name");
                            Log.i(TAG, "Ml name: "+ Ml_Name);
                            recomendation(Ml_Name);
                        }
                    }



                } catch (JSONException e) {
                    e.printStackTrace();
                }

            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(getActivity().getApplicationContext(), error.toString(), Toast.LENGTH_LONG).show();
            }
        }){
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String, String> params = new HashMap<String, String>();
                params.put("recomment_id",text);
                return params;
            }


        };
        RequestQueue requestQueue= Volley.newRequestQueue(getContext().getApplicationContext());
        requestQueue.add(stringRequest);
    }
    public void recomendation( String text)
    {
        final String txt= text;
        StringRequest stringRequest=new StringRequest(Request.Method.POST, Python_adress1, new Response.Listener<String>() {
            //5 seconds
            @Override

            public void onResponse(String response) {
                //  Toast.makeText(getActivity().getApplicationContext(),response,Toast.LENGTH_LONG).show();
                //   et3.setText(response);
                ////////////////////////////////////////////////////////////////////////////////
                getrecommeditem(response);
                ////////////////////////////////////////////////////////////////////////////////
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                // et3.setText(error.toString());
                Toast.makeText(getActivity().getApplicationContext(),error.toString(),Toast.LENGTH_LONG).show();

            }
        }){
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String,String> stringMap=new HashMap<>();
                stringMap.put("num1",txt);
                //   stringMap.put("num2",num2);
                return stringMap;
            }
        };
        stringRequest.setRetryPolicy(new DefaultRetryPolicy(
                5000,
                DefaultRetryPolicy.DEFAULT_MAX_RETRIES,
                DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));

        RequestQueue requestQueue= Volley.newRequestQueue(getActivity().getApplicationContext());
        requestQueue.add(stringRequest);
    }
    public void getrecommeditem(String txt)
    {
        String url = "http://"+ip+"/grocery/product_recomend.php";
        final String text = txt;
        StringRequest stringRequest = new StringRequest(Request.Method.POST, url, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                //   Toast.makeText(getActivity().getApplicationContext(), response.trim(), Toast.LENGTH_LONG).show();
                try {
                    JSONObject jsonObject = new JSONObject(response);
                    String succes = jsonObject.getString("success");
                    JSONArray jsonArray = jsonObject.getJSONArray("data");
                    //Log.i(TAG, "onResponse: "+succes);

                    String id="",imageurl="",url="",price="",name="", category="";
                    if(succes.equals("1")){
                        for(int i=0;i<jsonArray.length();i++){
                            JSONObject object = jsonArray.getJSONObject(i);
                            Log.i(TAG, "onResponse: "+object);
                            id = object.getString("id");
                            name= object.getString("name");
                            imageurl= object.getString("image");
                            category=object.getString("category");
                            price=object.getString("price");
                            url = "http://"+ip+"/grocery/images/" + category + "/" + imageurl;
                            Toast.makeText(getActivity().getApplicationContext(),name+"it's id"+id+" Image url is"+imageurl+" category is"+category,Toast.LENGTH_LONG).show();
                            Picasso.get().load(url).into(img);
                            tv_name.setText(name);
                            tv_price.setText(price);
                            Toast.makeText(getContext(),id,Toast.LENGTH_LONG).show();
                            SharedPreferences.Editor editor = getContext().getSharedPreferences("recom_id", MODE_PRIVATE).edit();
                            editor.putString("recom_id", id);
                            editor.apply();

                        }
                    }



                } catch (JSONException e) {
                    e.printStackTrace();
                }

            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(getActivity().getApplicationContext(), error.toString(), Toast.LENGTH_LONG).show();
            }
        }){
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String, String> params = new HashMap<String, String>();
                params.put("product",text);
                return params;
            }


        };
        RequestQueue requestQueue= Volley.newRequestQueue(getActivity().getApplicationContext());
        requestQueue.add(stringRequest);
    }
    public void Add_recom_cart(){

        SharedPreferences editor4 = getActivity().getSharedPreferences("recom_mart_id", MODE_PRIVATE);
        recom_mart_id = editor4.getString("recom_mart_id", null);

        Handler handler = new Handler(Looper.getMainLooper());
        handler.post(new Runnable() {
            @Override
            public void run() {
                //Starting Write and Read data with URL
                //Creating array for parameters
                String[] field = new String[3];
                field[0] = "Cust_Id";
                field[1] = "Prod_Id";
                field[2] = "Mart_Id";


                //Creating array for data
                String[] data = new String[3];
                data[0] = user_name;
                data[1] = recom_id;
                data[2] = recom_mart_id;

                PutData putData = new PutData("http://"+ip+"/grocery/android/cart.php", "POST", field, data);
                Log.i(TAG, "putdata: "+putData.getData());
                if (putData.startPut()) {
                    if (putData.onComplete()) {
                        String result = putData.getResult();
                        Log.i(TAG, "run: "+result);
                        if (result.equals("Added To carts") == true)
                        {

                            //  Intent intent=new Intent(RegistrationActivity.this,Home.class);
                            //startActivity(intent);

                            Log.i(TAG, "data added");
                            clicklistener(user_name);
                            // Toast.makeText(SignUp.this,"data added",Toast.LENGTH_LONG).show();
                        }
                        else
                        {
                            // Toast.makeText(MyAdapter.this, result,Toast.LENGTH_LONG).show();
                            Log.i(TAG, "data not added");
                            Log.i(TAG, "run: ");
                        }
                        //End ProgressBar (Set visibility to GONE)
                        //Log.i("PutData", result);
                    }
                }
                //End Write and Read data with URL
            }
        });
    }

}
