package com.example.foodbyte.ui.cart;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.foodbyte.PutData;
import com.example.foodbyte.R;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static android.content.ContentValues.TAG;
import static android.content.Context.MODE_PRIVATE;
public class Checkout extends AppCompatActivity {

    RecyclerView recyclerView;
    Button select_rider;
    MyAdapter2 myAdapter2;
    String user_name;
    List<ModelImage2> imageList2;
    ModelImage2 modelImage2;
    TextView total;
    String user_id,ip,g_total;
    private LinearLayoutManager LayoutManager;
    final ArrayList<Double> Arrayid = new ArrayList<Double>(200);
    final ArrayList<Double> Arraylatitude = new ArrayList<Double>(300);
    final ArrayList<Double> Arraylongitude = new ArrayList<Double>(300);
    final ArrayList<Double> Arraydistance = new ArrayList<Double>(300);

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_checkout);

        ActionBar actionBar = getSupportActionBar();
        actionBar.setHomeAsUpIndicator(R.drawable.ic_baseline_close_24);
        actionBar.setDisplayHomeAsUpEnabled(true);
        SharedPreferences editor = getSharedPreferences("user", MODE_PRIVATE);
        user_id=editor.getString("user",null);
        SharedPreferences editor1 = getSharedPreferences("ip", Context.MODE_PRIVATE);
        ip=editor1.getString("ip",null);
        Log.i(TAG, "ip: "+ip);
        ///////////////////////////////////
        select_rider= findViewById(R.id.select_rider);
        recyclerView=findViewById(R.id.receipt_recyclerView);
        total=findViewById(R.id.total);
        LayoutManager= new LinearLayoutManager(Checkout.this);
        recyclerView.setLayoutManager(LayoutManager);
        imageList2 = new ArrayList<>();
        // Toast.makeText(Checkout.this,user_id,Toast.LENGTH_LONG).show()
        myAdapter2 = new MyAdapter2(Checkout.this, imageList2);
        recyclerView.setAdapter(myAdapter2);
        clicklistener(user_id);
        select_rider.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (Integer.parseInt(total.getText().toString())>0) {fetchlocation();}
                else Toast.makeText(getApplicationContext(),"Add some items to cart",Toast.LENGTH_LONG).show();
            }
        });

    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                this.finish();
                return true;
        }
        return super.onOptionsItemSelected(item);
    }

    public void clicklistener(String txt){

        String url = "http://"+ip+"/grocery/display_receipt.php";
        final String text = txt;
        StringRequest stringRequest = new StringRequest(Request.Method.POST, url, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                Log.i(TAG, "display receipt: "+response);
                //Toast.makeText(Checkout.this, response.trim(), Toast.LENGTH_LONG).show();
                try {
                    JSONObject jsonObject = new JSONObject(response);
                    String succes = jsonObject.getString("success");
                    JSONArray jsonArray = jsonObject.getJSONArray("data");
                    //Log.i(TAG, "onResponse: "+succes);

                    String price="",name= "",quantity="",grand_total="0";
                    if (succes.equals("1")) {
                        for (int i = 0; i < jsonArray.length(); i++) {
                            JSONObject object = jsonArray.getJSONObject(i);
                            Log.i(TAG, "onResponse: " + object);

                            price = object.getString("price");
                            name = object.getString("name");
                            quantity=object.getString("quantity");
                            int prod_total=Integer.parseInt(price) * Integer.parseInt(quantity);
                            price=String.valueOf(prod_total);
                            grand_total=String.valueOf(Integer.parseInt(price)+Integer.parseInt(grand_total));
                            Log.i(TAG, "total: "+grand_total);
                            total.setText(grand_total);
                            modelImage2 =new ModelImage2(name,price);
                            //  imageList.add(modelImage);
                            imageList2.add(modelImage2);
                            // myAdapter.notifyDataSetChanged();
                            myAdapter2.notifyDataSetChanged();
                        }

                    }


                } catch (JSONException e) {
                    e.printStackTrace();
                }

            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(getApplicationContext(), error.toString(), Toast.LENGTH_LONG).show();
            }
        }) {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String, String> params = new HashMap<String, String>();
                params.put("user_id", text);
                return params;
            }


        };
        RequestQueue requestQueue = Volley.newRequestQueue(getApplicationContext());
        requestQueue.add(stringRequest);
    }
    public void fetchlocation(){

        StringRequest request = new StringRequest(Request.Method.POST, "http://"+ip+"/grocery/Location/locationget.php",
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        Toast.makeText(Checkout.this,response.trim(),Toast.LENGTH_LONG).show();
                        try {
                            JSONObject jsonObject = new JSONObject(response);
                            String succes = jsonObject.getString("success");
                            JSONArray jsonArray = jsonObject.getJSONArray("data");
                            Log.i(TAG, "onResponse: "+succes);
                            if(succes.equals("1")){
                                for(int i=0;i<jsonArray.length();i++){
                                    JSONObject object = jsonArray.getJSONObject(i);

                                    String id = object.getString("id");
                                    String latitude = object.getString("latitude");
                                    String longitude= object.getString("longitude");

                                    Log.i(id, "onResponse: "+id);

                                    //   Arrayid[i]=Double.parseDouble(id);
                                    Arrayid.add(Double.parseDouble(id));

                                    Arraylatitude.add(Double.parseDouble(latitude));
                                    // Arraylatitude.add(23.23);
                                    //Arraylatitude.add(23.2343);

                                    // Arraylongitude[i]=Double.parseDouble(longitude);
                                    Arraylongitude.add(Double.parseDouble(longitude));
                                    // Arrayid[i]=Double.parseDouble(id);
                                    Double rest=null;
                                    //  Toast.makeText(MainActivity2.this, Integer.toString(i),Toast.LENGTH_LONG).show();
                                    rest =distance(Arraylatitude.get(i), 53.31861111111111, Arraylongitude.get(i), -1.6997222222222223);
                                    Arraydistance.add(rest);
                                    Toast.makeText(Checkout.this,Double.toString(rest),Toast.LENGTH_LONG).show();
                                    // Toast.makeText(MainActivity2.this,Double.toString(Arraydistance[]),Toast.LENGTH_LONG).show();

//                                    // driver code
//                                    public static void main(String[] args)
//                                    {
//                                        double lat1 = 53.32055555555556;
//                                        double lat2 = 53.31861111111111;
//                                        double lon1 = -1.7297222222222221;
//                                        double lon2 = -1.6997222222222223;
//                                        System.out.println( + " K.M");
//                                    }

                                    // Toast.makeText(MainActivity2.this,id+"  "+latitude+"   "+longitude,Toast.LENGTH_LONG).show();
                                }
                                // Toast.makeText(MainActivity2.this,Arraydistance.size(),Toast.LENGTH_LONG).show();
                                //    Toast.makeText(MainActivity2.this,Arraylatitude.size(),Toast.LENGTH_LONG).show();
                                //  Toast.makeText(MainActivity2.this,Integer.toString(Arraylatitude.size()),Toast.LENGTH_LONG).show();
                                double ret= getMin(Arraydistance);
                                //Toast.makeText(Checkout.this,Double.toString(ret),Toast.LENGTH_LONG).show();
                                //Toast.makeText(Checkout.this,Integer.toString(Arrayid.size()),Toast.LENGTH_LONG).show();
                                double nearest= Findid(Arraydistance, ret);
                                //Toast.makeText(Checkout.this,Double.toString(nearest),Toast.LENGTH_LONG).show();
                                Toast.makeText(Checkout.this,"Rider id: "+Double.toString(Arrayid.get((int)nearest)),Toast.LENGTH_LONG).show();
                                Toast.makeText(getApplicationContext(),"you order is placed successfully",Toast.LENGTH_LONG).show();
                                add_rider_notification(Double.toString(Arrayid.get((int)nearest)),user_id);
                            }



                        } catch (JSONException e) {
                            e.printStackTrace();
                        }


                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(Checkout.this, error.getMessage(), Toast.LENGTH_SHORT).show();
            }

        });

        RequestQueue requestQueue = Volley.newRequestQueue(Checkout.this);
        requestQueue.add(request);
        //  getMin(Arraydistance);

    }
    public double distance(double lat1, double lat2, double lon1, double lon2)
    {

        // The math module contains a function
        // named toRadians which converts from
        // degrees to radians.
        lon1 = Math.toRadians(lon1);
        lon2 = Math.toRadians(lon2);
        lat1 = Math.toRadians(lat1);
        lat2 = Math.toRadians(lat2);

        // Haversine formula
        double dlon = lon2 - lon1;
        double dlat = lat2 - lat1;
        double a = Math.pow(Math.sin(dlat / 2), 2)
                + Math.cos(lat1) * Math.cos(lat2)
                * Math.pow(Math.sin(dlon / 2),2);

        double c = 2 * Math.asin(Math.sqrt(a));

        // Radius of earth in kilometers. Use 3956
        // for miles
        double r = 6371;
        double reult= c*r;
        // Arraydistance.add(reult);
        //  Toast.makeText(MainActivity2.this,Double.toString(reult)+"km",Toast.LENGTH_LONG).show();
        // calculate the result
        return(c * r);
    }
    public static double getMin(ArrayList<Double> inputArray){
        double minValue = inputArray.get(0);
        for(int i=1;i<inputArray.size();i++){
            if(inputArray.get(i) < minValue){
                minValue = inputArray.get(i);
            }
        }
        return minValue;
    }
    public static double Findid(ArrayList<Double> inputArray, double value){
        double Nearestid = 0;
        for(int i=0;i<inputArray.size();i++){
            if(inputArray.get(i) == value){
                Nearestid= i;
                // minValue = inputArray.get(i);
                break;
            }
        }
        return Nearestid;
    }


    public void add_rider_notification(final String rider, final String user){
        Log.i(TAG, "rider pass: "+rider);
        Log.i(TAG, "user pass: "+user);

        Handler handler = new Handler(Looper.getMainLooper());
        handler.post(new Runnable() {
            @Override
            public void run() {
                //Starting Write and Read data with URL
                //Creating array for parameters
                String[] field = new String[2];
                field[0] = "Cust_Id";
                field[1] = "Rider_Id";


                //Creating array for data
                String[] data = new String[2];
                data[0] = user;
                data[1] = rider;

                PutData putData = new PutData("http://"+ip+"/grocery/android/add_rider_notification.php", "POST", field, data);
                Log.i(TAG, "putdata: "+putData.getData());
                if (putData.startPut()) {
                    if (putData.onComplete()) {
                        String result = putData.getResult();
                        Log.i(TAG, "run: "+result);
                        if (result.equals("notification added") == true)
                        {

                            //  Intent intent=new Intent(RegistrationActivity.this,Home.class);
                            //startActivity(intent);

                            Log.i(TAG, "data added");
                            // Toast.makeText(SignUp.this,"data added",Toast.LENGTH_LONG).show();
                        }
                        else
                        {
                            // Toast.makeText(MyAdapter.this, result,Toast.LENGTH_LONG).show();
                            Log.i(TAG, "data not added");
                            Log.i(TAG, "run: ");
                        }
                        //End ProgressBar (Set visibility to GONE)
                        //Log.i("PutData", result);
                    }
                }
                //End Write and Read data with URL
            }
        });
    }

}