package com.example.foodbyte.ui.profile;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.foodbyte.LoginActivity;
import com.example.foodbyte.R;
import com.example.foodbyte.ui.cart.ModelImage;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static android.content.ContentValues.TAG;
import static android.content.Context.MODE_PRIVATE;

public class ProfileFragment extends Fragment {
   // private ProfileViewModel profileViewModel;
    ImageView imageView;
    ListView listView;
    String user_id,ip;
    String name="",email="",phone="";
    AlertDialog.Builder builder;
    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        View root = inflater.inflate(R.layout.fragment_profile, container, false);
        SharedPreferences editor = getActivity().getSharedPreferences("user", MODE_PRIVATE);
        user_id=editor.getString("user",null);
        SharedPreferences editor1 = getActivity().getSharedPreferences("ip", Context.MODE_PRIVATE);
        ip=editor1.getString("ip",null);
        Log.i(TAG, "ip: "+ip);

        imageView= root.findViewById(R.id.bgimgview);
        listView = root.findViewById(R.id.itemlist);

        builder = new AlertDialog.Builder(getActivity());

        clicklistener(user_id);
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                if (position == 3)
                {
                    Intent intent= new Intent(getActivity(),Edit_Profile.class);
                    startActivity(intent);
                }
                if (position == 4)
                {
                    Toast.makeText(getContext(),"Notification",Toast.LENGTH_LONG).show();
                    builder.setMessage("No notifications yet") .setTitle("Password Reset");

                    //Setting message manually and performing action on button click
                    builder.setMessage("No notifications yet")
                            .setCancelable(false)
                            .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                                        public void onClick(DialogInterface dialog, int id) {
                                            Toast.makeText(getContext(),"Notify clicked",Toast.LENGTH_LONG).show();
                                        }
                                    }
                            );
                    //Creating dialog box
                    AlertDialog alert = builder.create();
                    //Setting the title manually
                    alert.setTitle("Notifications");
                    alert.show();

                }
                if (position == 5)
                {
                    Intent intent= new Intent(getActivity(), LoginActivity.class);
                    startActivity(intent);
                }
            }
        });
        return root;
    }

    //private void setContentView(int activity_main) { }

    public void clicklistener(String txt) {
        String url = "http://"+ip+"/grocery/android/get_user_profile.php";
        final String text = txt;
        StringRequest stringRequest = new StringRequest(Request.Method.POST, url, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                Log.i(TAG, "get user profile: "+response);
                //Toast.makeText(getActivity().getApplicationContext(), response, Toast.LENGTH_LONG).show();
                try {
                    JSONObject jsonObject = new JSONObject(response);
                    String succes = jsonObject.getString("success");
                    JSONArray jsonArray = jsonObject.getJSONArray("data");
                    Log.i(TAG, "onResponse: "+succes);
                    if(succes.equals("1")){
                        for(int i=0;i<jsonArray.length();i++){
                            JSONObject object = jsonArray.getJSONObject(i);
                            Log.i(TAG, "onResponse: "+object);
                            name= object.getString("name");
                            email=object.getString("email");
                            phone=object.getString("phone");
                            Log.i(TAG, "afterget1: "+name+email+phone);
                            String[] detail = new String[]
                                    {name,email,phone,"Edit","Notification","Logout"};
                            //  private ArrayList<String> data;
                            int[] listview_icon = new int[]
                                    {R.drawable.ic_baseline_account_box_24,R.drawable.ic_baseline_email_24,
                                            R.drawable.ic_baseline_phone_24,R.drawable.ic_baseline_edit_24,R.drawable.ic_notifications_black_24dp,
                                            R.drawable.ic_baseline_power_settings_new_24};
                            List<HashMap<String,String>> list= new ArrayList<HashMap<String, String>>();
                            for (int j =0 ; j<6 ; j++)
                            {
                                HashMap<String,String> hm =new HashMap<String, String>();
                                hm.put("Listdetail",detail[j]);
                                hm.put("listicon",Integer.toString(listview_icon[j]));

                                list.add(hm);
                            }
                            String[] from = {
                                    "listicon","Listdetail"
                            };
                            int[] to ={R.id.foricon, R.id.foritem};
                            SimpleAdapter simpleAdapter =new SimpleAdapter(getActivity(),list,R.layout.fragment_profile_item,from,to);
                            listView.setAdapter(simpleAdapter);
                        }
                    }


                } catch (JSONException e) {
                    e.printStackTrace();
                    Log.i(TAG, "excep: ");
                }

            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(getActivity().getApplicationContext(), error.toString(), Toast.LENGTH_LONG).show();
            }
        }) {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String, String> params = new HashMap<String, String>();
                params.put("user_id", text);
                Log.i(TAG, "getParams: "+params);
                return params;
            }


        };
        RequestQueue requestQueue = Volley.newRequestQueue(getContext().getApplicationContext());
        requestQueue.add(stringRequest);
    }

}
