package com.example.foodbyte.ui.home;
import android.content.SharedPreferences;
import android.content.Context;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.VolleyLog;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.foodbyte.R;
import com.example.foodbyte.ui.grocery.GroceryFragment;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static android.content.ContentValues.TAG;

public class HomeFragment extends Fragment {
    ImageView Mart1,Mart2,Mart3;
    TextView people_mart;
    // private GroceryViewModel groceryViewModel;
    public View onCreateView(@NonNull final LayoutInflater inflater,
                             final ViewGroup container, Bundle savedInstanceState) {
        // groceryViewModel = new ViewModelProvider(this).get(GroceryViewModel.class);
        View root = inflater.inflate(R.layout.fragment_home, container, false);
        //final TextView textView = root.findViewById(R.id.text_grocery);
        /*groceryViewModel.getText().observe(getViewLifecycleOwner(), new Observer<String>() {
            @Override
            public void onChanged(@Nullable String s) {
                textView.setText(s);
            }
        });*/
        Mart1= root.findViewById(R.id.img_mart1);
        Mart2= root.findViewById(R.id.img_mart2);
        Mart3= root.findViewById(R.id.img_mart3);
        people_mart= root.findViewById(R.id.people_mart);
        Mart1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //String Mart_name= people_mart.getText().toString();
                SharedPreferences.Editor editor = getActivity().getApplicationContext().getSharedPreferences("mart_id", Context.MODE_PRIVATE).edit();
                editor.putString("mart_id", "1");
                editor.apply();
                Log.i(editor.toString(), "id: " + editor);
                GroceryFragment groceryFragment=new GroceryFragment();
                getFragmentManager().beginTransaction().replace(R.id.nav_host_fragment,groceryFragment).commit();
//                Bundle bundle=new Bundle();
//                bundle.putString("mart_name","01");
//                groceryFragment.setArguments(bundle);
                }
        });
        Mart2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //String Mart_name= people_mart.getText().toString();
                SharedPreferences.Editor editor = getActivity().getApplicationContext().getSharedPreferences("mart_id", Context.MODE_PRIVATE).edit();
                editor.putString("mart_id", "2");
                editor.apply();
                Log.i(editor.toString(), "id: " + editor);
                GroceryFragment groceryFragment=new GroceryFragment();
                getFragmentManager().beginTransaction().replace(R.id.nav_host_fragment,groceryFragment).commit();
//                Bundle bundle=new Bundle();
//                bundle.putString("mart_name","01");
//                groceryFragment.setArguments(b
            }
        });
        Mart3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //String Mart_name= people_mart.getText().toString();
                SharedPreferences.Editor editor = getActivity().getApplicationContext().getSharedPreferences("mart_id", Context.MODE_PRIVATE).edit();
                editor.putString("mart_id", "3");
                editor.apply();
                Log.i(editor.toString(), "id: " + editor);
                GroceryFragment groceryFragment=new GroceryFragment();
                getFragmentManager().beginTransaction().replace(R.id.nav_host_fragment,groceryFragment).commit();

//                Bundle bundle=new Bundle();
//                bundle.putString("mart_name","01");
//                groceryFragment.setArguments(bundle);
            }
        });
        return root;
    }
    public void makeJsonObjectRequest()
    {
        RequestQueue mRequestQueue = Volley.newRequestQueue(getActivity().getApplicationContext());
        String url = "http://my-site-name/sampleGET.php";
        StringRequest jsonObjReq = new StringRequest(
                Request.Method.GET,
                url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        Log.d("result:", response);
                        Toast.makeText(getActivity().getApplicationContext(), response, Toast.LENGTH_SHORT).show();
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        VolleyLog.d("err", "Error: " + error.getMessage());
                        makeJsonObjectRequest();
                    }
                }
        ){
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<>();
                params.put("name", "json");
                return params;
            }
        };
        mRequestQueue.add(jsonObjReq);
    }
}
