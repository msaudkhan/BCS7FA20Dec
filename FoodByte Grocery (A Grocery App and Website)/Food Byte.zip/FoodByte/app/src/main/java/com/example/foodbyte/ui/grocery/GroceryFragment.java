
package com.example.foodbyte.ui.grocery;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.SearchView;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.foodbyte.R;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static android.content.ContentValues.TAG;
import static android.content.Context.MODE_PRIVATE;

public class GroceryFragment extends Fragment {

    Button biscuit,candy,sweet,perfumes,Baby_Body_Care,Stationary,Pet_Foods,Vegetable,Beverages;
    RecyclerView recyclerView;
    MyAdapter myAdapter;
    List<ModelImage> imageList;
    ModelImage modelImage;
    LinearLayoutManager linearLayoutManager;
    Spinner backery_item;
    SearchView searchView;
    ArrayList list;
    ArrayAdapter adapter;
    String user_name,mart_id,ip;

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        View root = inflater.inflate(R.layout.fragment_grocery, container, false);
        biscuit=root.findViewById(R.id.biscuit);
        candy=root.findViewById(R.id.candy);
        sweet=root.findViewById(R.id.sweet);
        perfumes=root.findViewById(R.id.perfumes);
        Baby_Body_Care=root.findViewById(R.id.Baby_Body_Care);
        Stationary=root.findViewById(R.id.Stationary);
        Pet_Foods=root.findViewById(R.id.Pet_Foods);
        Vegetable=root.findViewById(R.id.Vegetable);
        Beverages=root.findViewById(R.id.Beverages);
        searchView=root.findViewById(R.id.searchView);

        SharedPreferences editor1 = getActivity().getSharedPreferences("ip", Context.MODE_PRIVATE);
        ip=editor1.getString("ip",null);
        Log.i(TAG, "ip: "+ip);

        list=new ArrayList();
        list.add("air freshner");
        list.add("baby body care");
        list.add("baby milk");
        list.add("beauty care");
        list.add("beverages");
        list.add("biscuit");
        list.add("body care");
        list.add("break fast");
        list.add("cake");
        list.add("cigaret");
        list.add("cleaning");
        list.add("hair care");
        list.add("diaper");
        list.add("kitchen");
        list.add("meat");
        list.add("milk");
        list.add("oral care");
        list.add("pasta");
        list.add("perfumes");
        list.add("sweet");
        list.add("pet food");
        list.add("toilet paper");
        list.add("stationary");
        list.add("vegetable");
        adapter = new ArrayAdapter<String>(getContext(), android.R.layout.simple_list_item_1,list);
        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                if(list.contains(query)){
                    adapter.getFilter().filter(query);
                    clicklistener(query);
                    Log.i(TAG, "onQueryTextSubmit: "+query);
                }else{
                    Toast.makeText(getContext(), "No Match found",Toast.LENGTH_LONG).show();
                }
                return false;
            }
            @Override
            public boolean onQueryTextChange(String newText) {
                adapter.getFilter().filter(newText);
                Log.i(TAG, "onQueryTextSubmit: "+newText);
                return false;
            }
        });

        biscuit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) { clicklistener("biscuit"); }
        });
        candy.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                clicklistener("candy");
            }
        });
        sweet.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                clicklistener("sweet");
            }
        });
        perfumes.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                clicklistener("perfumes");
            }
        });
        Baby_Body_Care.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) { clicklistener("baby body care"); }
        });
        Stationary.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                clicklistener("stationary");
            }
        });
        Pet_Foods.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                clicklistener("Pet Food");
            }
        });
        Vegetable.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                clicklistener("vegatable");
            }
        });
        Beverages.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                clicklistener("beverages");
            }
        });

       /* backery_item.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                String selectedItem = parent.getItemAtPosition(position).toString();
                clicklistener(selectedItem);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });*/
       /* for (int j=0;j<1;j++){
            GroceryFragment newFragment = new GroceryFragment();
            FragmentTransaction transaction = getFragmentManager().beginTransaction();
            transaction.replace(R.id.nav_host_fragment, newFragment);
            transaction.addToBackStack(null);
            Log.i(TAG, "refresh");
            transaction.commit();}*/
        recyclerView = root.findViewById(R.id.recyclerView);
        linearLayoutManager = new LinearLayoutManager(getContext());
        recyclerView.setLayoutManager(linearLayoutManager);
        imageList = new ArrayList<>();

        myAdapter = new MyAdapter(getContext(), imageList);
        fetchImages();
        recyclerView.setAdapter(myAdapter);

        SharedPreferences editor = getActivity().getSharedPreferences("user", MODE_PRIVATE);
        user_name=editor.getString("user",null);

        Log.i(TAG, "onCreateView: "+user_name);
        return root;
    }
    public void clicklistener(String txt) {
        imageList.clear();
        recyclerView.removeAllViews();
        imageList.removeAll(imageList);
        String url = "http://"+ip+"/grocery/postdata.php";
        final String text = txt;
        StringRequest stringRequest = new StringRequest(Request.Method.POST, url, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                //Toast.makeText(getActivity().getApplicationContext(), response.trim(), Toast.LENGTH_LONG).show();
                Log.i(TAG, "category : "+response);
                try {
                    JSONObject jsonObject = new JSONObject(response);
                    String succes = jsonObject.getString("success");
                    JSONArray jsonArray = jsonObject.getJSONArray("data");
                    //Log.i(TAG, "onResponse: "+succes);

                    String id="",imageurl="",url="",price="",name="";
                    if(succes.equals("1")){
                        for(int i=0;i<jsonArray.length();i++){
                            JSONObject object = jsonArray.getJSONObject(i);
                            Log.i(TAG, "onResponse: "+object);
                            id = object.getString("id");
                            imageurl = object.getString("image");
                            url = "http://"+ip+"/grocery/images/"+text+"/"+imageurl;
                            price=object.getString("price");
                            name= object.getString("name");
                            Log.i(TAG, "id: "+id+" "+price+" "+name);
                            Log.i(id, "onResponse: "+id);
                            modelImage = new ModelImage(id,url,name,price,user_name);
                            imageList.add(modelImage);
                            myAdapter.notifyDataSetChanged();
                        }
                    }



                } catch (JSONException e) {
                    e.printStackTrace();
                }

            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(getActivity().getApplicationContext(), error.toString(), Toast.LENGTH_LONG).show();
            }
        }){
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String, String> params = new HashMap<String, String>();
                params.put("category",text);
                return params;
            }


        };
        RequestQueue requestQueue= Volley.newRequestQueue(getContext().getApplicationContext());
        requestQueue.add(stringRequest);
    }
    public void fetchImages(){

        StringRequest request = new StringRequest(Request.Method.POST, "http://"+ip+"/grocery/fetchImage.php",
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {

                        try {
                            JSONObject jsonObject = new JSONObject(response);
                            String succes = jsonObject.getString("success");
                            JSONArray jsonArray = jsonObject.getJSONArray("data");
                            Log.i(TAG, "onResponse: "+succes);
                            if(succes.equals("1")){
                                for(int i=0;i<jsonArray.length();i++){
                                    JSONObject object = jsonArray.getJSONObject(i);

                                    String id = object.getString("id");
                                    String imageurl = object.getString("image");
                                    String url = "http://"+ip+"/grocery/images/cake/"+imageurl;
                                    String name= object.getString("name");
                                    String price=object.getString("price");
                                    //Log.i(id, "onResponse: "+id);

                                    modelImage = new ModelImage(id,url,name,price, user_name);
                                    imageList.add(modelImage);
                                    myAdapter.notifyDataSetChanged();

                                }
                            }



                        } catch (JSONException e) {
                            e.printStackTrace();
                        }


                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(getActivity().getApplicationContext(), error.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });

        RequestQueue requestQueue = Volley.newRequestQueue(getActivity().getApplicationContext());
        requestQueue.add(request);


    }


}
