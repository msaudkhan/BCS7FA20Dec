package com.example.foodbyte;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.Window;
import android.view.WindowManager;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;
import android.widget.TextView;

public class LauncherActivity extends AppCompatActivity {
    private int sleep=5000;
    TextView slogan,appname;
    ImageView imageView;
    Animation frombottom,fromtop,fromside;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);//will hide the title
        getSupportActionBar().hide(); //hide the title bar
        this.getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN); //show the activity in full screen
        setContentView(R.layout.activity_launcher);

        slogan=findViewById(R.id.slogan);
        appname=findViewById(R.id.appname);
        imageView=findViewById(R.id.imageView);
        frombottom= AnimationUtils.loadAnimation(this,R.anim.frombottom);
        fromtop= AnimationUtils.loadAnimation(this,R.anim.fromtop);
        fromside= AnimationUtils.loadAnimation(this,R.anim.fromside);
        slogan.setAnimation(frombottom);
        appname.setAnimation(fromtop);
        imageView.setAnimation(fromside);

        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                Intent i=new Intent(LauncherActivity.this,LoginActivity.class);
                startActivity(i);
                finish();
            }
        },sleep);
    }
}