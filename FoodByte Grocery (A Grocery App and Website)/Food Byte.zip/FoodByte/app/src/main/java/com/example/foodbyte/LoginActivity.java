package com.example.foodbyte;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.method.HideReturnsTransformationMethod;
import android.text.method.PasswordTransformationMethod;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.foodbyte.ui.grocery.GroceryFragment;
import com.example.foodbyte.ui.grocery.MyAdapter;
import com.example.foodbyte.ui.home.HomeFragment;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.net.URL;
import java.util.HashMap;
import java.util.Map;

import static android.content.ContentValues.TAG;

public class LoginActivity extends AppCompatActivity {

    private EditText username,password;
    private Button forgetpassword,loginbtn,newuser;
    ImageView eye;
    String email,pass,id="",ip;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);//will hide the title
        getSupportActionBar().hide(); //hide the title bar
        this.getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN); //show the activity in full screen
        setContentView(R.layout.activity_login);

        username=findViewById(R.id.username);
        password=findViewById(R.id.password);
        forgetpassword=findViewById(R.id.fogetpassword);
        loginbtn=findViewById(R.id.loginbtn);
        newuser=findViewById(R.id.newuser);
        eye=findViewById(R.id.eye);

        SharedPreferences.Editor editor = getApplicationContext().getSharedPreferences("ip", MODE_PRIVATE).edit();
        editor.putString("ip", "192.168.10.5");
        editor.apply();
        Log.i(editor.toString(), "ip: " + editor);
        SharedPreferences editor1 = getSharedPreferences("ip", Context.MODE_PRIVATE);
        ip=editor1.getString("ip",null);
        Log.i(TAG, "ip: "+ip);


        newuser.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i=new Intent(LoginActivity.this,RegistrationActivity.class);
                startActivity(i);
                finish();
            }
        });
        eye.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(password.getTransformationMethod().equals(PasswordTransformationMethod.getInstance())){
                    password.setTransformationMethod(HideReturnsTransformationMethod.getInstance());
                }
                else{password.setTransformationMethod(PasswordTransformationMethod.getInstance());}
            }
        });

        loginbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                email = username.getText().toString();
                pass = password.getText().toString();

                Handler handler = new Handler(Looper.getMainLooper());
                handler.post(new Runnable() {
                    @Override
                    public void run() {
                        //Starting Write and Read data with URL
                        //Creating array for parameters
                        String[] field = new String[2];
                        field[0] = "username";
                        field[1] = "password";

                        String[] data = new String[2];
                        data[0] = email;
                        data[1] = pass;
                        PutData putData = new PutData("http://"+ip+"/grocery/android/login.php", "POST", field, data);
                        Log.i(putData.result_data, "run before: ");
                        if (putData.startPut()) {
                            if (putData.onComplete()) {
                                String result = putData.getResult();
                                Log.i(result, "run: "+result);
                                if (result.equals("customer")){

                                    fetch_user_id(email);//username.getText().toString();
                                    Toast.makeText(getApplicationContext(),"Customer",Toast.LENGTH_LONG).show();
                                }
                                else if (result.equals("rider")){
                                    fetch_rider_id(email);

                                    Toast.makeText(getApplicationContext(),"Rider",Toast.LENGTH_LONG).show();
                                }
                                else {Toast.makeText(getApplicationContext(),"Wrong Email or Password",Toast.LENGTH_LONG).show();}
                            }
                        }


//                        startActivity(i);
//                        finish();

                    }
                });
            }
        });

        forgetpassword.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i=new Intent(LoginActivity.this,Forget_Password.class);
                startActivity(i);
                finish();
            }
        });
    }

    private void fetch_user_id(String email) {
        String url = "http://"+ip+"/grocery/android/get_user_id.php";
        final String text = email;

        StringRequest stringRequest = new StringRequest(Request.Method.POST, url, new Response.Listener<String>() {

            @Override
            public void onResponse(String response) {
                //response=response.substring(text.length());
                //Toast.makeText(getApplicationContext(), response, Toast.LENGTH_LONG).show();
                try {
                    JSONObject jsonObject = new JSONObject(response);
                    String succes = jsonObject.getString("success");
                    JSONArray jsonArray = jsonObject.getJSONArray("data");
                    Log.i(TAG, "onResponse: "+succes);
                    if(succes.equals("1")){
                        for(int i=0;i<jsonArray.length();i++){
                            JSONObject object = jsonArray.getJSONObject(i);
                            Log.i(TAG, "onResponse: "+object);
                            id=object.getString("id");
                            Log.i(TAG, "idd: "+id);
                            Intent intent=new Intent(getApplicationContext(),Home.class);
                            SharedPreferences.Editor editor = getApplicationContext().getSharedPreferences("user", MODE_PRIVATE).edit();
                            editor.putString("user", id);
                            editor.apply();
                            Log.i(editor.toString(), "id: " + editor);
                            startActivity(intent);
                            finish();
                        }
                    }


                } catch (JSONException e) {
                    e.printStackTrace();
                    Log.i(TAG, "excep: ");
                }

            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(getApplicationContext(), error.toString(), Toast.LENGTH_LONG).show();
            }
        }) {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String, String> params = new HashMap<String, String>();
                params.put("user_id", text);
                Log.i(TAG, "getParams: "+params);
                return params;
            }


        };
        RequestQueue requestQueue = Volley.newRequestQueue(getApplicationContext());
        requestQueue.add(stringRequest);

    }
    private void fetch_rider_id(String email) {
        String url = "http://"+ip+"/grocery/android/get_rider_id.php";
        final String text = email;

        StringRequest stringRequest = new StringRequest(Request.Method.POST, url, new Response.Listener<String>() {

            @Override
            public void onResponse(String response) {
                //response=response.substring(text.length());
                //Toast.makeText(getApplicationContext(), response, Toast.LENGTH_LONG).show();
                try {
                    JSONObject jsonObject = new JSONObject(response);
                    String succes = jsonObject.getString("success");
                    JSONArray jsonArray = jsonObject.getJSONArray("data");
                    Log.i(TAG, "onResponse: "+succes);
                    if(succes.equals("1")){
                        for(int i=0;i<jsonArray.length();i++){
                            JSONObject object = jsonArray.getJSONObject(i);
                            Log.i(TAG, "onResponse: "+object);
                            id=object.getString("id");
                            Log.i(TAG, "idd: "+id);
                            Intent intent=new Intent(getApplicationContext(), Rider_Home.class);
                            SharedPreferences.Editor editor = getApplicationContext().getSharedPreferences("user", MODE_PRIVATE).edit();
                            editor.putString("user", id);
                            editor.apply();
                            Log.i(editor.toString(), "id: " + editor);
                            startActivity(intent);
                            finish();
                        }
                    }


                } catch (JSONException e) {
                    e.printStackTrace();
                    Log.i(TAG, "excep: ");
                }

            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(getApplicationContext(), error.toString(), Toast.LENGTH_LONG).show();
            }
        }) {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String, String> params = new HashMap<String, String>();
                params.put("user_id", text);
                Log.i(TAG, "getParams: "+params);
                return params;
            }


        };
        RequestQueue requestQueue = Volley.newRequestQueue(getApplicationContext());
        requestQueue.add(stringRequest);

    }
}