<?php 
session_start();
     include 'conection.php';
     if (isset($_POST['submit'])) {
     	$email= $_POST['email'];
     	$pass= $_POST['pass'];
     	$q="SELECT Name,Id,Email FROM `mart owner` WHERE Email = '".$email."' AND  Password = '".$pass."'";
     	$result1 = mysqli_query($con,$q) or die(mysqli_error());
     	if(is_null($result1)){echo "failed".mysqli_error();}
     	else{
        if(mysqli_num_rows($result1) > 0 )
        { 
           foreach ($result1 as $key) {
               $_SESSION["name"]=$key['Name'];
               $_SESSION["id"]=$key['Id'];
               $_SESSION["email"]=$key["Email"];
               
               if ($_SESSION["email"]=="admin@local.com" && $_SESSION["id"]=="4") { 
                 header("Location:dashboard/Admin/dashboard.php");
               }
               elseif ($_SESSION["id"]=="1") {
                 header("Location:dashboard/Mart/Mart01/dashboard.php");
               }
               elseif ($_SESSION["id"]=="2") {
                 header("Location:dashboard/Mart/Mart02/dashboard.php");
               }
               elseif ($_SESSION["id"]=="3") {
                 header("Location:dashboard/Mart/Mart03/dashboard.php");
               }
               else{header("Location:index.php");}
               exit;
           }
        }
        else
        {
            echo 'The username or password are incorrect!';
        }}
     }
?>