<html>
  <head>
    <title>Admin Panel</title>
    <link rel="stylesheet" href="../css/dashboard.css">
  </head>
<?php session_start();
if (isset($_SESSION["name"])) {
  if ($_SESSION["email"]=="admin@local.com") {
?>
  <body>
    <header>
      <div class="left_area">
        <a href="../home.php"><h3>Food <span>Byte</span></h3></a>
      </div>
    </header>

    <div class="sidebar">
      <center>
        <img src="bil.jpg" class="profile_image" alt="">
        <h4>Bilal</h4>
      </center>
      <a href="dashboard.php"><span>Dashboard</span></a>
      <a href="insert.php"><span>Insert Item</span></a>
      <a href="update.php"><span>Update Item</span></a>
      <a href="delete.php"><span>Delete Item</span></a>
      <a href="show.php"><span>Show Items</span></a>
      <a href="../about.html"><span>About</span></a>
      <a href="../logout.php" class="logout_btn">Logout</a>
    </div>
    <div class="content">
      <h3>Welcome Admin</h3>
      <p>Here You can add,remove and update your website!</p>
      <?php
      include 'Tables.php';
      ?>
    </div>

<?php }
else{echo "Admin Can see dashboard ";?><br><a href="login.php">login</a><br>
     <a href="home.php">go back to home page</a>
 <?php }
}
else{echo "login first"; ?> <a href="login.php">login</a> <?php } ?>

</body>
</html>