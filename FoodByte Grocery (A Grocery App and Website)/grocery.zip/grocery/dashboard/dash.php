<!DOCTYPE html>
<html>
<head>
    <link rel="stylesheet" type="text/css" href="dash.css">
</head><body>
<div class="admin">
    <header class="admin__header">
        <a href="#" class="logo">
            <h1>FOOD BYTE</h1>
        </a>
        <div class="toolbar">
            <div class="toolbar__left">
                <button class="btn btn--primary">Add content</button>
            </div>
            <div class="toolbar__right">
              <a href="#" class="btn btn--primary logout">Log Out</a>
            </div>
        </div>
    </header>
    <nav class="admin__nav">
        <ul class="menu">
            <li class="menu__title">Dashboard</li>
            <li class="menu__item">
                <a class="menu__link" href="#">Dashboard</a>
            </li>
            <li class="menu__item">
                <a class="menu__link" href="#">Performance</a>
            </li>
<!--             <li class="menu__divider"></li>             -->
            <li class="menu__title">Content</li>
            <li class="menu__item">
                <a class="menu__link" href="#">Media</a>
            </li>
            <li class="menu__item">
                <a class="menu__link" href="#">Templates</a>
            </li>
<!--             <li class="menu__divider"></li> -->
            <li class="menu__title">Network</li>
            <li class="menu__item">
                <a class="menu__link is-active" href="#">Players</a>
            </li>
            <li class="menu__item">
                <a class="menu__link" href="#">Channels</a>
            </li>
            <li class="menu__item">
                <a class="menu__link" href="#">Domains</a>
            </li>
<!--             <li class="menu__divider"></li> -->
            <li class="menu__title">Account</li>
            <li class="menu__item">
                <a class="menu__link" href="#">Account Details</a>
            </li>
            <li class="menu__item">
                <a class="menu__link" href="#">Account Settings</a>
            </li>
<!--             <li class="menu__divider"></li> -->
            <li class="menu__title">Help</li>
            <li class="menu__item">
                <a class="menu__link" href="#">Documentation</a>
            </li>
            <li class="menu__item">
                <a class="menu__link" href="#">Changelogs</a>
            </li>
        </ul>
    </nav>
    <main class="admin__main">
        <div class="dashboard">
            <div class="dashboard__item">
                <div class="card">
                    <div class="card__header">
                        Players
                    </div>
                    <div class="card__content">
                        <div class="card__item">
                            <?php
                               include 'Tables.php';
                            ?>
                        </div>
                    </div>
                </div>
            </div>
           
            <div class="dashboard__item dashboard__item--full">
                <div class="card">
                    <div class="card__header">
                        Card full width
                    </div>
                    <div class="card__content">
                        <div class="card__item">
                            Lorem ipsum dolor sit amet consectetur adipisicing elit. Laudantium labore id culpa sit nisi nostrum, excepturi cumque eos laborum ducimus alias, provident doloribus et facere explicabo ab repudiandae perferendis earum. Lorem ipsum dolor sit amet, consectetur adipisicing elit. Minima dolore laudantium est, vel illo labore nostrum cupiditate perspiciatis, doloremque sit enim sequi, quasi cumque dolorum voluptate! Aliquam corrupti laboriosam nostrum. Lorem, ipsum dolor sit amet consectetur adipisicing elit. Assumenda cupiditate porro dolores optio dicta tempora quas, culpa itaque, unde recusandae tempore. Voluptas quia perferendis est veritatis nobis, iusto voluptate dolor?
                        </div>
                    </div>
                </div>
            </div>
            <div class="dashboard__item dashboard__item--col">
                <div class="card">
                    <div class="card__header">
                        Card
                    </div>
                    <div class="card__content">
                        <div class="card__item">
                            Lorem ipsum dolor sit amet consectetur adipisicing elit. Laudantium labore id culpa sit nisi nostrum, excepturi cumque eos laborum ducimus alias, provident doloribus et facere explicabo ab repudiandae perferendis earum.
                        </div>
                    </div>
                </div>
            </div>
            <div class="dashboard__item dashboard__item--col">
                <div class="card">
                    <div class="card__header">
                        Card
                    </div>
                    <div class="card__content">
                        <div class="card__item">
                            Lorem ipsum dolor sit amet consectetur adipisicing elit. Laudantium labore id culpa sit nisi nostrum, excepturi cumque eos laborum ducimus alias, provident doloribus et facere explicabo ab repudiandae perferendis earum.
                        </div>
                    </div>
                </div>
            </div>
            <div class="dashboard__item dashboard__item--col">
                <div class="card">
                    <div class="card__header">
                        Card
                    </div>
                    <div class="card__content">
                        <div class="card__item">
                            Lorem ipsum dolor sit amet consectetur adipisicing elit. Laudantium labore id culpa sit nisi nostrum, excepturi cumque eos laborum ducimus alias, provident doloribus et facere explicabo ab repudiandae perferendis earum.
                        </div>
                    </div>
                </div>
            </div>
            <div class="dashboard__item dashboard__item--col">
                <div class="card">
                    <div class="card__header">
                        Card
                    </div>
                    <div class="card__content">
                        <div class="card__item">
                            Lorem ipsum dolor sit amet consectetur adipisicing elit. Laudantium labore id culpa sit nisi nostrum, excepturi cumque eos laborum ducimus alias, provident doloribus et facere explicabo ab repudiandae perferendis earum.
                        </div>
                    </div>
                </div>
            </div>
            <div class="dashboard__item dashboard__item--full">
                <div class="card">
                    <div class="card__header">
                        Card full width
                    </div>
                    <div class="card__content">
                        <div class="card__item">
                            Lorem ipsum dolor sit amet consectetur adipisicing elit. Laudantium labore id culpa sit nisi nostrum, excepturi cumque eos laborum ducimus alias, provident doloribus et facere explicabo ab repudiandae perferendis earum. Lorem ipsum dolor sit amet, consectetur adipisicing elit. Minima dolore laudantium est, vel illo labore nostrum cupiditate perspiciatis, doloremque sit enim sequi, quasi cumque dolorum voluptate! Aliquam corrupti laboriosam nostrum. Lorem, ipsum dolor sit amet consectetur adipisicing elit. Assumenda cupiditate porro dolores optio dicta tempora quas, culpa itaque, unde recusandae tempore. Voluptas quia perferendis est veritatis nobis, iusto voluptate dolor?
                        </div>
                    </div>
                </div>
            </div>
            <div class="dashboard__item dashboard__item--full">
                <div class="card">
                    <div class="card__header">
                        Card full width
                    </div>
                    <div class="card__content">
                        <div class="card__item">
                            Lorem ipsum dolor sit amet consectetur adipisicing elit. Laudantium labore id culpa sit nisi nostrum, excepturi cumque eos laborum ducimus alias, provident doloribus et facere explicabo ab repudiandae perferendis earum. Lorem ipsum dolor sit amet, consectetur adipisicing elit. Minima dolore laudantium est, vel illo labore nostrum cupiditate perspiciatis, doloremque sit enim sequi, quasi cumque dolorum voluptate! Aliquam corrupti laboriosam nostrum. Lorem, ipsum dolor sit amet consectetur adipisicing elit. Assumenda cupiditate porro dolores optio dicta tempora quas, culpa itaque, unde recusandae tempore. Voluptas quia perferendis est veritatis nobis, iusto voluptate dolor?
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </main>
    <footer class="admin__footer">
        <span>&copy; 2018 Company Inc.</span>
        <span><a href="#1" class="help">Ask for help</a></span>
    </footer>
</div></body></html>