<html>
  <head>
    <title>Admin Panel</title>
    <link rel="stylesheet" href="../css/dashboard.css">
    <link rel="stylesheet" type="text/css" href="../css/table.css">
    <style type="text/css">
      .a{
        width: 20%;
        padding: 1em;
        line-height: 1;
        background-color: #f9f9f9;
        border: 1px solid #e5e5e5;
        border-radius: 3px;
        transition: 0.35s ease-in-out;
        margin-right: 10px;
        margin-bottom: 5px;
      }
        input{padding: 1em;
          margin-bottom: 5px;
        line-height: 1;}
        h5{margin-left: 50px;}
    </style>
  </head>
<?php session_start();
$id="";
if (isset($_SESSION["name"])) {
  if ($_SESSION["email"]=="admin@local.com") {
?>
  <body>
    <header>
      <div class="left_area">
        <a href="../home.php"><h3>Food <span>Byte</span></h3></a>
      </div>
      <div class="right_area">
        <a href="../logout.php" class="logout_btn">Logout</a>
      </div>
    </header>

    <div class="sidebar">
      <center>
        <img src="bil.jpg" class="profile_image" alt="">
        <h4>Bilal</h4>
      </center>
      <a href="dashboard.php"><span>Dashboard</span></a>
      <a href="insert.php"><span>Insert Item</span></a>
      <a href="update.php"><span>Update Item</span></a>
      <a href="delete.php"><span>Delete Item</span></a>
      <a href="show.php"><span>Show Items</span></a>
      <a href="../about.html"><span>About</span></a>
    </div>
    <div class="content">
      <h3>Welcome Admin</h3>
      <p>Here You can add,remove and update your website!</p>
      <?php include '../conection.php';
      $u=$_GET['r'];
      $re= mysqli_query($con,"SELECT * From products where Prod_Id='".$u."'");
      while ($rows=mysqli_fetch_assoc($re)){
        $id=$rows["Prod_Id"];
        ?>
        <form action="#" method="POST">
          <input type="text" name="id" value="<?php echo $rows["Prod_Id"] ?>" disabled><br>
          <input type="text" name="name" value="<?php echo $rows["Prod_Name"] ?>" ><br>
          <input type="text" name="price" value="<?php echo $rows["Prod_Price"] ?>" ><br>
          <input type="text" name="size" value="<?php echo $rows["Prod_Size"] ?>" ><br>
          <input type="text" name="desp" value="<?php echo $rows["Prod_Desp"] ?>" ><br>
          <input type="submit" name="submit" value="Update">
        </form>
      <?php  
      }
      ?>
    </div>

<?php }
else{echo "Admin Can see dashboard ";?><br><a href="login.php">login</a><br>
     <a href="home.php">go back to home page</a>
 <?php }
}
else{echo "login first"; ?> <a href="login.php">login</a> <?php } ?>

</body>
</html>

<?php
if (isset($_POST['submit'])) {
  $name=$_POST["name"];
  $price=$_POST["price"];
  $size=$_POST["size"];
  $desp=$_POST["desp"];

  $query="UPDATE Products SET Prod_Name='".$name."', Prod_Price='".$price."', Prod_Size='".$size."', Prod_Desp='".$desp."' where Prod_Id='".$id."'";
  mysqli_query($con,$query);
  echo "Updated";

}
?>
