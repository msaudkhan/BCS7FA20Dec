<?php
     include '../conection.php';
     $var=$_GET['r'];
     echo $var;
     $q=mysqli_query($con,"DELETE from `Products` where Prod_Id='".$var."'");
     header("location:delete.php");
?>