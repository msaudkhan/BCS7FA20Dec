<?php
     include '../../../conection.php';
     $var=$_GET['r'];
     echo $var;
     $q=mysqli_query($con,"DELETE from `mart02 products` where Prod_Id='".$var."'");
     header("location:delete.php");
?>