<html>
  <head>
    <title>Admin Panel</title>
    <link rel="stylesheet" href="../../../css/dashboard.css">
    <link rel="stylesheet" type="text/css" href="../../../css/table.css">
    <style type="text/css">
      .a{
        width: 20%;
        padding: 1em;
        line-height: 1;
        background-color: #f9f9f9;
        border: 1px solid #e5e5e5;
        border-radius: 3px;
        transition: 0.35s ease-in-out;
        margin-right: 10px;
        margin-bottom: 5px;
      }
        input{padding: 1em;
          margin-bottom: 5px;
        line-height: 1;}
        h5{margin-left: 50px;}
      #customers{width: 150%;}
      #customers td, #customers th { border: 1px solid #ddd;padding: 20px;}
      #customers tr:nth-child(even){background-color: #f2f2f2;}
      #customers tr:hover {background-color: #ddd;}
      .content a{
        margin-left: 80px;
        background: green;
        color: white;
        padding:15px;
        text-decoration: none;
        margin-top: 30px;}
    </style>
  </head>
<?php session_start();
$id="";
if (isset($_SESSION["name"])) {
?>
  <body>
    <header>
      <div class="left_area">
        <a href="../../../home.php"><h3>Food <span>Byte</span></h3></a>
      </div>
    </header>

    <div class="sidebar">
      <center>
        <img src="nasem.png" class="profile_image" alt="">
        <h4><?php echo $_SESSION["name"]; ?></h4>
      </center>
      <div class="sidebar_menu">
      <a href="dashboard.php"><span>Dashboard</span></a>
      <a href="notifications.php"><span>Notifications</span></a>
      <a href="insert.php"><span>Insert Item</span></a>
      <a href="update.php"><span>Update Item</span></a>
      <a href="delete.php"><span>Delete Item</span></a>
      <a href="show.php"><span>Show Items</span></a>
      <a href="#"><span>About</span></a>
      <a href="../../../logout.php" class="logout_btn">Logout</a></div>
    </div>
    </div>
    <div class="content">
      <h3>Welcome Admin</h3>
      <p>Here You can add,remove and update your website!</p><br><br>
      <table id="customers">
        <tr>
          <th>Name</th>
          <th>Description</th> 
          <th>Quantity</th>
        </tr>
        <?php include '../../../conection.php';
        $u=$_GET['r'];
        $re= mysqli_query($con,"SELECT * From `rider notification` where Rider_Id='".$u."'");
        $length=0;
        while ($rows=mysqli_fetch_assoc($re)){
        $id=$rows["Cust_Id"];
        $responce = mysqli_query($con,"SELECT * FROM `user cart` where Cust_Id='".$id."' AND Mart_Id='2'");
        $a=0;
        $length= mysqli_num_rows($responce);
        while($row1 = mysqli_fetch_array($responce))
        {
        	 $index    = $row1["Prod_Id"];
        	 $select= "SELECT * FROM `mart02 products` where Prod_Id='".$index."'";	
        	 $fetch = mysqli_query($con,$select);
           
			  while($row = mysqli_fetch_array($fetch)){
          $a=$a+1;
        ?>
        <tr>
          <td><?php echo $row['Prod_Name']; ?></td>
          <td><?php echo $row['Prod_Desp']; ?></td>
          <td><?php echo $row1['Quantity']; ?></td>
          
        </tr> 
        <?php $option="";
        $re= mysqli_query($con,"SELECT * From `mart notification` where Rider_Id='".$u."' AND Mart_Id='2'");
        while ($row=mysqli_fetch_assoc($re)){$status=$row["Status"];
         if ($a==$length) { 
          if ($status=="Packing") {$option="Ready";}
          else{$option="Delivered";}
          ?>
            <tr><td style="border: 0px;background: white;"></td>
            	<td style="border: 0px;background: white;padding-top: 40px;padding-right: 70px">
            	<a href="update_mart_notification.php?r=<?php echo $u; ?>"><?php echo $option; ?>
            	</a> </td>
            </tr>
       <?php    }}
        
       
      } }
        }
      ?></table>

    </div>

<?php 
}
else{echo "login first"; ?> <a href="login.php">login</a> <?php } ?>

</body>
</html>
