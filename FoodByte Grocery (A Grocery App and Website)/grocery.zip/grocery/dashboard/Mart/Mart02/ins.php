
<?php 
include '../../../conection.php';
if (isset($_POST['submit'])) {
  $name=$_POST['p_name'];
  $category=$_POST['category'];
  $price=$_POST['price'];
  $desp=$_POST['desp'];
  $size=$_POST['size'];
  $filename = $_FILES['img']['name']; 
  $tempname = $_FILES['img']['tmp_name'];     
  $folder = "../../../images/".$category."/".$filename;
  $query="INSERT into `mart02 products` (Prod_Name,Category,Prod_Price,Prod_Desp,Prod_Size,Prod_Img)
          VALUES ('$name','$category','$price','$desp','$size','$filename')";
        mysqli_query($con, $query);

  if (move_uploaded_file($tempname, $folder)){$msg = "Product uploaded successfully";}
  else{$msg = "Failed to upload image";}
  echo $msg;

}?>