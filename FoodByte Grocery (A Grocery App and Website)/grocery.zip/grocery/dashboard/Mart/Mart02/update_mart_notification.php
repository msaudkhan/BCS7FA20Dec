<?php
     include '../../../conection.php';
     $var=$_GET['r'];
     $re= mysqli_query($con,"SELECT * From `mart notification` where Rider_Id='".$var."' AND Mart_Id='2'");
     while ($row=mysqli_fetch_assoc($re))
     {
     	$status=$row["Status"];
     	echo $status;
     	if ($status=="Packing") 
          {
     		$query="UPDATE `mart notification` SET Status='Ready' where Rider_Id='".$var."' AND Mart_Id='2'";
     		mysqli_query($con,$query);
     		echo "Ready";
               header("location:notification1.php?r=".$var);
     	}
     	elseif ($status=="Ready") 
          {
               $re=mysqli_query($con,"SELECT * From `rider notification` where Rider_Id='".$var."'");
     		while ($rows=mysqli_fetch_assoc($re))
               {
                    $id=$rows["Cust_Id"];
                    echo $id;
                    $responce = mysqli_query($con,"DELETE FROM `user cart` where Cust_Id='".$id."' AND Mart_Id='2' ");
               }
               $query="DELETE FROM `mart notification` where Rider_Id='".$var."' AND Mart_Id='2'";
     		mysqli_query($con,$query);
     		echo "delivered";
               header("location:notifications.php");     	
     	}
     	else{echo "delivered";}
     }
     //header("location:delete.php");
?>