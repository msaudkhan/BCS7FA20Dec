<link rel="stylesheet" type="text/css" href="../../../css/table.css">
<style type="text/css">
  
.panel{
  height: 60%;
  width: 284%;
  border: 2px solid black;
  overflow-y: scroll;
}

</style>

<?php 
      include '../../../conection.php';
?>
<br><br>

<div class="panel">
<table id="customers">
  <tr>
    <th>Prod_ID</th>
    <th>Prod_Name</th> 
    <th>Category</th>
    <th>Prod_Price</th>
    <th>Description</th> 
    <th>Prod_Size</th>
  </tr>
 <?php $query="SELECT * from `mart01 products`"; 
       $re=mysqli_query($con,$query);
       while ($rows=mysqli_fetch_assoc($re)) {
           ?>
           <tr>
    <td><?php echo $rows['Prod_Id']; ?></td>
    <td><?php echo $rows['Prod_Name']; ?></td>
    <td><?php echo $rows['Category']; ?></td>
    <td><?php echo $rows['Prod_Price']; ?></td>
    <td><?php echo $rows['Prod_Desp']; ?></td>
    <td><?php echo $rows['Prod_Size']; ?></td>
    
    </tr>
           <?php
       }

 ?>
  
</table>
 

</div>
