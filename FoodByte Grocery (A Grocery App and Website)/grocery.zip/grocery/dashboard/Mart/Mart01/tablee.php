<?php 
      include '../../../conection.php';
?>
<head>
  <title>
    Tables Record
  </title>
  <meta content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0, shrink-to-fit=no' name='viewport' />
  <!-- CSS Files -->
  <link href="../../../css/bootstrap.min.css" rel="stylesheet" />
  <link href="../../../css/paper-dashboard.css?v=2.0.1" rel="stylesheet" />
</head>
<div class="content" style="margin-left:50px;margin-right: 50px;max-height: 200px">
        <div class="row">
          <div class="col-md-12">
            <div class="card">
              <div class="card-header">
                <h4 class="card-title"> Simple Table</h4>
              </div>
              <div class="card-body">
                <div class="table-responsive">
                  <table class="table">
                    <thead class=" text-primary">
                      <th>Prod_ID</th>
                      <th>Prod_Name</th> 
                      <th>Category</th>
                      <th>Prod_Price</th>
                      <th>Description</th> 
                      <th>Prod_Size</th>
                    </thead>
                    <tbody>
                      <?php $query="SELECT * from Products"; 
       $re=mysqli_query($con,$query);
       while ($rows=mysqli_fetch_assoc($re)) {
           ?>
           <tr>
    <td><?php echo $rows['Prod_Id']; ?></td>
    <td><?php echo $rows['Prod_Name']; ?></td>
    <td><?php echo $rows['Category']; ?></td>
    <td><?php echo $rows['Prod_Price']; ?></td>
    <td><?php echo $rows['Prod_Desp']; ?></td>
    <td><?php echo $rows['Prod_Size']; ?></td>
    
    </tr>
           <?php
       }

 ?>
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>