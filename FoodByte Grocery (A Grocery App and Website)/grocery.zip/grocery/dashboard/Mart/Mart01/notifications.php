<?php include '../../../conection.php';?>
<html>
  <head>
    <title>Admin Panel</title>
    <link rel="stylesheet" href="../../../css/dashboard.css">
    <link rel="stylesheet" type="text/css" href="../../../css/table.css">
    <style type="text/css">
      .content{margin-left: 170px;width: 50%;}
      #customers{width: 80%;}
      #customers td, #customers th { border: 1px solid #ddd;padding: 20px;}
      #customers tr:nth-child(even){background-color: #f2f2f2;}
      #customers tr:hover {background-color: #ddd;}
      table a{
        background: green;
        color: white;
        padding:5px;
        text-decoration: none;
      }
    </style>
  </head>
<?php session_start();
if (isset($_SESSION["name"])) {

?>
  <body>
    <header>
      <div class="left_area">
        <a href="../../../home.php"><h3>Food <span>Byte</span></h3></a>
      </div>
    </header>

    <div class="sidebar">
      <center>
        <img src="peoples.png" class="profile_image" alt="">
        <h4><?php echo $_SESSION["name"]; ?></h4>
      </center>
      <div class="sidebar_menu">
      <a href="dashboard.php"><span>Dashboard</span></a>
      <a href="notifications.php"><span>Notifications</span></a>
      <a href="insert.php"><span>Insert Item</span></a>
      <a href="update.php"><span>Update Item</span></a>
      <a href="delete.php"><span>Delete Item</span></a>
      <a href="show.php"><span>Show Items</span></a>
      <a href="#"><span>About</span></a>
      <a href="../../../logout.php" class="logout_btn">Logout</a></div>
    </div>
    </div>
    <div class="content">
      <div style="margin-left: 90px">
      <h3>Welcome <?php echo $_SESSION["name"]; ?></h3>
      <p>Here You can add,remove and update your website!</p></div>
    <form action="#" method="POST">
            <br><br><ul style="display: flex;float: left;list-style: none;">
        <li> 
<table id="customers">
      <tr>
        <th>Description</th>
        <th>Rider ID</th>
        <th>Option</th> 
      </tr>
      <?php $query="SELECT * from `mart notification`WHERE Mart_Id='1'"; 
      $re=mysqli_query($con,$query);
      while ($rows=mysqli_fetch_assoc($re)) { ?>
      <tr>
        <td><?php echo $rows['Description']; ?></td>
        <td><?php echo $rows['Rider_Id']; ?></td>
        <td><a href="notification1.php?r=<?php echo $rows['Rider_Id']; ?>">Detail</a></td>
      </tr>
      <?php } ?>
        </th>
</table><br>
      </li></ul>
   </form>
</div>

<?php 
}
else{echo "login first"; ?> <a href="login.php">login</a> <?php } ?>

</body>
</html>
