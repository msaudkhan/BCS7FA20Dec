<html>
  <head>
    <title>Admin Panel</title>
    <link rel="stylesheet" href="../../css/dashboard.css">
    <style type="text/css">
      .input-group input,select
      {
        width: 200%;
        padding: 1em;
        line-height: 1;
        background-color: #f9f9f9;
        border: 1px solid #e5e5e5;
        border-radius: 3px;
        transition: 0.35s ease-in-out;
      }
     .input-group {margin-bottom: 1em;width: 30%;}
     .input-group label{color:black;}
     .btn {
        padding: 2px 10px;
        background-color: #178A36;
        font-family: Poppins-Regular;
        font-size: 16px;
        color: #fff;
        transition: all 0.4s;
}
input{
      padding: 1em;
      margin-bottom: 5px;
      line-height: 1;
    }
.btn:hover {background-color: black;}

    </style>
  </head>
<?php session_start();
if (isset($_SESSION["name"])) {
  if ($_SESSION["email"]=="admin@local.com") {
?>
  <body>
    <header>
      <div class="left_area">
        <a href="../../index.php"><h3>Food <span>Byte</span></h3></a>
      </div>
    </header>

    <div class="sidebar">
      <center>
        <img src="bil.jpg" class="profile_image" alt="">
        <h4>Bilal</h4>
      </center>
      <a href="dashboard.php"><span>Dashboard</span></a>
      <a href="insert.php"><span>Insert Item</span></a>
      <a href="update.php"><span>Update Item</span></a>
      <a href="delete.php"><span>Delete Item</span></a>
      <a href="show.php"><span>Show Items</span></a>
      <a href="../../about.html"><span>About</span></a>
      <a href="../../logout.php" class="logout_btn">Logout</a>
    </div>
    <div class="content">
      <h3>Welcome Admin</h3>
      <p>Here You can add,remove and update your website!</p><br><br><br>
      <form action="ins.php" method="POST" enctype="multipart/form-data">
      <div class="input-group">
        <input type="text" placeholder="Product Name" name="p_name"  required>
      </div>
      <div class="input-group">
        <select name="category">
          <option value="Candy">Candy</option>
          <option value="Pasta">Pasta</option>
          <option value="Cake">Cake</option>
          <option value="Milk">Milk</option>
          <option value="Biscuit">Biscuit</option>
          <option value="Beverages">Beverages</option>
          <option value="Air Freshner">Air Freshner</option>
          <option value="Cigaret">Cigaret</option>
          <option value="Cleaning">Cleaning</option>
          <option value="Kitchen">Kitchen</option>
          <option value="Toilet Paper">Toilet Paper</option>
          <option value="Baby Body care">Baby Body care</option>
          <option value="Baby Milk">Baby Milk</option>
          <option value="Diapers">Diapers</option>
          <option value="Beauty care">Beauty care</option>
          <option value="Body care">Body care</option>
          <option value="Hair Care">Hair Care</option>
          <option value="Oral Care">Oral Care</option>
          <option value="Perfumes">Perfumes</option>
          <option value="Pet Food">Pet Food</option>
          <option value="stationary">stationary</option>
          <option value="Meat">Meat</option>
          <option value="Vegetable">Vegetable</option>
          <option value="Sweet">Sweet</option>
          <option value="Bread">Bread</option>
          <option value="Break Fast">Break Fast</option>
        </select>
      </div>
      <div class="input-group">
        <input type="text" placeholder="Product Price" name="price" required>
      </div>      
      <div class="input-group">
        <input type="text" placeholder="Product Description" name="desp" required>        
      </div>
      <div class="input-group">
        <input type="text" placeholder="Product Size" name="size" required>       
      </div>
      <input type="file" name="img" ><br><br>
      <button class="btn" type="submit" name="submit">Insert</button>
      </form>
    </div>

<?php }
else{echo "Admin Can see dashboard ";?><br><a href="../../login.php">login</a><br>
     <a href="../../index.php">go back to home page</a>
 <?php }
}
else{echo "login first"; ?> <a href="login.php">login</a> <?php } ?>

</body>
</html>