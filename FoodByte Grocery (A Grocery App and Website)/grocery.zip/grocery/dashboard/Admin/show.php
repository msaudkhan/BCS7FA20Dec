<html>
  <head>
    <title>Admin Panel</title>
    <link rel="stylesheet" href="../../css/dashboard.css">
  </head>
<?php session_start();
if (isset($_SESSION["name"])) {
  if ($_SESSION["email"]=="admin@local.com") {
?>
  <body>
    <header>
      <div class="left_area">
        <a href="../../home.php"><h3>Food <span>Byte</span></h3></a>
      </div>
    </header>

    <div class="sidebar">
      <center>
        <img src="bil.jpg" class="profile_image" alt="">
        <h4>Administrator</h4>
      </center>
     <div class="sidebar_menu">
      <a href="dashboard.php"><span>Dashboard</span></a>
      <a href="marts.php"><span>See Marts</span></a>
      <a href="riders.php"><span>See Riders</span></a>
      <a href="users.php"><span>See Users</span></a>
      <a href="show.php"><span>Show Products</span></a>
      <a href="#"><span>About</span></a>
      <a href="../../logout.php" class="logout_btn">Logout</a></div>
    </div>
    <div class="content">
      <h3>Welcome Admin</h3>
      <p>Here You can add,remove and update your website!</p>
      <form action="#" method="POST">
      <input type="submit" name="submita" value="Mart 01">
      <input type="submit" name="submitb" value="Mart 02">
      <input type="submit" name="submitc" value="Mart 03"></form>
      <br><br>
      <?php
      if (isset($_POST["submita"])){
      	include 'Tables.php';
      }
      else if (isset($_POST["submitb"])){
      	
      }
      else if (isset($_POST["submitc"])){
      	
      }
      else{}
      
      ?>
    </div>

<?php }
else{echo "Admin Can see dashboard ";?><br><a href="login.php">login</a><br>
     <a href="home.php">go back to home page</a>
 <?php }
}
else{echo "login first"; ?> <a href="login.php">login</a> <?php } ?>

</body>
</html>