<html>
  <head>
    <title>Admin Panel</title>
    <link rel="stylesheet" href="../../css/dashboard.css">
    <link rel="stylesheet" href="../../css/Table.css">
    <style type="text/css">
      #customers{width: 100px;height: 100px;}
      .a{
        width: 50%;
        padding: 1em;
        line-height: 1;
        background-color: #f9f9f9;
        border: 1px solid #e5e5e5;
        border-radius: 3px;
        transition: 0.35s ease-in-out;
        margin-right: 10px;
        margin-bottom: 5px;
      }
      #customers{width: 150%;height: 40%;}
        input{padding: 1em;
          margin-bottom: 5px;
        line-height: 1;}
        h5{margin-left: 50px;}
    </style>
  </head>
<?php session_start(); include '../../conection.php';
if (isset($_SESSION["name"])) {
  if ($_SESSION["email"]=="admin@local.com") {
?>
  <body>
    <header>
      <div class="left_area">
        <a href="../../index.php"><h3>Food <span>Byte</span></h3></a>
      </div>
      <div class="right_area">
      </div>
    </header>

    <div class="sidebar">
      <center>
        <img src="bil.jpg" class="profile_image" alt="">
        <h4>Bilal</h4>
      </center>
     <div class="sidebar_menu">
      <a href="dashboard.php"><span>Dashboard</span></a>
      <a href="marts.php"><span>See Marts</span></a>
      <a href="riders.php"><span>See Riders</span></a>
      <a href="users.php"><span>See Users</span></a>
      <a href="show.php"><span>Show Products</span></a>
      <a href="#"><span>About</span></a>
      <a href="../../../logout.php" class="logout_btn">Logout</a></div>
    </div>
    <div class="content">
      <h3>Welcome Admin</h3>
      <p>Here You can add,remove and update your website!</p><br><br><br>
      <table id="customers">
        <tr>
          <th>Name</th>
          <th>Phone no</th> 
          <th>Email</th>
          <th>Address</th>
        </tr>
        <?php
        $result=mysqli_query($con,"SELECT * FROM customers");
        while ($row=mysqli_fetch_assoc($result)){?>
          <tr>
            <td><?php echo $row['Name']; ?></td>
            <td><?php echo $row['Phone']; ?></td>
            <td><?php echo $row['Email']; ?></td>
            <td><?php echo $row['Address']; ?></td>
          </tr>
  <?php }?>
     </table>
    </div>

<?php }
else{echo "Admin Can see dashboard ";?><br><a href="../../login.php">login</a><br>
     <a href="../../index.php">go back to home page</a>
 <?php }
}
else{?>
  <div style="margin-top: 50px;text-align: center;border:1px solid green;padding: 15px 15px;">
    <p>Sorry Admin! You Have To Login First</p><br>
    <button><a style="text-decoration: none;padding: 5px 5px;" href="../login.php">Login Here</a></button>
  </div>
   <?php } ?>

</body>
</html>


