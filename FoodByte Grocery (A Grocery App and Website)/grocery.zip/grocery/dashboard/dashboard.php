<html>
  <head>
    <title>Admin Panel</title>
    <link rel="stylesheet" href="../css/dashboard.css">
  </head>
<?php session_start();
if (isset($_SESSION["name"])) {
  if ($_SESSION["email"]=="admin@local.com" && $_SESSION["id"]=="4") {
?>
  <body>
    <header>
      <div class="left_area">
        <a href="../home.php"><h3>Food <span>Byte</span></h3></a>
      </div>
      <div class="right_area">
      </div>
    </header>

    <div class="sidebar">
      <center>
        <img src="bil.jpg" class="profile_image" alt="">
        <h4>Bilal</h4>
      </center>
      <a href="dashboard.php"><span>Dashboard</span></a>
      <a href="insert.php"><span>Insert Item</span></a>
      <a href="delete.php"><span>Delete Item</span></a>
      <a href="show_mart.php"><span>Show Item</span></a>
      <a href="insert.php"><span>Insert Item</span></a>
      <a href="#"><span>About</span></a>
      <a href="../logout.php" class="logout_btn">Logout</a>
    </div>
    <div class="content">
      <h3>Welcome Admin</h3>
      <p>Here You can add,remove and update your website!</p>
      <?php
      include 'Tables.php';
      ?>
    </div>

<?php }
else{
?>
<body>
    <header>
      <div class="left_area">
        <a href="../home.php"><h3>Food <span>Byte</span></h3></a>
      </div>
      <div class="right_area">
      </div>
    </header>

    <div class="sidebar">
      <center>
        <img src="../pics/m.png" class="profile_image" alt="">
        <h4><?php echo $_SESSION["name"]; ?></h4>
      </center>
      <a href="dashboard.php"><span>Dashboard</span></a>
      <a href="update.php"><span>Update Item</span></a>
      <a href="delete.php"><span>Delete Item</span></a>
      <a href="show.php"><span>Show Items</span></a>
      <a href="#"><span>About</span></a>
      <a href="../logout.php" class="logout_btn">Logout</a>
    </div>
    <div class="content">
      <h3>Welcome Admin</h3>
      <p>Here You can add,remove and update your website!</p>
      <?php
      include 'Tables.php';
      ?>
    </div>


 <?php }
}
else{?>
  <div style="margin-top: 50px;text-align: center;border:1px solid green;padding: 15px 15px;">
    <p>Sorry Admin! You Have To Login First</p><br>
    <button><a style="text-decoration: none;padding: 5px 5px;" href="../login.php">Login Here</a></button>
  </div>
   <?php } ?>

</body>
</html>