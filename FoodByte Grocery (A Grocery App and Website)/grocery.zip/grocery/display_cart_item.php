<?php
    $connect = mysqli_connect("localhost","root","","foodbyte");

if($_SERVER['REQUEST_METHOD'] =='POST'){
	
   $user_id= $_POST['user_id'];
   $select= "SELECT * FROM `cart items` where Cust_Id='".$user_id."' ";
   $result = array();
   $result['data'] = array();
   $responce = mysqli_query($connect,$select);
    while($row1 = mysqli_fetch_array($responce))
			 {
		
		     $index    = $row1['2'];
		    // $index['name']  = $row['1'];
		    // $index['price'] = $row['4'];
		    // $index['image'] = $row['7'];
		     //$index1['quantity']    = $row1['3'];
			 $select= "SELECT * FROM `mart01 products` where Prod_Id='".$index."'";	
			 

			$fetch = mysqli_query($connect,$select);
			 while($row = mysqli_fetch_array($fetch))
			 {
                   $indx['id']       = $row['0'];
		           $indx['name']     = $row['1'];
		           $indx['price']    = $row['4'];
		           $indx['category'] = $row['3'];
		           $indx['image']    = $row['7'];
		           $indx['quantity'] = $row1['4'];
		           $indx['mart']     = $row1['3'];
		           array_push($result['data'], $indx);
			 }
			// array_push($result['data'],$index1);
			 }
			 $result["success"]="1";
		    echo json_encode($result);
			mysqli_close($connect);
}
else echo "not set";
			// print_r($result);
			
   //      if($_SERVER['REQUEST_METHOD'] =='POST')
   //          {
    
     
			// $result = array();
			// $result['data'] = array();
			// $select= "SELECT * FROM `mart01 products` WHERE category='cake' LIMIT 3";
			// $responce = mysqli_query($connect,$select);
	
            
			// while($row = mysqli_fetch_array($responce))
			// {
		
		 //    $index['id']    = $row['0'];
		 //    $index['name']  = $row['1'];
		 //    $index['price'] = $row['4'];
		 //    $index['image'] = $row['7'];
				
			// array_push($result['data'], $index);

			
				
			// }
			// $result["success"]="1";
		 //    echo json_encode($result);
			// mysqli_close($connect);

   //          }	
?>