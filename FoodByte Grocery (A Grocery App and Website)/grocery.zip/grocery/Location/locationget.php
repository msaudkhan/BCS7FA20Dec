<?php
    $connect = mysqli_connect("localhost","root","","foodbyte");


        if($_SERVER['REQUEST_METHOD'] =='POST')
            {
    
     
			$result = array();
			$result['data'] = array();
			$select= "SELECT * FROM rider";
			$responce = mysqli_query($connect,$select);
	
            
			while($row = mysqli_fetch_array($responce))
			{
		
		    $index['id']    = $row['0'];
		    $index['latitude']  = $row['8'];
		    $index['longitude'] = $row['9'];
		    
				
			array_push($result['data'], $index);

			
				
			}
			$result["success"]="1";
		    echo json_encode($result);
			mysqli_close($connect);

            }	
?>