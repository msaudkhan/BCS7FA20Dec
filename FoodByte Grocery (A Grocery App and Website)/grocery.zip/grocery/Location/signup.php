<?php
require "DataBase.php";
$db = new DataBase();
if (isset($_POST['latitude']) && isset($_POST['longitude']) && isset($_POST['id'])) {
    if ($db->dbConnect()) {
        if ($db->Location_send("rider", $_POST['latitude'], $_POST['longitude'],  $_POST['id'])) {
            echo "location added";
        }
      //  echo $_POST['latitude'];
          else echo "Sign up Failed";
    	//echo "connected";
    } else echo "Error: Database connection";
} else echo "All fields are required";
?>
