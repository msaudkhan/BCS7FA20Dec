<html>
  <head>
    <title>Admin Panel</title>
    <link rel="stylesheet" href="../css/dashboard.css">
  </head>
<?php session_start();
if (isset($_SESSION["name"])) {
  if ($_SESSION["name"]=="admin") {
?>
  <body>
    <header>
      <div class="left_area">
        <a href="../home.php"><h3>Food <span>Byte</span></h3></a>
      </div>
      <div class="right_area">
        <a href="../login.html" class="logout_btn">Logout</a>
      </div>
    </header>

    <div class="sidebar">
      <center>
        <img src="bil.jpg" class="profile_image" alt="">
        <h4>Bilal</h4>
      </center>
      <a href="dashboard.php"><span>Dashboard</span></a>
      <a href="insert.php"><span>Insert Item</span></a>
      <a href="update.php"><span>Update Item</span></a>
      <a href="delete.phpp"><span>Delete Item</span></a>
      <a href="show.php"><span>Show Items</span></a>
      <a href="../about.html"><span>About</span></a>
    </div>
    <div class="content">
      <img src="../icon/dash.jpg">
      <h3>Welcome Admin</h3>
      <p>Here You can add,remove and update your website!
        <br>
        Have a Nice day Admin!
      </p>
    </div>

<?php }
else{echo "Admin Can see dashboard ";?><br><a href="login.php">login</a><br>
     <a href="home.php">go back to home page</a>
 <?php }
}
else{echo "login first"; ?> <a href="login.php">login</a> <?php } ?>

</body>
</html>