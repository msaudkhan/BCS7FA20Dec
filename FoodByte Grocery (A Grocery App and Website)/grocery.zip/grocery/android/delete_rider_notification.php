<?php
require "DataBase.php";
$db = new DataBase();
if (isset($_POST['Rider_Id'])) {
    if ($db->dbConnect()) {
        if ($db->del_rider_notification($_POST['Rider_Id'])) {
            echo "Success";
        } else echo "Failed";
    } else echo "Error: Database connection";
} else echo "All fields are required";
?>
