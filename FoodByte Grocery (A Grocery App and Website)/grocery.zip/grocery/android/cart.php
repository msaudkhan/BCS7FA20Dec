<?php
require "DataBase.php";
$db = new DataBase();
if (isset($_POST['Cust_Id']) && isset($_POST['Prod_Id']) && isset($_POST['Mart_Id'])) {
    if ($db->dbConnect()) {
        if ($db->cart("cart items",$_POST['Cust_Id'], $_POST['Prod_Id'], $_POST['Mart_Id'])) {
           echo "Added To carts";
        } else echo "Failed";
    } else echo "Error: Database connection";
} else echo "All fields are required";
?>
