<?php
require "DataBase.php";
$db = new DataBase();
if (isset($_POST['Name']) && isset($_POST['Gender']) && isset($_POST['Phone']) && isset($_POST['Email']) && isset($_POST['Password']) && isset($_POST['Address']) && isset($_POST['Date_Of_Birth'])) {
    
    if ($db->dbConnect()) {

        if ($db->user_register("customers", $_POST['Name'], $_POST['Gender'], $_POST['Phone'], $_POST['Email'],$_POST['Password'],$_POST['Address'],$_POST['Date_Of_Birth'])) 
        {echo "Sign Up Success";}

        elseif ($db->user_register("customers", $_POST['Name'],$_POST['Gender'], $_POST['Phone'],$_POST['Email'],$_POST['Password'],$_POST['Address'],$_POST['Date_Of_Birth'])=="0") {echo "0";}

        else echo "Sign up Failed";

    }
    else echo "Error: Database connection";
} 
else echo "All fields are required";
?>
