<?php
    $connect = mysqli_connect("localhost","root","","foodbyte");

if($_SERVER['REQUEST_METHOD'] =='POST'){
	
   $user_id= $_POST['user_id'];
   $select= "SELECT * FROM `rider` WHERE Rider_Id='".$user_id."' ";
   $result = array();
   $result['data'] = array();
   $responce = mysqli_query($connect,$select);
    while($row = mysqli_fetch_array($responce))
			 {
		           $indx['name']  = $row['1'];
		           $indx['address'] = $row['6'];
		           $indx['phone'] = $row['3'];
		           $indx['password']=$row['5'];
		           
		           array_push($result['data'],$indx);
			 }
			$result["success"]="1";
		    echo json_encode($result);
			mysqli_close($connect);
}
else echo "not set";

