<?php
require "DataBase.php";
$db = new DataBase();
if (isset($_POST['Rider_Id']) && isset($_POST['Name']) && isset($_POST['Phone']) && isset($_POST['Address']) && isset($_POST['Password'])) {
    if ($db->dbConnect()) {
        if ($db->change_rider_profile("rider", $_POST['Rider_Id'], $_POST['Name'], $_POST['Phone'], $_POST['Address'], $_POST['Password'])) {
            echo "Success";
        } else echo "Failed";
    } else echo "Error: Database connection";
} else echo "All fields are required";
?>
