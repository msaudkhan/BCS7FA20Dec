<?php
require "DataBaseConfig.php";

class DataBase
{
    public $connect;
    public $data;
    private $sql;
    protected $servername;
    protected $username;
    protected $password;
    protected $databasename;

    public function __construct()
    {
        $this->connect = null;
        $this->data = null;
        $this->sql = null;
        $dbc = new DataBaseConfig();
        $this->servername = $dbc->servername;
        $this->username = $dbc->username;
        $this->password = $dbc->password;
        $this->databasename = $dbc->databasename;
    }

    function dbConnect()
    {
        $this->connect = mysqli_connect($this->servername, $this->username, $this->password, $this->databasename);
        return $this->connect;
    }

    function prepareData($data)
    {
        return mysqli_real_escape_string($this->connect, stripslashes(htmlspecialchars($data)));
    }

    function logIn($table, $username, $password)
    {
        $username = $this->prepareData($username);
        $password = $this->prepareData($password);

        $this->sql = "SELECT * FROM customers WHERE Email = '".$username."' AND 
        Password= '".$password."' ";
        $result = mysqli_query($this->connect, $this->sql);

        $this->sql1 = "SELECT * FROM rider WHERE Email = '".$username."' AND 
        Password= '".$password."' ";
        $result1 = mysqli_query($this->connect, $this->sql1);

        if (mysqli_num_rows($result) == 1) {return "user";} 
        elseif (mysqli_num_rows($result1) == 1) {return "rider";}
        else { return false;}
    }

    function user_register($table, $Name,$gender,$phone, $email,$password ,$address,$dateofbirth )
    {
        $fullname    = $this->prepareData($Name);
        $gender      = $this->prepareData($gender);
        $phone       = $this->prepareData($phone);
        $email       = $this->prepareData($email);
        $password    = $this->prepareData($password);
        $address     = $this->prepareData($address);
        $dateofbirth = $this->prepareData($dateofbirth);


        $query="SELECT * FROM customers WHERE Email='".$email."' OR  Phone = '".$phone."'";
        $result= mysqli_query($this->connect,$query);
        $num = mysqli_num_rows($result);

        $query1="SELECT * FROM rider WHERE Email='".$email."' OR  Phone = '".$phone."'";
        $result1= mysqli_query($this->connect,$query1);
        $num1 = mysqli_num_rows($result1);
        if ($num == 0 && $num1==0){
                $this->sql="INSERT INTO `".$table ."` (Name, Gender, Phone, Email, Password, Address, Date_Of_Birth) VALUES ('" . $fullname . "','" . $gender . "','" . $phone . "','" . $email . "','" .$password . "','" . $address . "','" . $dateofbirth . "')";
                if (mysqli_query($this->connect, $this->sql)) {return true;}
                else return false; 
        }
        else{return "0";}

    }

    function rider_register($table, $Name,$gender,$phone, $email,$password ,$address,$dateofbirth )
    {
        $fullname    = $this->prepareData($Name);
        $gender      = $this->prepareData($gender);
        $phone       = $this->prepareData($phone);
        $email       = $this->prepareData($email);
        $password    = $this->prepareData($password);
        $address     = $this->prepareData($address);
        $dateofbirth = $this->prepareData($dateofbirth);
        
        $query="SELECT * FROM customers WHERE Email='".$email."' OR  Phone = '".$phone."'";
        $result= mysqli_query($this->connect,$query);
        $num = mysqli_num_rows($result);

        $query1="SELECT * FROM rider WHERE Email='".$email."' OR  Phone = '".$phone."'";
        $result1= mysqli_query($this->connect,$query1);
        $num1 = mysqli_num_rows($result1);
        if ($num == 0 && $num1==0){
                $this->sql="INSERT INTO `".$table ."` (Name, Gender, Phone, Email, Password, Address, Date_Of_Birth) VALUES ('" . $fullname . "','" . $gender . "','" . $phone . "','" . $email . "','" .$password . "','" . $address . "','" . $dateofbirth . "')";
                if (mysqli_query($this->connect, $this->sql)) {return true;}
                else return false; 
        }
        else{return "0";}

    }

    function cart($table,$Cust_Id,$Prod_Id,$mart_id)
    {
        #$cart_id = $this->prepareData($Cart_Id);
        $cust_id = $this->prepareData($Cust_Id);
        $prod_id = $this->prepareData($Prod_Id);


        $this->sql="SELECT Quantity,Prod_Id FROM `cart items` WHERE Prod_Id='".$prod_id."' AND  Mart_Id='".$mart_id."'";
        $result= mysqli_query($this->connect, $this->sql) or die(mysql_errno());
        $num = mysqli_num_rows($result);
        if ($num == 0) {
            $this->sql =
            "INSERT INTO `". $table ."` (Cust_Id, Prod_Id,Mart_Id, Quantity) 
            VALUES ('" . $cust_id . "','" . $prod_id . "','" . $mart_id . "','1')";
        if (mysqli_query($this->connect, $this->sql)) {return true;} 
        else return false;
        }
        elseif (mysqli_num_rows($result) > 0) {
             foreach ($result as $key) {
                $quantity=$key['Quantity'];
                $quantity=$quantity+1;
                $this->sql =
            "UPDATE `".$table."` SET Quantity='".$quantity."' WHERE Prod_Id='".$prod_id."' AND Cust_Id='".$cust_id."' AND Mart_Id='".$mart_id."'";
        if (mysqli_query($this->connect, $this->sql)) {return true;} 
        else return false;
             }
        }
        
    }

    function remove_item($table,$Cust_Id,$Prod_Id,$mart_id)
    {
        $cust_id = $this->prepareData($Cust_Id);
        $prod_id = $this->prepareData($Prod_Id);
        $this->sql =
            "DELETE FROM `".$table."` WHERE Prod_Id='".$prod_id."' AND Cust_Id='".$cust_id."' AND Mart_Id='".$mart_id."'";
        if (mysqli_query($this->connect, $this->sql)) {return true;} 
        else return false;
    }

     function quantity_add($table,$Cust_Id,$Prod_Id,$mart_id)
    {
        $cust_id = $this->prepareData($Cust_Id);
        $prod_id = $this->prepareData($Prod_Id);
        $this->sql="SELECT Quantity,Prod_Id FROM `cart items` WHERE Prod_Id='".$prod_id."' AND Cust_Id='".$cust_id."' AND Mart_Id='".$mart_id."' ";
        $result= mysqli_query($this->connect, $this->sql) or die(mysql_errno());
        if (mysqli_num_rows($result) > 0) {
             foreach ($result as $key) {
                $quantity=$key['Quantity'];
                $quantity=$quantity+1;
                $this->sql =
            "UPDATE `".$table."` SET Quantity='".$quantity."' WHERE Prod_Id='".$prod_id."' AND Cust_Id='".$cust_id."' AND Mart_Id='".$mart_id."'";
        if (mysqli_query($this->connect, $this->sql)) {return true;} 
        else return false;
             }
        }
    }
     function quantity_sub($table,$Cust_Id,$Prod_Id,$mart_id)
    {
        $cust_id = $this->prepareData($Cust_Id);
        $prod_id = $this->prepareData($Prod_Id);
        $this->sql="SELECT Quantity,Prod_Id FROM `cart items` WHERE Prod_Id='".$prod_id."' AND Cust_Id='".$cust_id."' AND Mart_Id='".$mart_id."'";
        $result= mysqli_query($this->connect, $this->sql) or die(mysql_errno());
        if (mysqli_num_rows($result) > 0) {
             foreach ($result as $key) {
                $quantity=$key['Quantity'];
                $quantity=$quantity-1;
                if ($quantity=='0') {
                    $this->sql =
                    "DELETE FROM `".$table."` WHERE Prod_Id='".$prod_id."' AND Cust_Id='".$cust_id."' AND Cust_Id='".$cust_id."' AND Mart_Id='".$mart_id."'";
                    if (mysqli_query($this->connect, $this->sql)) {return true;} 
                    else return false;
                }
                else{
                    $this->sql =
                    "UPDATE `".$table."` SET Quantity='".$quantity."' WHERE Prod_Id='".$prod_id."' AND Cust_Id='".$cust_id."' AND Mart_Id='".$mart_id."'";
                    if (mysqli_query($this->connect, $this->sql)) {return true;} 
                    else return false;
                }
                
             }
        }
    }

    function change_profile($table,$cust_id,$Name,$phone,$address,$password)
    {
        $this->sql =
                    "UPDATE `".$table."` SET Name= '".$Name."', Phone= '".$phone."', Password='".$password."',Address='".$address."' 
                    WHERE Customer_Id='".$cust_id."'";
                    if (mysqli_query($this->connect, $this->sql)) {return true;} 
                    else return false;
    }
     function change_rider_profile($table,$cust_id,$Name,$phone,$address,$password)
    {
        $this->sql =
                    "UPDATE `".$table."` SET Name= '".$Name."', Phone= '".$phone."', Password='".$password."',Address='".$address."' 
                    WHERE Rider_Id='".$cust_id."'";
                    if (mysqli_query($this->connect, $this->sql)) {return true;} 
                    else return false;
    }
    function reset_password($table,$email,$dob){
        $query="SELECT * FROM customers WHERE Email='".$email."' AND  Date_Of_Birth = '".$dob."'";
        $result= mysqli_query($this->connect,$query);
        $num = mysqli_num_rows($result);

        $query1="SELECT * FROM rider WHERE Email='".$email."' AND  Date_Of_Birth = '".$dob."'";
        $result1= mysqli_query($this->connect,$query1);
        $num1 = mysqli_num_rows($result1);
        if ($num==1) {
            $this->sql ="UPDATE `".$table."` SET Password='1234' WHERE Email='".$email."' AND  Date_Of_Birth = '".$dob."'";
            if (mysqli_query($this->connect, $this->sql)) {return true;}
        }
        elseif ($num1==1) {
            $this->sql ="UPDATE rider SET Password='1234' WHERE Email='".$email."' AND  Date_Of_Birth = '".$dob."'";
            if (mysqli_query($this->connect, $this->sql)) {return true;}
        }
        else{return false;}
    }
    function logout_rider($table,$rider_id)
    {
        $this->sql =
                    "UPDATE `".$table."` SET Status= 'Offline' 
                    WHERE Rider_Id='".$rider_id."'";
                    if (mysqli_query($this->connect, $this->sql)) {return true;} 
                    else return false;
    }

    function add_rider_notification($cust_id,$rider_id)
    {
        $this->sql ="INSERT INTO `rider notification` (Cust_Id,Rider_Id) 
        VALUES ('".$cust_id."','".$rider_id."')";
        mysqli_query($this->connect, $this->sql);

        $this->sql ="SELECT * FROM `cart items` where Cust_Id='".$cust_id."'";
        $fetch=mysqli_query($this->connect, $this->sql);
        $i=0;
        $m1="";
        while($row = mysqli_fetch_array($fetch))
        {
            $m2=$row['3'];
            $i++;
            if($i<2)
            {
                $m1=$row['3'];
                $this->sql ="INSERT INTO `mart notification` (Mart_Id,Rider_Id) 
                VALUES ('".$row['3']."','".$rider_id."')";
                mysqli_query($this->connect, $this->sql);
            }
            else
            {
                if ($m2!=$m1) 
                {
                   $m1=$row['3'];
                   $this->sql ="INSERT INTO `mart notification` (Mart_Id,Rider_Id) 
                   VALUES ('".$row['3']."','".$rider_id."')";
                   mysqli_query($this->connect, $this->sql);
                }
            }
            

            $this->sql ="INSERT INTO `user cart` (Cust_Id,Mart_Id,Prod_Id,Quantity) 
            VALUES ('".$cust_id."','".$row['3']."','".$row['2']."','".$row['4']."')";
            mysqli_query($this->connect, $this->sql);
        }

        $this->sql ="UPDATE `rider` SET Status= 'Busy' WHERE Rider_Id='".$rider_id."'";
        mysqli_query($this->connect, $this->sql);

        $this->sql ="DELETE FROM `cart items` WHERE Cust_Id='".$cust_id."'";
        if (mysqli_query($this->connect, $this->sql)) {return true;} 
        else return false;
    }
    function del_rider_notification($rider_id){

        $this->sql ="UPDATE `rider` SET Status= 'Free' WHERE Rider_Id='".$rider_id."'";
        mysqli_query($this->connect, $this->sql);

        $this->sql ="DELETE FROM `rider notification` WHERE Rider_Id='".$rider_id."'";
        if (mysqli_query($this->connect, $this->sql)) {return true;} 
        else return false;
    }
}

?>
