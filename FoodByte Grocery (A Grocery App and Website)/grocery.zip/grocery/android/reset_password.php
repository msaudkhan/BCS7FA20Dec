<?php
require "DataBase.php";
$db = new DataBase();
if (isset($_POST['email']) && isset($_POST['dob'])) {
    if ($db->dbConnect()) {
        if ($db->reset_password("customers", $_POST['email'], $_POST['dob'])) {
            echo "reset";
        }
        else echo "Wrong Email or DOB";
    } else echo "Error: Database connection";
} else echo "All fields are required";
?>
