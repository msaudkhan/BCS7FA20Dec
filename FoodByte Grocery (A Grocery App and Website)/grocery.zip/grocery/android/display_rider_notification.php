<?php
    $connect = mysqli_connect("localhost","root","","foodbyte");
if($_SERVER['REQUEST_METHOD'] =='POST'){
   $user_id= $_POST['user_id'];
   $select= "SELECT * FROM `rider notification` where Rider_Id='".$user_id."' ";
   $result = array();
   $result['data'] = array();
   $responce = mysqli_query($connect,$select);
    while($row1 = mysqli_fetch_array($responce))
			 {
			 
			 $select= "SELECT * FROM `customers` where Customer_Id='".$row1['1']."'";	
			 $fetch = mysqli_query($connect,$select);
			 while($row = mysqli_fetch_array($fetch))
			 {
			 	$query=mysqli_query($connect,"SELECT * FROM `user cart` WHERE Cust_Id='".$row['0']."' GROUP BY Mart_Id");
			 	$mart="";
			 	while($row3 = mysqli_fetch_array($query))
			 	{
			 		$select1= "SELECT * FROM `marts` where Id='".$row3['3']."'";	
			 		$fetch1 = mysqli_query($connect,$select1);
			        while($row4 = mysqli_fetch_array($fetch1)){
			        	$mart=$mart." and ".$row4['1'];
			        }
			 		
			 	}
                   $indx['order_id']=$row1['0'];
			       $indx['desp']=$row1['3'];
		           $indx['name']  = $row['1'];
		           $indx['mart_id']=$mart;
		           array_push($result['data'], $indx);
			 }
			 
			 }
			 $result["success"]="1";
			// print_r($result);
		    echo json_encode($result);
			mysqli_close($connect);
}
else echo "not set";
?>