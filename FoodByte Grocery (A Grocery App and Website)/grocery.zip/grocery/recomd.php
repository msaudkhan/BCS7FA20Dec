<?php 
 include 'conection.php';
 $re= mysqli_query($con,"SELECT Ml_Name from products");
 $array= array();
 $j=0;
 while ($rows=mysqli_fetch_assoc($re)) {
 	
 	for ($i=$j; $i <$j+100; $i++) { 
 		$array[$i]=$rows['Ml_Name'];
 		//echo $array[$i]." ";
 	}
 	$j=$j+100;
 }
shuffle($array);shuffle($array);shuffle($array);
for ($i=0; $i <count($array) ; $i++) { 
	echo $array[$i]." ";
}

?>