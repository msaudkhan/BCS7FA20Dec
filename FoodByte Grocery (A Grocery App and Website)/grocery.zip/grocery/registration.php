
<html>
<head>
	<title>Registration</title>
<!--===============================================================================================-->	
	
	  <link rel="stylesheet" type="text/css" href="css/main.css">
    <link rel="stylesheet" type="text/css" href="css/login.css">
    <link rel="stylesheet" type="text/css" href="css/reg.css">

<!--===============================================================================================-->
</head>
<body>
	<?php include 'headers/main-header.html'; ?>
<br>
<div class="container">
  <form action="check-registration.php" method="POST" >
    
      <center><h3>Registration</h3></center>
      <br>
      <div class="input-group input-group-icon">
        <input type="text" placeholder="Full Name" name="name"  required>
        <div class="input-icon"><img src="icon/user.png"></div>
      </div>
      <div class="input-group input-group-icon">
        <input type="email" placeholder="Email Adress" name="email" required>
        <div class="input-icon"><img src="icon/email.png"></div>
      </div>
      <div class="input-group input-group-icon">
        <input type="password" placeholder="Password" name="password" required>
        <div class="input-icon"><img src="icon/password.png"></div>
      </div>
      <div class="col-half">
        <h3>Date of Birth</h3>
      <div class="input-group">
      <div class="col-third">           
        <input type="Number" placeholder="DD" max="31" min="1" name="d" required>
      </div>
      <div class="col-third">
        <input type="Number" placeholder="MM" max="12" min="1" name="m" required>
      </div>
      <div class="col-third">
        <input type="Number" placeholder="YYYY" max="2012" min="1970" name="y"required>
      </div>
        </div>
      </div>
      <div class="col-half">
        <h3>Gender</h3>
        <div class="input-group">
          <input type="radio" name="gender" value="male" id="gender-male"required>
          <label for="gender-male">Male</label>
          <input type="radio" name="gender" value="female" id="gender-female"required>
          <label for="gender-female">Female</label>
        </div>
      </div>
      <div class="input-group input-group-icon">
        <input type="text" placeholder="Phone Number" name="phone" required>
        <div class="input-icon"><img src="icon/phone-no.png"></div>
      </div>
      <div class="input-group input-group-icon">
        <input type="text" placeholder="Address" name="address" required>
        <div class="input-icon"><img src="icon/home.png"></div>
      </div>
      <button class="login-form-btn" type="submit" name="submit">Register</button>
  </form>
  
</div>
</body>
</html>
