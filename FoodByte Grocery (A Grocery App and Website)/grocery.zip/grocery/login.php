
<html>
<head>
	<title>Login</title>
	<link rel="stylesheet" type="text/css" href="css/login.css">
    <link rel="stylesheet" type="text/css" href="css/main.css">
    <meta charset="utf-8">
    
<meta name="viewport" content="width=device-width, initial-scale=1">
</head>
<body>
<?php include 'headers/main-header.html'; ?>
	<div class="container-login">
		<div class="wrap-login">
		<div class="login-form-title"><span class="login-form-title-1">Login In</span></div>
	<form class="login-form " action="check-login.php" method="POST">
	    <div class="wrap-input m-b-26">
	   		<span class="label-input">Email</span>
	   		<input class="form-input" type="text" name="email" placeholder="Enter Email" required>
		</div>	
		<div class="wrap-input m-b-18">
	    	<span class="label-input">Password</span>
        	<input class="form-input" type="password" name="pass" placeholder="Enter password" required>
		</div>
		
		<div class="container-login-form-btn">
		    <button class="login-form-btn" type="submit" name="submit">Login</button>
		    <a href="registration.php" style="margin-left: 20px;" class="login-form-btn">Register</a>
		</div>
    </form>
</div>		
</div>
</body>
</html>