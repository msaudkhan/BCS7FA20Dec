<?php
 session_start();
 include 'conection.php';
 $query="DELETE FROM `cart items` WHERE Cust_Id='".$_SESSION["cust_id"]."'";
 mysqli_query($con,$query);
 session_destroy();
 header("Location:index.php");
?>