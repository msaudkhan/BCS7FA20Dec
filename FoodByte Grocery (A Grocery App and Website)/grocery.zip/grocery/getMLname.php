<?php
$connect = mysqli_connect("localhost","root","","foodbyte");
if($_SERVER['REQUEST_METHOD'] =='POST'){
	$result = array();
			$result['data'] = array();
$recomment_id= $_POST['recomment_id'];
$query1="SELECT * FROM `mart01 products` WHERE Prod_Id= '".$recomment_id."'";
$responce = mysqli_query($connect,$query1);
	
            
			while($row = mysqli_fetch_array($responce))
			{
		
		    $index['Ml_Name']    = $row['2'];
		    // $index['name']  = $row['1'];
		    // $index['price'] = $row['4'];
		    // $index['image'] = $row['7'];

     
				
			array_push($result['data'], $index);

			
				
			}
			$result["success"]="1";
		    echo json_encode($result);
		   // echo $category;
			mysqli_close($connect);

            }	
//echo $data;



?>