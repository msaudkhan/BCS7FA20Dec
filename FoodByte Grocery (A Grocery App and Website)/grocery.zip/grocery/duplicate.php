
<?php include 'conection.php';
$q="SELECT Prod_Name FROM `products`";
     	$result1 = mysqli_query($con,$q) or die(mysqli_error());
     	if(is_null($result1)){echo "failed".mysqli_error();}
     	else{
        if(mysqli_num_rows($result1) > 0 )
        { $i=1;
           foreach ($result1 as $key) {
               $add=$key["Prod_Name"];
               $new_str = str_replace(' ', '', $add);
               $query="UPDATE products SET `Ml_Name`='".$new_str."' WHERE Prod_Id='$i'";
               mysqli_query($con, $query);
               $i=$i+1;
               echo $i."<br>";
           }
           echo "added all";
        }
    }
?>