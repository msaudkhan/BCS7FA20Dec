
<?php
$con = mysqli_connect("localhost","root","","foodbyte") or die("not connected".mysqli_error());

?>