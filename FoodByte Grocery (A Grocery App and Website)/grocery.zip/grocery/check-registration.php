
<?php 
include 'conection.php';
if (isset($_POST['submit'])) {
  $name=$_POST['name'];
  $email=$_POST['email'];
  $password=$_POST['password'];
  $d=$_POST['d'];
  $m=$_POST['m'];
  $y=$_POST['y'];
  $phone=$_POST['phone'];
  $gender=$_POST['gender'];
  $address=$_POST['address'];
  $dob=$d."/".$m."/".$y;

  $query="SELECT * FROM customers WHERE Email='".$email."' OR  Phone = '".$phone."'";
  $result= mysqli_query($con,$query);
     $num = mysqli_num_rows($result);
  if ($num == 0) {
  	$query="INSERT INTO customers 
          (Name,Email,Password,Date_Of_Birth,Gender,Phone,Address)
          VALUES
          ('$name','$email','$password','$dob','$gender','$phone','$address')";

          mysqli_query($con,$query) or die(mysql_error());
          echo "Successfull! <br>";
          echo "Thanks ".$name;
          sleep(3);
          header("Location:index.php");
  }
  else{echo "Email or Phone Number Already Taken MR:".$name;
       echo "<br> <a href='registration.php'> <button>Go To Registration Form</button></a>";
      }

  
}
?>