
<?php 
include 'headers/main-header.html';
include 'conection.php';
session_start(); 

$rest=mysqli_query($con,"SELECT * FROM `Cart Items`");
$num =mysqli_num_rows($rest);
?>
	<div id="menu">
		<img onclick="window.location.href='index.php'" style="margin-left: 30px;" src="pics/m.png">
	    <h2>Cash On Delivery</h2>
	</div>
	<hr>
	<br>
	<div id="menu2">
	<ul>
		<li><div class="dropdown">
    <button class="dropbtn">Backery Items</button>
    <div class="dropdown-content">
      <div class="list-items">
        <a style="width: 60%;" href="products.php?id=<?php echo "candy"?>">CANDY</a>
        <a style="width: 40%;" href="products.php?id=<?php echo "pasta"?>">PASTA</a>
    </div>
     <div class="list-items">
        <a style="width: 60%;" href="products.php?id=<?php echo "beverages"?>">BEVERAGES</a>
        <a style="width: 40%;" href="products.php?id=<?php echo "milk"?>">Milk</a>
    </div>
    <div class="list-items">
        <a style="width: 60%;" href="products.php?id=<?php echo "biscuit"?>">BISCUITS</a>
        <a style="width: 40%;" href="products.php?id=<?php echo "cake"?>">CAKE</a>
    </div>
    </div>
    </div></li>
    <li><div class="dropdown">
    <button class="dropbtn">Fresh Food</button>
    <div class="dropdown-content">
     <div class="list-items">
        <a style="width: 40%;" href="products.php?id=<?php echo "vegetable"?>">Vegatables</a>
        <a style="width: 40%;" href="products.php?id=<?php echo "meat"?>">Beef/Chicken</a>
    </div>
     <div class="list-items">
        <a style="width: 40%;" href="products.php?id=<?php echo "Sweet"?>">Sweet</a>
        <a style="width: 40%;" href="products.php?id=<?php echo "break fast"?>">Break Fast</a>
    </div>
  </div></div></li>
    <li><div class="dropdown">
    <button class="dropbtn">HouseHold Needs</button>
    <div class="dropdown-content">
     <div class="list-items">
        <a style="width: 40%;" href="products.php?id=<?php echo "Cleaning"?>">CLEANING</a>
        <a style="width: 40%;" href="products.php?id=<?php echo "kitchen"?>">KITCHEN ACCESSORIES</a>
    </div>
     <div class="list-items">
      	<a style="width: 40%;" href="products.php?id=<?php echo "Toilet Paper"?>">TOILET PAPER</a>
        <a style="width: 40%;" href="products.php?id=<?php echo "Air Freshner"?>">AIR FRESHNERS</a>
    </div>
     <div class="list-items">
        <a style="width: 40%;" href="products.php?id=<?php echo "Cigaret"?>">CIGARETTES AND LIGHTERS</a>
    </div>
  </div></div></li>

  <li><div class="dropdown">
    <button class="dropbtn">Personal Care</button>
    <div class="dropdown-content">
      <div class="list-items">
        <a style="width: 60%;" href="products.php?id=<?php echo "Body Care"?>">BODY CARE</a>
        <a style="width: 40%;" href="products.php?id=<?php echo "Hair Care"?>">HAIR CARE</a>
      </div>
      <div class="list-items">
      	<a style="width: 60%;" href="products.php?id=<?php echo "Beauty Care"?>">BEAUTY CARE</a>
        <a style="width: 40%;" href="products.php?id=<?php echo "Perfumes"?>">PERFUMES</a>
      </div>
      <div class="list-items">
        <a style="width: 40%;" href="products.php?id=<?php echo "Oral Care"?>">ORAL CARE</a>
        
      </div>
  </div></li>

  <li><div class="dropdown">
    <button class="dropbtn">Baby Care</button>
    <div class="dropdown-content">
     <div class="list-items">
        <a style="width: 40%;" href="products.php?id=<?php echo "Diapers"?>">DIAPERS</a>
        <a style="width: 60%;" href="products.php?id=<?php echo "Baby Milk"?>">BABY MILK</a>
    </div>
     <div class="list-items">
      	<a style="width: 50%;" href="products.php?id=<?php echo "Baby Body Care"?>">BODY CARE</a>
    </div>
    </div></div></li>

   <li><div class="dropdown">
    <button class="dropbtn">Stationary Products</button>
    <div class="dropdown-content">
    <div class="list-items">
        <a style="width: 40%;" href="products.php?id=<?php echo "stationary"?>">PENS</a>
        <a style="width: 40%;" href="products.php?id=<?php echo "stationary"?>">PENCILS</a>  
    </div>
     <div class="list-items">
      	<a style="width: 40%;" href="products.php?id=<?php echo "stationary"?>">BOOKS</a>
        <a style="width: 40%;" href="products.php?id=<?php echo "stationary"?>">DAIRIES</a>    
    </div>
    <div class="list-items">
      <a style="width: 40%;" href="products.php?id=<?php echo "stationary"?>">COLORS</a>
      <a style="width: 40%;" href="products.php?id=<?php echo "stationary"?>">REGISTERS</a>
    </div>
    </div></div></li>

  <li><div class="dropdown">
    <button class="dropbtn">Pet Foods</button>
    <div class="dropdown-content">
    <div class="list-items">
        <a style="width: 40%;" href="products.php?id=<?php echo "Pet Food"?>">KITCHEN QUEEN BAJRA</a>
        <a style="width: 40%;" href="products.php?id=<?php echo "Pet Food"?>">FELIX CAT FOOD SACHET</a>
        
    </div>
 
    <div class="list-items">
      <a style="width: 40%;" href="products.php?id=<?php echo "Pet Food"?>">ME-O CAT SEA FOOD</a>
      <a style="width: 40%;" href="products.php?id=<?php echo "Pet Food"?>">NOVA FISH FOOD</a>
    </div>
    </div></div></li>
  <li><div class="dropdown">
    <button class="dropbtn">Sale on products</button>
    <div class="dropdown-content">
    <div class="list-items">
        <a style="width: 100%;" href="#">no product on sale </a>
    </div>
  </div></div></li>
	</ul>
</div>
<br>
<hr>
	<img src="pics/banner2.jpg" style="margin-top: 2%;width:101%;margin-left: -1%;">
	<hr>
	<br><br>

<?php
$query1="SELECT * FROM `mart01 products` WHERE category='cake' LIMIT 3";
$query2="SELECT * FROM `mart01 products` WHERE category='milk' LIMIT 3";
$query3="SELECT * FROM `mart01 products` WHERE category='biscuit' LIMIT 3";
$query4="SELECT * FROM `mart01 products` WHERE category='air freshner' LIMIT 3";
$query5="SELECT * FROM `mart01 products` WHERE category='cleaning' LIMIT 3";
for ($i=1; $i <6 ; $i++) { 
  if ($i==1) {
    $re=mysqli_query($con,$query1);
  }
  if ($i==2) {
    $re=mysqli_query($con,$query2);
  }
  if ($i==3) {
    $re=mysqli_query($con,$query3);
  }
  if ($i==4) {
    $re=mysqli_query($con,$query4);
  }
  if ($i==5) {
    $re=mysqli_query($con,$query5);
  }

while($results = mysqli_fetch_array($re)) { ?>
  <div class="card">
       <img src="images/<?php echo $results['Category']; ?>/<?php echo $results['Prod_Img']; ?>" alt="bakery Biscuit" style="width:100%">
       <div class="card_desp"><h3><?php echo $results['Prod_Name']; ?></h3>
       <p class="price">RS : <?php echo $results['Prod_Price']; ?></p>
       <p><?php echo $results['Prod_Desp']; ?></p>
    </div></div>

<?php }} ?>



<?php include 'footer.html'; ?>

<script type="text/javascript">
  function increment() {
  <?php if (isset($_SESSION["name"])){ ?>
    var val = parseInt(document.getElementById('inc').value);
    val++;
    document.getElementById('inc').value=val;
  <?php } 
  else{ ?>alert("sorry you have to login first");
  <?php }?>
}
</script>