<?php
$connect = mysqli_connect("localhost","root","","foodbyte");
if($_SERVER['REQUEST_METHOD'] =='POST'){
	
$product_name= $_POST['product'];
$result = array();
			$result['data'] = array();
$query1="SELECT * FROM `mart01 products` WHERE Ml_Name= '".$product_name."' ";
$responce = mysqli_query($connect,$query1);
	
            
			while($row = mysqli_fetch_array($responce))
			{
		
		    $index['id']    = $row['0'];
		    $index['name']  = $row['1'];
		    $index['price'] = $row['4'];
            $index['image']= $row['7'];
            $index['category']= $row['3'];
     
				
			array_push($result['data'], $index);

			
				
			}
			$result["success"]="1";
		    echo json_encode($result);
		   // echo $responce;
		    echo $product_name;
			mysqli_close($connect);

            }	
//echo $data;



?>