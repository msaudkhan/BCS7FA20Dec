<?php 
include 'headers/main-header.html';
$category=$_GET['id'];
include 'conection.php';
$query="SELECT * FROM products WHERE category='".$category."'";
$re=mysqli_query($con,$query);

?>
<div id="menu">
	<img onclick="window.location.href='index.php'" style="margin-left: 30px;" src="pics/m.png">
    <h2>Cash On Delivery</h2>
</div><hr>
<h1 style="background-color: green;"><?php echo ucwords($category); ?> Menu</h1><hr>
<img style="width: 80%;margin-left: 10%;height: 60vh" src="images/<?php echo $category ?>/banner.jpg"><hr>
<?php while($results = mysqli_fetch_array($re)) { ?>
	<div class="card">
       <img src="images/<?php echo $results['Category']; ?>/<?php echo $results['Prod_Img']; ?>" alt="bakery Biscuit" style="width:100%">
       <div class="card_desp"><h3><?php echo $results['Prod_Name']; ?></h3>
       <p class="price">RS : <?php echo $results['Prod_Price']; ?></p>
       <p><?php echo $results['Prod_Desp']; ?></p>
    </div></div>

<?php } ?>

<script type="text/javascript">
  function increment() {
    var val = parseInt(document.getElementById('inc').value);
    val++;
    document.getElementById('inc').value=val;
  }
</script>